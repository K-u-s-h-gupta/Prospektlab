var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

// frontend/src/telemetry.ts
var SESSION_STORAGE_KEY = "prospektlab_telemetry_session_id";
var CLIENT_IDENTITY_KEY = "prospektlab_telemetry_user";
var UTM_STORAGE_KEY = "prospektlab_telemetry_utm";
var initialized = false;
var enabled = false;
var ingestionUrl = "";
var instrumentationKey = "";
var sessionId = "";
var currentUser = null;
var utmParams = {};
var appRoleName = "prospektlab-frontend";
var cloudRoleInstance = "browser";
function getRuntimeWindow() {
  if (typeof window === "undefined") {
    return void 0;
  }
  return window;
}
function readRuntimeConfig() {
  const runtimeWindow = getRuntimeWindow();
  const runtimeConfig = runtimeWindow?.__CONFIG__?.telemetry || {};
  const envConnectionString = import.meta?.env?.VITE_APPINSIGHTS_CONNECTION_STRING || "";
  return {
    enabled: runtimeConfig.enabled ?? Boolean(runtimeConfig.connectionString || envConnectionString),
    connectionString: runtimeConfig.connectionString || envConnectionString || "",
    roleName: runtimeConfig.roleName,
    cloudRoleInstance: runtimeConfig.cloudRoleInstance
  };
}
function parseConnectionString(connectionString) {
  const parts = connectionString.split(";").map((segment) => segment.trim()).filter(Boolean);
  const parsed = {};
  for (const part of parts) {
    const eqIndex = part.indexOf("=");
    if (eqIndex <= 0) {
      continue;
    }
    const key = part.slice(0, eqIndex).trim().toLowerCase();
    const value = part.slice(eqIndex + 1).trim();
    parsed[key] = value;
  }
  const instrumentationKeyValue = parsed["instrumentationkey"];
  const ingestionEndpoint = parsed["ingestionendpoint"] || "https://dc.services.visualstudio.com";
  if (!instrumentationKeyValue) {
    return null;
  }
  const normalizedEndpoint = ingestionEndpoint.endsWith("/") ? ingestionEndpoint : `${ingestionEndpoint}/`;
  return {
    instrumentationKey: instrumentationKeyValue,
    ingestionUrl: new URL("v2/track", normalizedEndpoint).toString()
  };
}
function ensureSessionId() {
  if (sessionId) {
    return sessionId;
  }
  const runtimeWindow = getRuntimeWindow();
  if (!runtimeWindow) {
    sessionId = `telemetry-${Date.now()}`;
    return sessionId;
  }
  try {
    const stored = runtimeWindow.sessionStorage.getItem(SESSION_STORAGE_KEY);
    if (stored) {
      sessionId = stored;
      return sessionId;
    }
  } catch (_) {
  }
  sessionId = typeof crypto !== "undefined" && typeof crypto.randomUUID === "function" ? crypto.randomUUID() : `telemetry-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
  try {
    runtimeWindow.sessionStorage.setItem(SESSION_STORAGE_KEY, sessionId);
  } catch (_) {
  }
  return sessionId;
}
function captureUtmParams() {
  const runtimeWindow = getRuntimeWindow();
  if (!runtimeWindow) {
    return {};
  }
  try {
    const stored = runtimeWindow.localStorage.getItem(UTM_STORAGE_KEY);
    if (stored) {
      utmParams = JSON.parse(stored);
      return utmParams;
    }
  } catch (_) {
  }
  try {
    const searchParams = new URLSearchParams(runtimeWindow.location.search);
    const params = {};
    const utmKeys = ["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term"];
    for (const key of utmKeys) {
      const value = searchParams.get(key);
      if (value) {
        params[key] = value;
      }
    }
    if (Object.keys(params).length > 0) {
      utmParams = params;
      try {
        runtimeWindow.localStorage.setItem(UTM_STORAGE_KEY, JSON.stringify(params));
      } catch (_) {
      }
    }
  } catch (_) {
  }
  return utmParams;
}
function getUtmParams() {
  return utmParams;
}
function formatDuration(durationMs) {
  const totalMs = Math.max(0, Math.round(durationMs || 0));
  const hours = Math.floor(totalMs / 36e5);
  const minutes = Math.floor(totalMs % 36e5 / 6e4);
  const seconds = Math.floor(totalMs % 6e4 / 1e3);
  const millis = totalMs % 1e3;
  const pad = (value, width = 2) => value.toString().padStart(width, "0");
  return `${pad(hours)}:${pad(minutes)}:${pad(seconds)}.${pad(millis, 3)}`;
}
function sanitizeProperties(properties) {
  const sanitized = {};
  if (!properties) {
    return sanitized;
  }
  for (const [key, value] of Object.entries(properties)) {
    if (value === void 0 || value === null) {
      continue;
    }
    if (typeof value === "string") {
      sanitized[key] = value;
    } else if (typeof value === "number" || typeof value === "boolean") {
      sanitized[key] = String(value);
    } else {
      sanitized[key] = JSON.stringify(value);
    }
  }
  return sanitized;
}
function sanitizeMeasurements(measurements) {
  const sanitized = {};
  if (!measurements) {
    return sanitized;
  }
  for (const [key, value] of Object.entries(measurements)) {
    if (typeof value === "number" && Number.isFinite(value)) {
      sanitized[key] = value;
    }
  }
  return sanitized;
}
function buildTags(extraTags) {
  const tags = {
    "ai.application.ver": "prospektlab-web",
    "ai.device.id": ensureSessionId(),
    "ai.session.id": ensureSessionId(),
    "ai.cloud.role": appRoleName,
    "ai.cloud.roleInstance": cloudRoleInstance,
    "ai.operation.id": ensureSessionId()
  };
  if (currentUser) {
    tags["ai.user.id"] = currentUser.email;
    tags["ai.user.authUserId"] = currentUser.email;
    tags["ai.user.accountId"] = currentUser.email;
  }
  return {
    ...tags,
    ...extraTags || {}
  };
}
function buildEnvelope(baseType, baseData, extraTags) {
  return {
    name: `Microsoft.ApplicationInsights.${baseType}`,
    time: (/* @__PURE__ */ new Date()).toISOString(),
    iKey: instrumentationKey,
    tags: buildTags(extraTags),
    data: {
      baseType,
      baseData
    }
  };
}
async function postEnvelopes(envelopes) {
  if (!enabled || envelopes.length === 0 || !ingestionUrl) {
    return;
  }
  const payload = JSON.stringify(envelopes);
  if (typeof window !== "undefined") {
    try {
      const parsedUrl = new URL(ingestionUrl, window.location.href);
      const isSameOrigin = parsedUrl.origin === window.location.origin;
      if (isSameOrigin && typeof navigator !== "undefined" && typeof navigator.sendBeacon === "function") {
        const blob = new Blob([payload], { type: "application/json" });
        if (navigator.sendBeacon(ingestionUrl, blob)) {
          return;
        }
      }
    } catch (_) {
    }
  }
  await fetch(ingestionUrl, {
    method: "POST",
    mode: "cors",
    credentials: "omit",
    keepalive: true,
    headers: {
      "Content-Type": "application/json"
    },
    body: payload
  }).catch(() => {
  });
}
function schedule(envelopes) {
  if (!enabled || envelopes.length === 0) {
    return;
  }
  void postEnvelopes(envelopes);
}
function buildCommonProperties(properties) {
  const runtimeWindow = getRuntimeWindow();
  const base = {
    source: "frontend",
    session_id: ensureSessionId(),
    environment: runtimeWindow?.__CONFIG__?.environment || import.meta?.env?.MODE || "unknown"
  };
  if (currentUser) {
    base.user_email = currentUser.email;
    base.user_name = currentUser.name;
  }
  const utm = getUtmParams();
  if (utm.utm_source) base.utm_source = utm.utm_source;
  if (utm.utm_medium) base.utm_medium = utm.utm_medium;
  if (utm.utm_campaign) base.utm_campaign = utm.utm_campaign;
  if (utm.utm_content) base.utm_content = utm.utm_content;
  if (utm.utm_term) base.utm_term = utm.utm_term;
  return {
    ...base,
    ...sanitizeProperties(properties)
  };
}
function handleGlobalError(event) {
  trackException(event.error || new Error(event.message || "Unhandled error"), {
    handler: "window.error",
    filename: event.filename,
    lineno: event.lineno,
    colno: event.colno
  });
}
function handleUnhandledRejection(event) {
  const reason = event.reason instanceof Error ? event.reason : new Error(typeof event.reason === "string" ? event.reason : "Unhandled promise rejection");
  trackException(reason, {
    handler: "window.unhandledrejection"
  });
}
function initializeTelemetry() {
  if (initialized) {
    return;
  }
  initialized = true;
  const config = readRuntimeConfig();
  enabled = Boolean(config.enabled && config.connectionString);
  if (!enabled) {
    return;
  }
  const parsed = parseConnectionString(config.connectionString || "");
  if (!parsed) {
    enabled = false;
    return;
  }
  ingestionUrl = parsed.ingestionUrl;
  instrumentationKey = parsed.instrumentationKey;
  appRoleName = config.roleName || "prospektlab-frontend";
  cloudRoleInstance = config.cloudRoleInstance || "browser";
  ensureSessionId();
  captureUtmParams();
  const runtimeWindow = getRuntimeWindow();
  if (runtimeWindow) {
    runtimeWindow.addEventListener("error", handleGlobalError);
    runtimeWindow.addEventListener("unhandledrejection", handleUnhandledRejection);
  }
  const utm = getUtmParams();
  trackEvent("app_initialized", {
    session_id: ensureSessionId(),
    environment: getRuntimeWindow()?.__CONFIG__?.environment || import.meta?.env?.MODE || "unknown",
    has_utm_attribution: Object.keys(utm).length > 0 ? "true" : "false"
  });
}
function getTelemetrySessionId() {
  return ensureSessionId();
}
function setTelemetryUser(user) {
  currentUser = user ? {
    email: user.email,
    name: user.name || user.email
  } : null;
  const runtimeWindow = getRuntimeWindow();
  if (!runtimeWindow) {
    return;
  }
  try {
    if (currentUser) {
      runtimeWindow.sessionStorage.setItem(CLIENT_IDENTITY_KEY, JSON.stringify(currentUser));
    } else {
      runtimeWindow.sessionStorage.removeItem(CLIENT_IDENTITY_KEY);
    }
  } catch (_) {
  }
}
function clearTelemetryUser() {
  setTelemetryUser(null);
}
function trackEvent(name, properties, measurements) {
  if (!enabled) {
    return;
  }
  schedule([
    buildEnvelope("EventData", {
      ver: 2,
      name,
      properties: buildCommonProperties(properties),
      measurements: sanitizeMeasurements(measurements)
    })
  ]);
}
function trackPageView(name, properties) {
  if (!enabled) {
    return;
  }
  const runtimeWindow = getRuntimeWindow();
  const navigationEntry = typeof performance !== "undefined" ? performance.getEntriesByType("navigation")[0] : void 0;
  const durationMs = navigationEntry?.duration;
  schedule([
    buildEnvelope("PageviewData", {
      ver: 2,
      name,
      uri: runtimeWindow?.location?.href || name,
      duration: typeof durationMs === "number" ? formatDuration(durationMs) : void 0,
      properties: buildCommonProperties({
        page_title: runtimeWindow?.document?.title || name,
        referrer: runtimeWindow?.document?.referrer || "",
        route: name,
        ...properties
      })
    })
  ]);
}
function trackDependency(options) {
  if (!enabled) {
    return;
  }
  let target = options.url;
  try {
    target = new URL(options.url, getRuntimeWindow()?.location?.origin || "http://localhost").host || options.url;
  } catch (_) {
    target = options.url;
  }
  schedule([
    buildEnvelope("RemoteDependencyData", {
      ver: 2,
      id: options.requestId || ensureSessionId(),
      name: options.name,
      data: options.url,
      target,
      duration: formatDuration(options.durationMs),
      success: options.success,
      resultCode: options.statusCode !== void 0 ? String(options.statusCode) : void 0,
      type: "Fetch",
      properties: buildCommonProperties(options.properties),
      measurements: sanitizeMeasurements({
        ...options.measurements,
        duration_ms: options.durationMs
      })
    })
  ]);
}
function trackException(error, properties, measurements) {
  if (!enabled) {
    return;
  }
  schedule([
    buildEnvelope("ExceptionData", {
      ver: 2,
      exceptions: [
        {
          typeName: error.name || "Error",
          message: error.message || String(error),
          hasFullStack: Boolean(error.stack),
          stack: error.stack || ""
        }
      ],
      severityLevel: 3,
      properties: buildCommonProperties(properties),
      measurements: sanitizeMeasurements(measurements)
    })
  ]);
}
function buildTelemetryHeaders(headers) {
  const merged = new Headers(headers || {});
  merged.set("X-Prospektlab-Request-Id", typeof crypto !== "undefined" && typeof crypto.randomUUID === "function" ? crypto.randomUUID() : `req-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`);
  merged.set("X-Prospektlab-Session-Id", ensureSessionId());
  return merged;
}
function getTelemetryRequestId(headers) {
  if (headers instanceof Headers) {
    return headers.get("X-Prospektlab-Request-Id");
  }
  if (Array.isArray(headers)) {
    const entry = headers.find(([key]) => key.toLowerCase() === "x-prospektlab-request-id");
    return entry ? entry[1] : null;
  }
  if (typeof headers === "object" && headers) {
    const record = headers;
    return record["X-Prospektlab-Request-Id"] || record["x-prospektlab-request-id"] || null;
  }
  return null;
}
function isTelemetryEnabled() {
  return enabled;
}

// frontend/src/utils/textSanitizer.ts
var MOJIBAKE_REPLACEMENTS = [
  [/\u00c3\u00a2\u00e2\u20ac\u0161\u00c2\u00b9/g, "Rs "],
  [/\u00e2\u201a\u00b9/g, "Rs "],
  [/\u00e2\u20ac\u201d/g, " - "],
  [/\u00e2\u20ac\u201c/g, " - "],
  [/\u00e2\u20ac\u02dc/g, "'"],
  [/\u00e2\u20ac\u2122/g, "'"],
  [/\u00e2\u20ac\u0153/g, '"'],
  [/\u00e2\u20ac\u009d/g, '"'],
  [/\u00e2\u20ac\u00a6/g, "..."],
  [/\u00e2\u20ac\u00a2/g, "-"],
  [/\u00e2\u2020\u2019/g, "->"],
  [/\u00c3\u00a2\u00e2\u201a\u00ac\u00e2\u20ac\u009d/g, " - "],
  [/\u00c3\u00a2\u00e2\u201a\u00ac\u00e2\u20ac\u0153/g, " - "],
  [/\u00c3\u00a2\u00e2\u201a\u00ac\u02dc/g, "'"],
  [/\u00c3\u00a2\u00e2\u201a\u00ac\u2122/g, "'"],
  [/\u00c3\u00a2\u00e2\u201a\u00ac\u0153/g, '"'],
  [/\u00c3\u00a2\u00e2\u201a\u00ac\u009d/g, '"'],
  [/\u00c3\u00a2\u00e2\u201a\u00ac\u00a6/g, "..."],
  [/\u00c3\u00a2\u00e2\u201a\u00ac\u00a2/g, "-"],
  [/\u00c3\u00a2\u00e2\u20ac\u2020\u00e2\u20ac\u2122/g, "->"],
  [/\u00c2\u00b7/g, " - "],
  [/\u00c2/g, ""]
];
var isPlainObject = (value) => Boolean(value) && Object.prototype.toString.call(value) === "[object Object]";
function repairMojibakeText(value) {
  let next = String(value ?? "").normalize("NFC");
  for (const [pattern, replacement] of MOJIBAKE_REPLACEMENTS) {
    next = next.replace(pattern, replacement);
  }
  return next;
}
function sanitizeMojibakeValue(value) {
  if (typeof value === "string") {
    return repairMojibakeText(value);
  }
  if (Array.isArray(value)) {
    return value.map((item) => sanitizeMojibakeValue(item));
  }
  if (isPlainObject(value)) {
    const entries = Object.entries(value).map(([key, item]) => [key, sanitizeMojibakeValue(item)]);
    return Object.fromEntries(entries);
  }
  return value;
}

// frontend/src/api/client.ts
var AUTH_TOKEN_KEY = "prospektlab_auth_token";
var AUTH_TOKEN_SESSION_KEY = "prospektlab_auth_token_session";
var GUEST_ID_KEY = "prospektlab_guest_id";
function getApiBase() {
  if (typeof window !== "undefined") {
    const w = window;
    if (w.__BACKEND_URL) return String(w.__BACKEND_URL).replace(/\/$/, "");
    if (w.__CONFIG__?.apiBase) return String(w.__CONFIG__.apiBase).replace(/\/$/, "");
  }
  const envBase = import.meta?.env?.VITE_BACKEND_API_URL || "";
  return envBase ? String(envBase).replace(/\/$/, "") : "";
}
function apiUrl(path) {
  if (path.startsWith("http://") || path.startsWith("https://")) return path;
  const base = getApiBase();
  if (!base) return path;
  const p = path.startsWith("/") ? path : `/${path}`;
  return `${base}${p}`;
}
function isCrossOriginApi() {
  if (typeof window === "undefined") return false;
  const base = getApiBase();
  if (!base) return false;
  try {
    return new URL(base, window.location.origin).origin !== window.location.origin;
  } catch (_) {
    return false;
  }
}
function requestCredentials() {
  return getAuthToken() ? isCrossOriginApi() ? "omit" : "include" : "include";
}
function resolveRequestCredentials(options) {
  return options?.credentials ?? requestCredentials();
}
var AUTH_REQUEST_TIMEOUT_MS = 15e3;
var MIRROR_STATUS_TIMEOUT_MS = 8e3;
var CHAT_START_TIMEOUT_MS = 9e4;
var DOCUMENT_UPLOAD_TIMEOUT_MS = 12e4;
var SCREENSHOT_UPLOAD_TIMEOUT_MS = 9e4;
function summarizeTelemetryPath(url) {
  try {
    const resolved = new URL(url, typeof window !== "undefined" ? window.location.origin : "http://localhost");
    return resolved.pathname;
  } catch (_) {
    return url;
  }
}
function telemetryMethod(options) {
  return (options?.method || "GET").toUpperCase();
}
function recordDependency(url, options, startMs, res, requestId, error) {
  if (!isTelemetryEnabled()) return;
  const elapsed = typeof performance !== "undefined" ? performance.now() - startMs : 0;
  const method = telemetryMethod(options);
  const path = summarizeTelemetryPath(url);
  const statusCode = res?.status;
  const success = res ? res.ok : false;
  trackDependency({
    name: `${method} ${path}`,
    url,
    method,
    durationMs: elapsed,
    success,
    statusCode,
    requestId,
    properties: {
      source: "frontend",
      path,
      session_id: getTelemetrySessionId(),
      error_type: error instanceof Error ? error.name : void 0
    }
  });
  if (error) {
    const exception = error instanceof Error ? error : new Error(String(error));
    if (exception.name !== "AbortError") {
      trackException(exception, {
        source: "frontend",
        path,
        method,
        request_id: requestId || ""
      });
    }
  }
}
async function fetchWithTimeout(url, options, timeoutMs, timeoutMessage) {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);
  const headers = buildTelemetryHeaders(options.headers);
  const requestId = getTelemetryRequestId(headers) || void 0;
  const startMs = typeof performance !== "undefined" ? performance.now() : Date.now();
  try {
    return await fetch(url, {
      ...options,
      headers: withAuthHeaders(headers),
      credentials: resolveRequestCredentials(options),
      signal: controller.signal
    }).then((res) => {
      recordDependency(url, options, startMs, res, requestId);
      if (res.status === 401) {
        handleAuthFailure();
      }
      return res;
    });
  } catch (err) {
    recordDependency(url, options, startMs, void 0, requestId, err);
    if (err?.name === "AbortError") {
      throw new Error(timeoutMessage);
    }
    throw err;
  } finally {
    window.clearTimeout(timer);
  }
}
var _cachedUser = null;
var _cachedUserPromise = null;
var _authToken = null;
function getStoredAuthToken() {
  if (typeof window === "undefined") return null;
  return localStorage.getItem(AUTH_TOKEN_KEY) || sessionStorage.getItem(AUTH_TOKEN_SESSION_KEY) || null;
}
function getGuestId() {
  if (typeof window === "undefined") return "";
  let gid = (localStorage.getItem(GUEST_ID_KEY) || "").trim();
  if (!/^g_[0-9a-f]{8,40}$/.test(gid)) {
    gid = `g_${Math.random().toString(16).slice(2)}${Date.now().toString(16)}`;
    localStorage.setItem(GUEST_ID_KEY, gid);
  }
  return gid;
}
function getAuthToken() {
  if (_authToken) return _authToken;
  _authToken = getStoredAuthToken();
  return _authToken;
}
function getEventSourceAuthToken() {
  return getStoredAuthToken();
}
function setAuthToken(token, remember = true) {
  _authToken = token;
  if (typeof window === "undefined") return;
  if (!token) {
    localStorage.removeItem(AUTH_TOKEN_KEY);
    sessionStorage.removeItem(AUTH_TOKEN_SESSION_KEY);
    return;
  }
  if (remember) {
    localStorage.setItem(AUTH_TOKEN_KEY, token);
    sessionStorage.removeItem(AUTH_TOKEN_SESSION_KEY);
  } else {
    sessionStorage.setItem(AUTH_TOKEN_SESSION_KEY, token);
    localStorage.removeItem(AUTH_TOKEN_KEY);
  }
}
function withAuthHeaders(headers) {
  const token = getAuthToken();
  const merged = new Headers(headers || {});
  if (token) {
    merged.set("Authorization", `Bearer ${token}`);
  } else {
    const gid = getGuestId();
    if (gid) merged.set("X-Prospekt-Guest-Id", gid);
  }
  return merged;
}
function getCachedUser() {
  return _cachedUser;
}
function setCachedUser(user) {
  _cachedUser = user;
}
async function getAuthMe() {
  if (_cachedUserPromise) {
    return _cachedUserPromise;
  }
  if (!getStoredAuthToken()) {
    _cachedUser = null;
    return null;
  }
  _cachedUserPromise = (async () => {
    try {
      const res = await fetchApi(apiUrl("/auth/me"), {
        credentials: requestCredentials()
      });
      if (res.ok) {
        const data = await res.json();
        const user = {
          email: data.email,
          name: data.name || "Researcher",
          mobile: data.mobile,
          require_mobile: data.require_mobile,
          email_verified: data.email_verified,
          plan: data.plan || "free"
        };
        _cachedUser = user;
        return user;
      }
      return null;
    } catch (err) {
      return null;
    } finally {
      _cachedUserPromise = null;
    }
  })();
  return _cachedUserPromise;
}
function handleAuthFailure() {
  const token = getAuthToken();
  if (!token) return;
  _cachedUser = null;
  setAuthToken(null);
  if (typeof window !== "undefined") {
    window.location.href = "/dashboard/overview";
  }
}
async function fetchApi(url, options) {
  const headers = buildTelemetryHeaders(options?.headers);
  const requestId = getTelemetryRequestId(headers) || void 0;
  const startMs = typeof performance !== "undefined" ? performance.now() : Date.now();
  const res = await fetch(url, {
    ...options || {},
    headers: withAuthHeaders(headers),
    credentials: resolveRequestCredentials(options)
  });
  recordDependency(url, options, startMs, res, requestId);
  if (res.status === 401) {
    handleAuthFailure();
  }
  return res;
}
async function parseJsonSanitized(res) {
  const payload = await res.json();
  return sanitizeMojibakeValue(payload);
}
async function apiLogin(email, password, remember = true) {
  const res = await fetchWithTimeout(
    apiUrl("/auth/login"),
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ email, password, remember })
    },
    AUTH_REQUEST_TIMEOUT_MS,
    "Login is taking too long. Please try again in a moment."
  );
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.detail || `Login failed: ${res.statusText}`);
  }
  const data = await res.json();
  if (data.token) {
    setAuthToken(data.token, remember);
  }
  if (data.user) {
    _cachedUser = {
      email: data.user?.email || email,
      name: data.user?.name || "Researcher",
      email_verified: data.user?.email_verified
    };
  }
  return data;
}
async function apiSignup(name, email, password, mobile, verificationCode) {
  const res = await fetchWithTimeout(
    apiUrl("/auth/signup"),
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        name,
        email,
        password,
        mobile,
        verification_code: verificationCode || void 0
      })
    },
    AUTH_REQUEST_TIMEOUT_MS,
    "Signup is taking too long. Please try again in a moment."
  );
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.detail || `Signup failed: ${res.statusText}`);
  }
  const data = await res.json();
  if (data.token) {
    setAuthToken(data.token, true);
  }
  if (data.user) {
    _cachedUser = {
      email: data.user?.email || email,
      name: data.user?.name || name,
      email_verified: data.user?.email_verified
    };
  }
  return data;
}
async function apiSendVerification(email) {
  const res = await fetchWithTimeout(
    apiUrl("/auth/send-verification"),
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ email })
    },
    AUTH_REQUEST_TIMEOUT_MS,
    "Verification email is taking too long. Please try again in a moment."
  );
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.detail || `Failed to send verification: ${res.statusText}`);
  }
  return res.json();
}
async function apiForgotPassword(email) {
  const res = await fetchWithTimeout(
    apiUrl("/auth/forgot-password"),
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ email })
    },
    AUTH_REQUEST_TIMEOUT_MS,
    "Password reset email is taking too long. Please try again in a moment."
  );
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.detail || `Failed to send reset code: ${res.statusText}`);
  }
  return res.json();
}
async function apiResetPassword(email, code, newPassword) {
  const res = await fetchWithTimeout(
    apiUrl("/auth/reset-password"),
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ email, code, new_password: newPassword })
    },
    AUTH_REQUEST_TIMEOUT_MS,
    "Password reset is taking too long. Please try again in a moment."
  );
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.detail || `Failed to reset password: ${res.statusText}`);
  }
  return res.json();
}
async function apiGoogleAuth(credential) {
  const res = await fetchWithTimeout(
    apiUrl("/auth/google"),
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ credential })
    },
    AUTH_REQUEST_TIMEOUT_MS,
    "Google sign-in is taking too long. Please try again in a moment."
  );
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.detail || `Google Auth failed: ${res.statusText}`);
  }
  const data = await res.json();
  if (data.token) {
    setAuthToken(data.token, true);
  }
  if (data.email) {
    _cachedUser = {
      email: data.email,
      name: data.name || data.full_name || "Researcher",
      mobile: data.mobile,
      require_mobile: data.require_mobile
    };
  }
  return data;
}
async function apiUpdateMobile(mobile) {
  const res = await fetchApi(apiUrl("/auth/google/update-mobile"), {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    credentials: "include",
    body: JSON.stringify({ mobile })
  });
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.detail || `Failed to update mobile: ${res.statusText}`);
  }
  if (_cachedUser) {
    _cachedUser = { ..._cachedUser, mobile, require_mobile: false };
  }
  return res.json();
}
async function apiLogout() {
  await fetchApi(apiUrl("/auth/logout"), {
    method: "POST"
  }).catch(() => {
  });
  _cachedUser = null;
  setAuthToken(null);
}
async function getPortfolioMirror() {
  const res = await fetchWithTimeout(
    apiUrl("/portfolio/mirror"),
    {
      credentials: "include"
    },
    MIRROR_STATUS_TIMEOUT_MS,
    "Portfolio status check timed out."
  );
  if (res.status === 401) {
    handleAuthFailure();
  }
  if (!res.ok) {
    throw new Error(`Failed to load portfolio mirror: ${res.statusText}`);
  }
  return parseJsonSanitized(res);
}
async function replacePortfolioMirror(positions) {
  trackEvent("portfolio_mirror_replace_requested", {
    source: "frontend",
    position_count: positions.length
  });
  const res = await fetchApi(apiUrl("/portfolio/mirror"), {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    credentials: "include",
    body: JSON.stringify({ positions })
  });
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    trackEvent("portfolio_mirror_replace_failed", {
      source: "frontend",
      position_count: positions.length,
      status_code: res.status
    });
    throw new Error(errorData.detail?.message || errorData.detail || `Failed to replace portfolio mirror: ${res.statusText}`);
  }
  const result = await parseJsonSanitized(res);
  trackEvent("portfolio_mirror_replace_completed", {
    source: "frontend",
    position_count: positions.length
  });
  return result;
}
async function syncManualPortfolio(positions) {
  trackEvent("portfolio_manual_sync_requested", {
    source: "frontend",
    position_count: positions.length
  });
  const res = await fetchApi(apiUrl("/portfolio/mirror/sync-manual"), {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    credentials: "include",
    body: JSON.stringify({ positions })
  });
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    trackEvent("portfolio_manual_sync_failed", {
      source: "frontend",
      position_count: positions.length,
      status_code: res.status
    });
    throw new Error(errorData.detail?.message || errorData.detail || `Failed to sync manual portfolio: ${res.statusText}`);
  }
  const result = await parseJsonSanitized(res);
  trackEvent("portfolio_manual_sync_completed", {
    source: "frontend",
    position_count: positions.length
  });
  return result;
}
async function uploadPortfolioDocument(file, password) {
  trackEvent("portfolio_upload_requested", {
    source: "frontend",
    upload_type: "document",
    file_name: file.name,
    file_size_bytes: file.size,
    has_password: Boolean(password)
  });
  const formData = new FormData();
  formData.append("file", file);
  if (password) {
    formData.append("password", password);
  }
  const res = await fetchWithTimeout(
    apiUrl("/api/portfolio/upload-cas"),
    {
      method: "POST",
      credentials: "include",
      body: formData
    },
    DOCUMENT_UPLOAD_TIMEOUT_MS,
    "Document upload timed out. Try a broker CSV/XLSX export or a clear screenshot."
  );
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    trackEvent("portfolio_upload_failed", {
      source: "frontend",
      upload_type: "document",
      file_name: file.name,
      status_code: res.status
    });
    throw new Error(errorData.detail?.message || errorData.detail || `Failed to parse document: ${res.statusText}`);
  }
  const result = await parseJsonSanitized(res);
  trackEvent("portfolio_upload_completed", {
    source: "frontend",
    upload_type: "document",
    file_name: file.name,
    result_code: result?.code || result?.status || "unknown"
  });
  return result;
}
async function uploadPortfolioScreenshot(file) {
  trackEvent("portfolio_upload_requested", {
    source: "frontend",
    upload_type: "screenshot",
    file_name: file.name,
    file_size_bytes: file.size
  });
  const formData = new FormData();
  formData.append("file", file);
  const res = await fetchWithTimeout(
    apiUrl("/api/portfolio/upload-screenshot"),
    {
      method: "POST",
      credentials: "include",
      body: formData
    },
    SCREENSHOT_UPLOAD_TIMEOUT_MS,
    "Screenshot upload timed out. Try a smaller, clearer image or a broker CSV/XLSX export."
  );
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    trackEvent("portfolio_upload_failed", {
      source: "frontend",
      upload_type: "screenshot",
      file_name: file.name,
      status_code: res.status
    });
    throw new Error(errorData.detail?.message || errorData.detail || `Failed to parse screenshot: ${res.statusText}`);
  }
  const result = await parseJsonSanitized(res);
  trackEvent("portfolio_upload_completed", {
    source: "frontend",
    upload_type: "screenshot",
    file_name: file.name,
    result_code: result?.code || result?.status || "unknown"
  });
  return result;
}
async function confirmExtraction(reviewId, positions, sourceType, reviewToken) {
  trackEvent("portfolio_extraction_confirm_requested", {
    source: "frontend",
    review_id: reviewId,
    source_type: sourceType || "unknown",
    position_count: positions?.length || 0
  });
  const res = await fetchApi(apiUrl("/api/portfolio/confirm-extraction"), {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    credentials: "include",
    body: JSON.stringify({
      review_id: reviewId,
      positions,
      source_type: sourceType,
      review_token: reviewToken || void 0
    })
  });
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    trackEvent("portfolio_extraction_confirm_failed", {
      source: "frontend",
      review_id: reviewId,
      status_code: res.status
    });
    throw new Error(errorData.detail?.message || errorData.detail || `Failed to confirm extraction: ${res.statusText}`);
  }
  const result = await parseJsonSanitized(res);
  trackEvent("portfolio_extraction_confirm_completed", {
    source: "frontend",
    review_id: reviewId,
    source_type: sourceType || "unknown"
  });
  return result;
}
async function cancelExtraction() {
  trackEvent("portfolio_extraction_cancel_requested", {
    source: "frontend"
  });
  const res = await fetchApi(apiUrl("/api/portfolio/cancel-extraction"), {
    method: "POST",
    credentials: "include"
  });
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    trackEvent("portfolio_extraction_cancel_failed", {
      source: "frontend",
      status_code: res.status
    });
    throw new Error(errorData.detail || `Failed to cancel extraction: ${res.statusText}`);
  }
  const result = await parseJsonSanitized(res);
  trackEvent("portfolio_extraction_cancel_completed", {
    source: "frontend"
  });
  return result;
}
async function getPortfolioAnalytics(benchmark = "NIFTY50", period = "1y") {
  const res = await fetchApi(apiUrl(`/portfolio/analytics?benchmark=${encodeURIComponent(benchmark)}&period=${encodeURIComponent(period)}`), {
    credentials: "include"
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch portfolio analytics: ${res.statusText}`);
  }
  return parseJsonSanitized(res);
}
async function deletePortfolioMirror() {
  const res = await fetchApi(apiUrl("/portfolio/mirror"), {
    method: "DELETE",
    credentials: "include"
  });
  if (!res.ok) {
    throw new Error(`Failed to clear portfolio: ${res.statusText}`);
  }
  return parseJsonSanitized(res);
}
async function getPortfolioNews(limit = 12) {
  const res = await fetchApi(apiUrl(`/portfolio/news?limit=${limit}`), {
    credentials: "include"
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch portfolio news: ${res.statusText}`);
  }
  return parseJsonSanitized(res);
}
async function getPortfolioSectors() {
  const res = await fetchApi(apiUrl("/portfolio/sectors"), {
    credentials: "include"
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch portfolio sectors: ${res.statusText}`);
  }
  return parseJsonSanitized(res);
}
async function getPortfolioGovernance() {
  const res = await fetchApi(apiUrl("/portfolio/governance"), { credentials: "include" });
  if (!res.ok) {
    throw new Error(`Failed to fetch portfolio governance: ${res.statusText}`);
  }
  return res.json();
}
async function getCompanyGovernance(cin) {
  const res = await fetchApi(apiUrl(`/company/${encodeURIComponent(cin)}/governance`), {
    credentials: "include"
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch company governance: ${res.statusText}`);
  }
  return res.json();
}
async function getCompanyNetwork(cin) {
  const res = await fetchApi(apiUrl(`/company/${encodeURIComponent(cin)}/network`), {
    credentials: "include"
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch company network: ${res.statusText}`);
  }
  return res.json();
}
async function getCompanyProvenance(cin) {
  const res = await fetchApi(apiUrl(`/company/${encodeURIComponent(cin)}/provenance`), {
    credentials: "include"
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch provenance: ${res.statusText}`);
  }
  return res.json();
}
async function getCompanyHealth(cin) {
  const res = await fetchApi(apiUrl(`/company/${encodeURIComponent(cin)}/health`), {
    credentials: "include"
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch company health: ${res.statusText}`);
  }
  return res.json();
}
async function triageFilings(filings) {
  const res = await fetchApi(apiUrl("/filings/triage"), {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ filings })
  });
  if (!res.ok) {
    throw new Error(`Failed to triage filings: ${res.statusText}`);
  }
  return res.json();
}
async function getHoldingDetail(symbol) {
  const res = await fetchApi(apiUrl(`/portfolio/holding/${encodeURIComponent(symbol)}`), {
    credentials: "include"
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch holding detail: ${res.statusText}`);
  }
  return res.json();
}
async function getCorporateActions(days = 30) {
  const res = await fetchApi(apiUrl(`/portfolio/corporate-actions?days=${days}`), {
    credentials: "include"
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch corporate actions: ${res.statusText}`);
  }
  return res.json();
}
async function getPortfolioAlerts() {
  const res = await fetchApi(apiUrl("/portfolio/alerts"), {
    credentials: "include"
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch portfolio alerts: ${res.statusText}`);
  }
  return res.json();
}
async function getTaxSummary() {
  const res = await fetchApi(apiUrl("/portfolio/tax-summary"), {
    credentials: "include"
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch tax summary: ${res.statusText}`);
  }
  return res.json();
}
async function getDividends() {
  const res = await fetchApi(apiUrl("/portfolio/dividends"), {
    credentials: "include"
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch dividends: ${res.statusText}`);
  }
  return res.json();
}
async function postStressTest(scenario, customShocks) {
  const res = await fetchApi(apiUrl("/portfolio/stress-test"), {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    credentials: "include",
    body: JSON.stringify({ scenario, custom_shocks: customShocks })
  });
  if (!res.ok) {
    throw new Error(`Failed to run stress test: ${res.statusText}`);
  }
  return res.json();
}
async function getMfAnalytics() {
  const res = await fetchApi(apiUrl("/portfolio/mf-analytics"), {
    credentials: "include"
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch MF analytics: ${res.statusText}`);
  }
  return res.json();
}
async function getTodayQueue() {
  const res = await fetchApi(apiUrl("/portfolio/today"), {
    credentials: "include"
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch action queue: ${res.statusText}`);
  }
  return res.json();
}
async function getPortfolioBrief() {
  const res = await fetchApi(apiUrl("/portfolio/brief"), {
    credentials: "include"
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch portfolio brief: ${res.statusText}`);
  }
  return res.json();
}
async function getPortfolioCommentary() {
  const res = await fetchApi(apiUrl("/portfolio/commentary"), {
    credentials: "include"
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch portfolio commentary: ${res.statusText}`);
  }
  return res.json();
}
async function startResearch(message, mode, portfolioContext) {
  const rewrittenMessage = portfolioContext ? `${portfolioContext} ${message}` : message;
  const apiMode = mode === "standard" ? "chat" : "deep";
  const payload = {
    // Keep a clean user query for portfolio-scope routing and target detection.
    target: message,
    // Keep enriched context for synthesis quality.
    message: rewrittenMessage,
    mode: apiMode
  };
  trackEvent("research_start_requested", {
    source: "frontend",
    mode,
    backend_mode: apiMode,
    has_portfolio_context: Boolean(portfolioContext),
    message_length: message.length
  });
  const res = await fetchWithTimeout(
    apiUrl("/chat/research"),
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      credentials: "include",
      body: JSON.stringify(payload)
    },
    CHAT_START_TIMEOUT_MS,
    "Starting the analysis is taking too long. Please try again."
  );
  if (!res.ok) {
    if (res.status === 401) {
      handleAuthFailure();
    }
    const errorData = await res.json().catch(() => ({}));
    trackEvent("research_start_failed", {
      source: "frontend",
      mode,
      status_code: res.status
    });
    const err = new Error(errorData.detail?.message || errorData.detail || `Failed to start research: ${res.statusText}`);
    err.detail = errorData.detail;
    throw err;
  }
  const result = await res.json();
  trackEvent("research_start_accepted", {
    source: "frontend",
    mode,
    session_id: result?.session_id || ""
  });
  return result;
}
async function stopSession(sessionId2) {
  trackEvent("research_stop_requested", {
    source: "frontend",
    session_id: sessionId2
  });
  const res = await fetchApi(apiUrl(`/sessions/${encodeURIComponent(sessionId2)}/stop`), {
    method: "POST",
    credentials: "include"
  });
  if (!res.ok) {
    trackEvent("research_stop_failed", {
      source: "frontend",
      session_id: sessionId2,
      status_code: res.status
    });
    throw new Error(`Failed to stop research session: ${res.statusText}`);
  }
  const result = await res.json();
  trackEvent("research_stop_completed", {
    source: "frontend",
    session_id: sessionId2
  });
  return result;
}
async function getSessionResult(sessionId2) {
  trackEvent("research_result_requested", {
    source: "frontend",
    session_id: sessionId2
  });
  const res = await fetchApi(apiUrl(`/sessions/${encodeURIComponent(sessionId2)}/result`), {
    credentials: "include"
  });
  if (!res.ok) {
    trackEvent("research_result_failed", {
      source: "frontend",
      session_id: sessionId2,
      status_code: res.status
    });
    throw new Error(`Failed to fetch session result: ${res.statusText}`);
  }
  const result = await res.json();
  trackEvent("research_result_received", {
    source: "frontend",
    session_id: sessionId2,
    status: result?.status || "unknown"
  });
  return result;
}
function streamSession(sessionId2, onEvent, onFinal, onError) {
  const MAX_RECONNECT_ATTEMPTS = 12;
  const MAX_STREAM_DURATION_MS = 12 * 6e4;
  const streamStartedAt = Date.now();
  let lastEventId = null;
  let sseAbort = new AbortController();
  let sseReconnectTimer = null;
  let sseActive = true;
  let onFinalCalled = false;
  let onErrorCalled = false;
  let reconnectAttempts = 0;
  const closeStream = () => {
    if (sseActive) {
      sseActive = false;
      clearTimeout(sseReconnectTimer);
      sseAbort.abort();
    }
  };
  function scheduleReconnect(delayMs = 1500) {
    if (!sseActive || onFinalCalled || onErrorCalled) return;
    reconnectAttempts += 1;
    if (reconnectAttempts > MAX_RECONNECT_ATTEMPTS) {
      closeStream();
      void finalizeFromResult();
      return;
    }
    clearTimeout(sseReconnectTimer);
    sseReconnectTimer = setTimeout(connectSSE, delayMs);
  }
  async function finalizeFromResult() {
    if (onFinalCalled || onErrorCalled) return;
    try {
      const result = await getSessionResult(sessionId2);
      const status = String(result.status || "").toLowerCase();
      const hasDeliverableMemo = Boolean(
        result.memo || result.final?.memo || result.final?.memo_preview || result.memo_event?.preview
      );
      const errorPayload = result.error;
      const errorMessage = typeof errorPayload === "string" ? errorPayload : errorPayload?.message || errorPayload?.payload?.message || null;
      if (errorMessage || result.status === "error") {
        if (!onErrorCalled) {
          onErrorCalled = true;
          onError(new Error(errorMessage || "Research failed"));
        }
        return;
      }
      if (!hasDeliverableMemo && status !== "done") {
        if (!sseActive) {
          if (!onErrorCalled) {
            onErrorCalled = true;
            onError(new Error("Research timed out before a final answer was available."));
          }
          return;
        }
        trackEvent("research_stream_waiting_for_result", {
          source: "frontend",
          session_id: sessionId2,
          status: status || "unknown"
        });
        scheduleReconnect();
        return;
      }
      if (!onFinalCalled) {
        onFinalCalled = true;
        onFinal(result.final || result);
      }
    } catch (err) {
      if (!onErrorCalled) {
        onErrorCalled = true;
        onError(err instanceof Error ? err : new Error("Failed to retrieve session result"));
      }
    }
  }
  function handleTerminalEvent(evType, evData) {
    if (evType === "final") {
      try {
        const parsed = JSON.parse(evData);
        closeStream();
        trackEvent("research_stream_final", {
          source: "frontend",
          session_id: sessionId2
        });
        if (!onFinalCalled) {
          onFinalCalled = true;
          onFinal(parsed);
        }
      } catch (err) {
        console.error("Failed to parse final event data", err);
        void finalizeFromResult();
      }
      return;
    }
    if (evType === "error") {
      try {
        const parsed = JSON.parse(evData);
        closeStream();
        trackEvent("research_stream_error", {
          source: "frontend",
          session_id: sessionId2,
          phase: "stream_error_event",
          message: parsed.message || "unknown"
        });
        if (!onErrorCalled) {
          onErrorCalled = true;
          onError(new Error(parsed.message || "Stream processing error"));
        }
      } catch (err) {
        closeStream();
        trackEvent("research_stream_error", {
          source: "frontend",
          session_id: sessionId2,
          phase: "stream_error_event"
        });
        if (!onErrorCalled) {
          onErrorCalled = true;
          onError(new Error("Stream encountered an error"));
        }
      }
      return;
    }
    if (evType === "done" || evType === "deep_complete") {
      closeStream();
      trackEvent("research_stream_completed", {
        source: "frontend",
        session_id: sessionId2,
        phase: evType
      });
      void finalizeFromResult();
    }
  }
  async function connectSSE() {
    if (!sseActive) return;
    if (Date.now() - streamStartedAt > MAX_STREAM_DURATION_MS) {
      closeStream();
      void finalizeFromResult();
      return;
    }
    sseAbort = new AbortController();
    clearTimeout(sseReconnectTimer);
    sseReconnectTimer = setTimeout(() => {
      if (sseActive) {
        console.info("SSE: proactive reconnect (25s window)");
        sseAbort.abort();
        connectSSE();
      }
    }, 25e3);
    const headers = {
      "Accept": "text/event-stream",
      "Cache-Control": "no-cache"
    };
    const telemetryHeaders = buildTelemetryHeaders(headers);
    const requestId = getTelemetryRequestId(telemetryHeaders) || void 0;
    const token = getAuthToken();
    if (token) {
      telemetryHeaders.set?.("Authorization", `Bearer ${token}`);
    }
    if (lastEventId !== null) {
      telemetryHeaders.set?.("Last-Event-ID", String(lastEventId));
    }
    const path = `/sessions/${encodeURIComponent(sessionId2)}/stream`;
    let url = apiUrl(path);
    if (lastEventId !== null) {
      url += (url.includes("?") ? "&" : "?") + "after=" + encodeURIComponent(lastEventId);
    }
    const startMs = typeof performance !== "undefined" ? performance.now() : Date.now();
    let resp;
    try {
      resp = await fetch(url, {
        headers: withAuthHeaders(telemetryHeaders),
        signal: sseAbort.signal,
        credentials: requestCredentials()
      });
    } catch (err) {
      if (!sseActive) return;
      if (err && err.name === "AbortError") return;
      trackDependency({
        name: `GET ${path}`,
        url,
        method: "GET",
        durationMs: (typeof performance !== "undefined" ? performance.now() : Date.now()) - startMs,
        success: false,
        requestId,
        properties: {
          source: "frontend",
          session_id: sessionId2,
          phase: "stream_connect",
          error_type: err?.name || "Error"
        }
      });
      trackEvent("research_stream_error", {
        source: "frontend",
        session_id: sessionId2,
        phase: "connect"
      });
      console.warn("SSE fetch error, retrying in 2s:", err);
      clearTimeout(sseReconnectTimer);
      sseReconnectTimer = setTimeout(connectSSE, 2e3);
      return;
    }
    trackDependency({
      name: `GET ${path}`,
      url,
      method: "GET",
      durationMs: (typeof performance !== "undefined" ? performance.now() : Date.now()) - startMs,
      success: resp.ok,
      statusCode: resp.status,
      requestId,
      properties: {
        source: "frontend",
        session_id: sessionId2,
        phase: "stream_connect"
      }
    });
    if (!resp.ok) {
      if (!sseActive) return;
      if (resp.status === 404) {
        closeStream();
        void finalizeFromResult();
        return;
      }
      trackEvent("research_stream_error", {
        source: "frontend",
        session_id: sessionId2,
        phase: "http_error",
        status_code: resp.status
      });
      console.warn("SSE HTTP error status:", resp.status, "\xE2\u20AC\u201D retrying in 3s");
      clearTimeout(sseReconnectTimer);
      sseReconnectTimer = setTimeout(connectSSE, 3e3);
      return;
    }
    trackEvent("research_stream_connected", {
      source: "frontend",
      session_id: sessionId2,
      resumed: String(lastEventId !== null)
    });
    reconnectAttempts = 0;
    const reader = resp.body?.getReader();
    if (!reader) {
      console.error("SSE response body is not readable");
      if (!onErrorCalled) {
        onErrorCalled = true;
        onError(new Error("Response body is not readable"));
      }
      return;
    }
    const decoder = new TextDecoder();
    let buf = "";
    let streamEnded = false;
    try {
      for (; ; ) {
        const { done, value } = await reader.read();
        if (done) {
          streamEnded = true;
          break;
        }
        buf += decoder.decode(value, { stream: true });
        let boundary;
        while ((boundary = buf.indexOf("\n\n")) !== -1) {
          const block = buf.slice(0, boundary);
          buf = buf.slice(boundary + 2);
          if (!block.trim() || block.startsWith(":")) continue;
          let evType = "message";
          let evData = "";
          let evId = null;
          for (const line of block.split("\n")) {
            if (line.startsWith("event:")) {
              evType = line.slice(6).trim();
            } else if (line.startsWith("data:")) {
              evData = line.slice(5).trim();
            } else if (line.startsWith("id:")) {
              evId = line.slice(3).trim();
            }
          }
          if (evId !== null) {
            const parsedId = parseInt(evId, 10);
            if (!isNaN(parsedId)) {
              lastEventId = parsedId;
            }
          }
          if (evType === "final" || evType === "error" || evType === "done" || evType === "deep_complete") {
            handleTerminalEvent(evType, evData);
            continue;
          }
          try {
            const parsed = JSON.parse(evData);
            onEvent({
              seq: parsed.id || (evId ? parseInt(evId, 10) : 0),
              type: evType,
              timestamp: parsed.timestamp || "",
              payload: parsed
            });
          } catch (err) {
            console.error(`Failed to parse ${evType} event data`, err);
          }
        }
      }
      if (sseActive && !onFinalCalled && !onErrorCalled) {
        scheduleReconnect(1e3);
      }
    } catch (err) {
      if (!sseActive) return;
      if (err && err.name === "AbortError") return;
      console.warn("SSE read error, retrying in 2s:", err);
      clearTimeout(sseReconnectTimer);
      sseReconnectTimer = setTimeout(connectSSE, 2e3);
      return;
    }
    if (streamEnded && sseActive && !onFinalCalled && !onErrorCalled) {
      void finalizeFromResult();
    }
  }
  connectSSE();
  return () => {
    closeStream();
  };
}
async function getUserTokenUsage() {
  const res = await fetchApi(apiUrl("/user/token-usage"), {
    credentials: "include"
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch user token usage: ${res.statusText}`);
  }
  return res.json();
}
async function getUserSubscription() {
  const res = await fetchApi(apiUrl("/user/subscription"), {
    credentials: "include"
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch subscription: ${res.statusText}`);
  }
  return res.json();
}
async function createRazorpayOrder(amountPaise, currency = "INR", plan = "pro") {
  const res = await fetchApi(apiUrl("/api/create-order"), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify({ amount: amountPaise, currency, plan })
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    const error = new Error(err.detail || `Failed to create order: ${res.statusText}`);
    error.status = res.status;
    throw error;
  }
  return res.json();
}
async function verifyRazorpayPayment(razorpay_order_id, razorpay_payment_id, razorpay_signature) {
  const res = await fetchApi(apiUrl("/api/verify-payment"), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify({ razorpay_order_id, razorpay_payment_id, razorpay_signature })
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    const error = new Error(err.detail || `Payment verification failed: ${res.statusText}`);
    error.status = res.status;
    throw error;
  }
  return res.json();
}
async function getMarketQuotes(symbols) {
  const res = await fetchWithTimeout(
    apiUrl(`/market/quotes?symbols=${encodeURIComponent(symbols.join(","))}`),
    { credentials: "include" },
    12e3,
    "Market quotes request timed out. Please retry."
  );
  if (!res.ok) {
    throw new Error(`Failed to fetch market quotes: ${res.statusText}`);
  }
  return parseJsonSanitized(res);
}
async function getMarketNews(query, limit = 10, includeImages = false) {
  const params = new URLSearchParams();
  if (query) params.set("query", query);
  params.set("limit", String(Math.max(1, Math.min(60, Number(limit) || 10))));
  params.set("images", includeImages ? "1" : "0");
  const qStr = params.toString();
  const res = await fetchWithTimeout(
    apiUrl(`/market/news${qStr ? `?${qStr}` : ""}`),
    { credentials: "include" },
    12e3,
    "Market news request timed out. Please retry."
  );
  if (!res.ok) {
    throw new Error(`Failed to fetch market news: ${res.statusText}`);
  }
  return parseJsonSanitized(res);
}
async function getMarketIndices() {
  const res = await fetchWithTimeout(
    apiUrl("/market/indices"),
    { credentials: "include" },
    2e4,
    "Market indices request timed out. Please retry."
  );
  if (!res.ok) {
    throw new Error(`Failed to fetch market indices: ${res.statusText}`);
  }
  return parseJsonSanitized(res);
}
async function getMarketHistory(symbol, period, assetType) {
  const params = new URLSearchParams({
    symbol,
    period
  });
  if (assetType) params.set("asset_type", assetType);
  const res = await fetchApi(apiUrl(`/market/history?${params.toString()}`), {
    credentials: "include"
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `Failed to fetch market history: ${res.statusText}`);
  }
  return parseJsonSanitized(res);
}
async function getWatchlistSnapshot(symbols, period = "1M") {
  const params = new URLSearchParams({
    symbols: symbols.join(","),
    period
  });
  const res = await fetchWithTimeout(
    apiUrl(`/watchlist/snapshot?${params.toString()}`),
    { credentials: "include" },
    15e3,
    "Watchlist snapshot timed out. Showing available live quotes."
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `Failed to fetch watchlist snapshot: ${res.statusText}`);
  }
  return parseJsonSanitized(res);
}
async function screenerSearch(query, limit = 8) {
  const params = new URLSearchParams({
    q: query,
    limit: String(limit)
  });
  const res = await fetchWithTimeout(
    apiUrl(`/screener/search?${params.toString()}`),
    { credentials: "include" },
    8e3,
    "Screener search timed out. Please retry."
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `Failed to search screener universe: ${res.statusText}`);
  }
  return parseJsonSanitized(res);
}
async function getScreenerSnapshot(identifier, period = "1Y") {
  const params = new URLSearchParams({ period });
  const res = await fetchWithTimeout(
    apiUrl(`/screener/company/${encodeURIComponent(identifier)}/snapshot?${params.toString()}`),
    { credentials: "include" },
    15e3,
    "Screener snapshot timed out. Showing cached data if available."
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `Failed to load screener snapshot: ${res.statusText}`);
  }
  return parseJsonSanitized(res);
}
async function getScreenerFinancials(identifier) {
  const res = await fetchWithTimeout(
    apiUrl(`/screener/company/${encodeURIComponent(identifier)}/financials`),
    { credentials: "include" },
    18e3,
    "Screener financials timed out. Try refreshing this section."
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `Failed to load screener financials: ${res.statusText}`);
  }
  return parseJsonSanitized(res);
}
async function getScreenerTechnicals(identifier, period = "1Y") {
  const params = new URLSearchParams({ period });
  const res = await fetchWithTimeout(
    apiUrl(`/screener/company/${encodeURIComponent(identifier)}/technicals?${params.toString()}`),
    { credentials: "include" },
    12e3,
    "Screener technicals timed out. Please retry."
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `Failed to load screener technicals: ${res.statusText}`);
  }
  return parseJsonSanitized(res);
}
async function getScreenerEvents(identifier, limit = 25) {
  const params = new URLSearchParams({ limit: String(limit) });
  const res = await fetchWithTimeout(
    apiUrl(`/screener/company/${encodeURIComponent(identifier)}/events?${params.toString()}`),
    { credentials: "include" },
    12e3,
    "Screener events timed out. Please retry."
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `Failed to load screener events: ${res.statusText}`);
  }
  return parseJsonSanitized(res);
}
async function getScreenerAnalysis(identifier) {
  const res = await fetchWithTimeout(
    apiUrl(`/screener/company/${encodeURIComponent(identifier)}/analyze`),
    { credentials: "include" },
    25e3,
    "Screener analysis is still loading. Please retry in a moment."
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `Failed to load screener analysis: ${res.statusText}`);
  }
  return parseJsonSanitized(res);
}
async function runScreenerQuery(query, limit = 25, universe = []) {
  const res = await fetchWithTimeout(
    apiUrl("/screener/query"),
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ query, limit, universe })
    },
    15e3,
    "Screener query timed out. Please try a narrower query."
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `Failed to run screener query: ${res.statusText}`);
  }
  return parseJsonSanitized(res);
}
async function generateFlashArticle(req) {
  const res = await fetchApi(apiUrl("/api/content/flash/generate"), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(req),
    credentials: "include"
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `Flash generation failed: ${res.statusText}`);
  }
  return res.json();
}
async function ingestFlashEvents(req) {
  const res = await fetchApi(apiUrl("/api/content/flash/ingest-events"), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(req),
    credentials: "include"
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `Ingest failed: ${res.statusText}`);
  }
  return res.json();
}
async function getContentAutomationStatus() {
  const res = await fetchApi(apiUrl("/api/content/automation/status"), {
    credentials: "include"
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch automation status: ${res.statusText}`);
  }
  return res.json();
}
async function runContentAutomationNow() {
  const res = await fetchApi(apiUrl("/api/content/automation/run-now"), {
    method: "POST",
    credentials: "include"
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `Failed to start automation sweep: ${res.statusText}`);
  }
  return res.json();
}
async function listContentArticles(routeBase, limit = 80) {
  const params = new URLSearchParams();
  if (routeBase) params.set("route_base", routeBase);
  params.set("limit", String(limit));
  const res = await fetchApi(apiUrl(`/api/content/articles?${params.toString()}`), {
    credentials: "include"
  });
  if (!res.ok) throw new Error(`Failed to list articles: ${res.statusText}`);
  return parseJsonSanitized(res);
}
async function getContentArticle(slug, routeBase = "insights") {
  const res = await fetchApi(
    apiUrl(`/api/content/articles/${encodeURIComponent(slug)}?route_base=${routeBase}`),
    { credentials: "include" }
  );
  if (!res.ok) throw new Error(`Article not found: ${slug}`);
  return parseJsonSanitized(res);
}
async function getContentArticleHtml(slug, routeBase = "insights") {
  const res = await fetchApi(
    apiUrl(`/api/content/articles/${encodeURIComponent(slug)}/html?route_base=${routeBase}`),
    { credentials: "include" }
  );
  if (!res.ok) throw new Error(`Article HTML not found: ${slug}`);
  return res.text();
}
async function publishContentArticle(slug, routeBase = "insights") {
  const res = await fetchApi(
    apiUrl(`/api/content/articles/${encodeURIComponent(slug)}/publish?route_base=${routeBase}`),
    { method: "POST", credentials: "include" }
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `Publish failed: ${res.statusText}`);
  }
  return res.json();
}
async function unpublishContentArticle(slug, routeBase = "insights") {
  const res = await fetchApi(
    apiUrl(`/api/content/articles/${encodeURIComponent(slug)}/unpublish?route_base=${routeBase}`),
    { method: "POST", credentials: "include" }
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `Unpublish failed: ${res.statusText}`);
  }
  return res.json();
}
function flashJobStreamUrl(jobId) {
  return apiUrl(`/sessions/${encodeURIComponent(jobId)}/stream`);
}
function flashJobStatusUrl(jobId) {
  return apiUrl(`/sessions/${encodeURIComponent(jobId)}/status`);
}
async function requestExport(sessionId2, format, style = "sell_side") {
  const res = await fetchApi(apiUrl("/research/export"), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify({ session_id: sessionId2, format, style })
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `Export request failed: ${res.statusText}`);
  }
  return res.json();
}
async function pollExport(jobId) {
  const res = await fetchApi(apiUrl(`/research/export/${encodeURIComponent(jobId)}`), {
    credentials: "include"
  });
  if (!res.ok) throw new Error(`Export poll failed: ${res.statusText}`);
  return res.json();
}
async function downloadExport(jobId) {
  const res = await fetchApi(apiUrl(`/research/export/${encodeURIComponent(jobId)}/download`), {
    credentials: "include"
  });
  if (!res.ok) throw new Error(`Export download failed: ${res.statusText}`);
  return res.blob();
}
async function downloadExportAndSave(jobId, format) {
  const blob = await downloadExport(jobId);
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `prospektlab_report.${format}`;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 100);
}
async function getIpoPipeline() {
  const res = await fetchApi(apiUrl("/ipo/pipeline"), { credentials: "include" });
  if (!res.ok) throw new Error(`IPO pipeline fetch failed: ${res.statusText}`);
  return res.json();
}
async function getIpoAnalysis(slug) {
  const res = await fetchApi(apiUrl(`/ipo/${encodeURIComponent(slug)}`), { credentials: "include" });
  if (!res.ok) throw new Error(`IPO analysis fetch failed: ${res.statusText}`);
  return res.json();
}
async function getIpoAnalysisStatus(slug) {
  const res = await fetchApi(apiUrl(`/ipo/${encodeURIComponent(slug)}/status`), { credentials: "include" });
  if (!res.ok) throw new Error(`IPO status fetch failed: ${res.statusText}`);
  return res.json();
}
async function queueIpoAnalysis(slug, priority = false) {
  const params = priority ? "?priority=true" : "";
  const res = await fetchApi(apiUrl(`/ipo/${encodeURIComponent(slug)}/queue${params}`), {
    method: "POST",
    credentials: "include"
  });
  if (!res.ok) throw new Error(`IPO queue failed: ${res.statusText}`);
  return res.json();
}
async function getIpoTracking(slug) {
  const res = await fetchApi(apiUrl(`/ipo/${encodeURIComponent(slug)}/tracking`), { credentials: "include" });
  if (!res.ok) throw new Error(`IPO tracking fetch failed: ${res.statusText}`);
  return res.json();
}
async function searchIpos(query, limit = 10) {
  const params = new URLSearchParams({ q: query, limit: String(limit) });
  const res = await fetchApi(apiUrl(`/ipo/search?${params}`), { credentials: "include" });
  if (!res.ok) throw new Error(`IPO search failed: ${res.statusText}`);
  return res.json();
}
async function getIpoStats() {
  const res = await fetchApi(apiUrl("/ipo/stats"), { credentials: "include" });
  if (!res.ok) throw new Error(`IPO stats fetch failed: ${res.statusText}`);
  return res.json();
}
async function refreshIpoData() {
  const res = await fetchApi(apiUrl("/ipo/refresh-nse"), {
    method: "POST",
    credentials: "include"
  });
  if (!res.ok) throw new Error(`IPO refresh failed: ${res.statusText}`);
  return res.json();
}
async function runIpoWatcher(options) {
  const params = new URLSearchParams();
  if (options?.download !== void 0) params.append("download", String(options.download));
  if (options?.includeBse !== void 0) params.append("include_bse", String(options.includeBse));
  if (options?.batchProcess !== void 0) params.append("batch_process", String(options.batchProcess));
  const res = await fetchApi(apiUrl(`/ipo/watcher/run?${params}`), {
    method: "POST",
    credentials: "include"
  });
  if (!res.ok) throw new Error(`IPO watcher failed: ${res.statusText}`);
  return res.json();
}
async function analyzeIpo(slug) {
  const res = await fetchApi(apiUrl(`/ipo/${encodeURIComponent(slug)}/analyze`), {
    method: "POST",
    credentials: "include"
  });
  if (!res.ok) throw new Error(`IPO analysis trigger failed: ${res.statusText}`);
  return res.json();
}
async function getEarningsCalendar(startDate, endDate) {
  const params = new URLSearchParams({ start_date: startDate, end_date: endDate });
  let res;
  try {
    res = await fetchWithTimeout(
      apiUrl(`/earnings/calendar?${params.toString()}`),
      { credentials: "include" },
      25e3,
      "Earnings calendar timed out. Please retry."
    );
  } catch (err) {
    if (err?.name === "AbortError") throw err;
    const msg = err?.message || "";
    if (msg === "Failed to fetch" || msg.includes("NetworkError") || msg.includes("network")) {
      throw new Error("Could not connect to the earnings service. Please check your connection and retry.");
    }
    throw err;
  }
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `Failed to load earnings calendar: ${res.statusText}`);
  }
  return parseJsonSanitized(res);
}
async function getEarningsOverview(startDate, endDate, pageSize) {
  const params = new URLSearchParams({
    start_date: startDate,
    end_date: endDate,
    page_size: String(pageSize || 50)
  });
  let res;
  try {
    res = await fetchWithTimeout(
      apiUrl(`/earnings/overview?${params.toString()}`),
      { credentials: "include" },
      25e3,
      "Earnings overview timed out. Please retry."
    );
  } catch (err) {
    if (err?.name === "AbortError") throw err;
    const msg = err?.message || "";
    if (msg === "Failed to fetch" || msg.includes("NetworkError") || msg.includes("network")) {
      throw new Error("Could not connect to the earnings service. Please check your connection and retry.");
    }
    throw err;
  }
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `Failed to load earnings overview: ${res.statusText}`);
  }
  return parseJsonSanitized(res);
}
async function getEarningsCompanies(options) {
  const params = new URLSearchParams({
    index: options.index || "All",
    market_cap: options.marketCap || "All",
    sector: options.sector || "All",
    page: String(options.page || 1),
    page_size: String(options.pageSize || 25)
  });
  if (options.startDate && options.endDate) {
    params.set("start_date", options.startDate);
    params.set("end_date", options.endDate);
  } else if (options.date) {
    params.set("date", options.date);
  }
  let res;
  try {
    res = await fetchWithTimeout(
      apiUrl(`/earnings/companies?${params.toString()}`),
      { credentials: "include" },
      25e3,
      "Earnings companies request timed out. Please retry."
    );
  } catch (err) {
    if (err?.name === "AbortError") throw err;
    const msg = err?.message || "";
    if (msg === "Failed to fetch" || msg.includes("NetworkError") || msg.includes("network")) {
      throw new Error("Could not connect to the earnings service. Please check your connection and retry.");
    }
    throw err;
  }
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `Failed to load earnings companies: ${res.statusText}`);
  }
  return parseJsonSanitized(res);
}
async function getEarningsResult(symbol, date) {
  const params = new URLSearchParams({ date });
  let res;
  try {
    res = await fetchWithTimeout(
      apiUrl(`/earnings/result/${encodeURIComponent(symbol)}?${params.toString()}`),
      { credentials: "include" },
      6e4,
      "Earnings result request timed out. Please retry."
    );
  } catch (err) {
    if (err?.name === "AbortError") throw err;
    const msg = err?.message || "";
    if (msg === "Failed to fetch" || msg.includes("NetworkError") || msg.includes("network")) {
      throw new Error("Could not connect to the earnings service. Please check your connection and retry.");
    }
    throw err;
  }
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `Failed to load earnings result: ${res.statusText}`);
  }
  return parseJsonSanitized(res);
}

export {
  __commonJS,
  __toESM,
  __publicField,
  initializeTelemetry,
  setTelemetryUser,
  clearTelemetryUser,
  trackEvent,
  trackPageView,
  getEventSourceAuthToken,
  getCachedUser,
  setCachedUser,
  getAuthMe,
  apiLogin,
  apiSignup,
  apiSendVerification,
  apiForgotPassword,
  apiResetPassword,
  apiGoogleAuth,
  apiUpdateMobile,
  apiLogout,
  getPortfolioMirror,
  replacePortfolioMirror,
  syncManualPortfolio,
  uploadPortfolioDocument,
  uploadPortfolioScreenshot,
  confirmExtraction,
  cancelExtraction,
  getPortfolioAnalytics,
  deletePortfolioMirror,
  getPortfolioNews,
  getPortfolioSectors,
  getPortfolioGovernance,
  getCompanyGovernance,
  getCompanyNetwork,
  getCompanyProvenance,
  getCompanyHealth,
  triageFilings,
  getHoldingDetail,
  getCorporateActions,
  getPortfolioAlerts,
  getTaxSummary,
  getDividends,
  postStressTest,
  getMfAnalytics,
  getTodayQueue,
  getPortfolioBrief,
  getPortfolioCommentary,
  startResearch,
  stopSession,
  getSessionResult,
  streamSession,
  getUserTokenUsage,
  getUserSubscription,
  createRazorpayOrder,
  verifyRazorpayPayment,
  getMarketQuotes,
  getMarketNews,
  getMarketIndices,
  getMarketHistory,
  getWatchlistSnapshot,
  screenerSearch,
  getScreenerSnapshot,
  getScreenerFinancials,
  getScreenerTechnicals,
  getScreenerEvents,
  getScreenerAnalysis,
  runScreenerQuery,
  generateFlashArticle,
  ingestFlashEvents,
  getContentAutomationStatus,
  runContentAutomationNow,
  listContentArticles,
  getContentArticle,
  getContentArticleHtml,
  publishContentArticle,
  unpublishContentArticle,
  flashJobStreamUrl,
  flashJobStatusUrl,
  requestExport,
  pollExport,
  downloadExport,
  downloadExportAndSave,
  getIpoPipeline,
  getIpoAnalysis,
  getIpoAnalysisStatus,
  queueIpoAnalysis,
  getIpoTracking,
  searchIpos,
  getIpoStats,
  refreshIpoData,
  runIpoWatcher,
  analyzeIpo,
  getEarningsCalendar,
  getEarningsOverview,
  getEarningsCompanies,
  getEarningsResult
};
//# sourceMappingURL=/chunk-chunk-ZUQP77ZM.js.map
