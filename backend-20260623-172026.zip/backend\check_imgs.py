import urllib.request
resp = urllib.request.urlopen('http://127.0.0.1:8000/insights/research/')
html = resp.read().decode('utf-8')
import re
imgs = re.findall('<img [^>]*src=\"([^\"]+)\"', html)
for i in imgs: print(i)
