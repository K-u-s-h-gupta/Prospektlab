import urllib.request
resp = urllib.request.urlopen('http://127.0.0.1:8000/insights/research/')
html = resp.read().decode('utf-8')
with open('current_hub.html', 'w', encoding='utf-8') as f:
    f.write(html)
print('Saved. Length:', len(html))
