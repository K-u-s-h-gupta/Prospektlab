"""[ARCHIVED — NOT ACTIVE]
Depth-first crawling using a real Playwright browser.

Returns a list of discovered URLs (same-domain by default) in the order visited.
Designed for finagent's need to deeply explore company filings, investor pages,
regulatory sites, etc. without triggering anti-bot systems.
"""

from __future__ import annotations

import asyncio
import logging
from collections import deque
from typing import Set
from urllib.parse import urljoin, urlparse

from finagent.tools.browser.playwright_backend import launch_browser

logger = logging.getLogger("finagent.deep_crawler")


def _same_domain(a: str, b: str) -> bool:
    return urlparse(a).netloc == urlparse(b).netloc


async def crawl_depth_first(
    seed_url: str,
    max_pages: int = 50,
    *,
    max_depth: int = 3,
    same_domain_only: bool = True,
    headless: bool = True,
) -> list[str]:
    """DFS crawl starting from seed_url.

    Returns up to max_pages unique URLs discovered via <a href> links.
    Uses a real browser (Playwright) so it handles JS-rendered links.
    """
    if not seed_url.startswith(("http://", "https://")):
        seed_url = "https://" + seed_url

    visited: Set[str] = set()
    results: list[str] = []
    queue: deque[tuple[str, int]] = deque([(seed_url, 0)])  # (url, depth)

    async with launch_browser(headless=headless) as ctx:
        while queue and len(results) < max_pages:
            url, depth = queue.pop()  # DFS = pop from right (stack)
            if url in visited or depth > max_depth:
                continue
            visited.add(url)

            try:
                page = await ctx.new_page()
                logger.info("[DEEP CRAWL] Visiting (depth=%d) %s", depth, url)
                resp = await page.goto(url, wait_until="domcontentloaded", timeout=25000)
                if not resp or resp.status >= 400:
                    await page.close()
                    continue

                # Extract all links
                anchors = await page.query_selector_all("a[href]")
                new_links = 0
                for a in anchors:
                    href = await a.get_attribute("href")
                    if not href:
                        continue
                    absolute = urljoin(url, href).split("#")[0].rstrip("/")
                    if same_domain_only and not _same_domain(seed_url, absolute):
                        continue
                    if absolute.startswith(("http://", "https://")) and absolute not in visited:
                        queue.append((absolute, depth + 1))  # push to end (right) so pop() gives DFS
                        new_links += 1
                        if len(results) + new_links >= max_pages:
                            break

                results.append(url)
                await page.close()

                # Be polite
                await asyncio.sleep(0.6)

            except Exception as exc:
                logger.warning("Deep crawl error on %s: %s", url, exc)
                continue

    logger.info("Deep crawl finished: %d pages discovered from %s", len(results), seed_url)
    return results[:max_pages]
