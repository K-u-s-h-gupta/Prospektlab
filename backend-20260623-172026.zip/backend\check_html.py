from finagent.content.flash_engine import build_insights_hub_html
import re
html = build_insights_hub_html('insights')
match = re.search('<div class="mb-px".*?</div>', html)
if match: print(match.group(0))
