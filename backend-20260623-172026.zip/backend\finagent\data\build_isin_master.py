"""Build the bundled ISIN master database from NSE + AMFI live sources.

Fetches:
- NSE EQUITY_L.csv (~5,700 equity ISINs with SYMBOL, NAME, DATE_OF_LISTING)
- AMFI MF list (via public API or CSV) (~1,800 MF ISINs)

Outputs: isin_master.json with ~7,500 ISINs keyed by ISIN code.

Run this script periodically (weekly recommended) to keep the bundle fresh.
"""

from __future__ import annotations

import asyncio
import csv
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any

import httpx

from finagent.paths import finagent_data_path

logger = logging.getLogger("finagent.data.build_isin_master")

# NSE EQUITY_L.csv: https://archives.nseindia.com/content/equities/EQUITY_L.csv
NSE_EQUITY_CSV_URL = "https://archives.nseindia.com/content/equities/EQUITY_L.csv"

# AMFI public scheme data endpoints
# Note: These endpoints often have issues or redirect to broken portals.
# For Phase 1, we skip AMFI bundling and rely on live API lookup instead.
AMFI_SCHEME_DATA_URL = "https://www.amfiindia.com/spages/showfile.php?id=11531"  # Open-ended equity funds (often broken)
AMFI_MF_LIST_URL = "https://www.amfiindia.com/spages/showfile.php?id=11532"  # All schemes (often broken)


async def fetch_nse_equities() -> dict[str, dict[str, str]]:
    """Fetch NSE equity list and build ISIN -> {symbol, name, sector} mapping.

    Returns:
        dict mapping ISIN -> {symbol, name, exchange, kind, sector}
    """
    equities: dict[str, dict[str, str]] = {}

    try:
        logger.info("Fetching NSE equity list from %s", NSE_EQUITY_CSV_URL)
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(NSE_EQUITY_CSV_URL)
            response.raise_for_status()
            csv_text = response.text

        reader = csv.DictReader(csv_text.splitlines())
        if not reader.fieldnames:
            logger.warning("NSE CSV has no header row")
            return equities

        # Normalize fieldnames to remove leading/trailing spaces
        if reader.fieldnames:
            reader.fieldnames = [f.strip() for f in reader.fieldnames]

        logger.debug("NSE CSV fields: %s", reader.fieldnames)

        count = 0
        for row in reader:
            # Expected columns: SYMBOL, NAME OF COMPANY, SERIES, DATE OF LISTING, ISIN NUMBER, FACE VALUE, etc.
            # Normalize row keys too
            row_norm = {k.strip(): v for k, v in row.items()}
            isin = (row_norm.get("ISIN NUMBER") or row_norm.get("ISIN") or "").strip().upper()
            symbol = (row_norm.get("SYMBOL") or "").strip().upper()
            name = (row_norm.get("NAME OF COMPANY") or row_norm.get("NAME") or "").strip()

            if not isin or not symbol:
                continue

            # Extract sector from NAME if available (often includes sector tag)
            sector = ""

            equities[isin] = {
                "symbol": symbol,
                "name": name,
                "exchange": "NSE",
                "kind": "equity",
                "sector": sector,
            }
            count += 1

        logger.info("Built NSE equity ISIN mapping: %d entries", count)

    except Exception as exc:
        logger.error("Failed to fetch NSE equities: %s", exc)

    return equities


async def fetch_amfi_funds() -> dict[str, dict[str, str]]:
    """Fetch AMFI MF list and build ISIN -> {name, amfi, sector} mapping.

    AMFI doesn't provide SYMBOL directly; we map ISIN -> ISIN as placeholder symbol.

    Returns:
        dict mapping ISIN -> {symbol (=ISIN), name, exchange, kind, sector}
    """
    funds: dict[str, dict[str, str]] = {}

    try:
        logger.info("Fetching AMFI MF list from %s", AMFI_MF_LIST_URL)
        async with httpx.AsyncClient(timeout=30.0, follow_redirects=True) as client:
            response = await client.get(AMFI_MF_LIST_URL)
            response.raise_for_status()
            csv_text = response.text

        reader = csv.DictReader(csv_text.splitlines())
        if not reader.fieldnames:
            logger.warning("AMFI CSV has no header row")
            return funds

        # Normalize fieldnames to remove leading/trailing spaces
        if reader.fieldnames:
            reader.fieldnames = [f.strip() for f in reader.fieldnames]

        logger.debug("AMFI CSV fields: %s", reader.fieldnames)

        count = 0
        for row in reader:
            # Expected columns vary; common ones: Scheme Code, Scheme Name, ISIN, Category, Type, etc.
            # Normalize row keys too
            row_norm = {k.strip(): v for k, v in row.items()}
            isin = (row_norm.get("ISIN") or row_norm.get("isin") or "").strip().upper()
            name = (row_norm.get("Scheme Name") or row_norm.get("scheme_name") or "").strip()
            amfi_code = (row_norm.get("Scheme Code") or row_norm.get("scheme_code") or "").strip()
            category = (row_norm.get("Category") or row_norm.get("category") or "").strip()

            if not isin:
                continue

            # Use ISIN as symbol for MF (since MF doesn't have equity-style tickers)
            funds[isin] = {
                "symbol": isin,  # MF placeholder
                "name": name or isin,
                "exchange": "AMFI",
                "kind": "mf",
                "sector": category,
            }
            count += 1

        logger.info("Built AMFI MF ISIN mapping: %d entries", count)

    except Exception as exc:
        logger.error("Failed to fetch AMFI funds: %s", exc)

    return funds


async def build_isin_master() -> dict[str, dict[str, str]]:
    """Build master ISIN database from NSE + AMFI sources.

    Returns:
        dict mapping ISIN -> {symbol, name, exchange, kind, sector}
    """
    logger.info("Building ISIN master database...")

    # Fetch both in parallel
    equities, funds = await asyncio.gather(
        fetch_nse_equities(),
        fetch_amfi_funds(),
    )

    # Merge
    master = {**equities, **funds}  # Equities first, then MF (MF overwrites if same ISIN)

    logger.info("ISIN master database built: %d total entries (%d equity, %d MF)",
                len(master), len(equities), len(funds))

    return master


def save_isin_master(master: dict[str, dict[str, str]]) -> Path:
    """Save ISIN master to isin_master.json.

    Args:
        master: ISIN -> metadata dict

    Returns:
        Path to saved file
    """
    output_path = finagent_data_path("isin_master.json")
    output_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(master, f, indent=2, ensure_ascii=False)
        logger.info("Saved ISIN master to %s (%d entries)", output_path, len(master))
        return output_path
    except Exception as exc:
        logger.error("Failed to save ISIN master: %s", exc)
        raise


async def main() -> None:
    """Main entry point: build and save ISIN master database."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    try:
        master = await build_isin_master()
        output_path = save_isin_master(master)
        logger.info("Successfully built ISIN master: %s", output_path)
    except Exception as exc:
        logger.error("ISIN master build failed: %s", exc)
        raise


if __name__ == "__main__":
    asyncio.run(main())
