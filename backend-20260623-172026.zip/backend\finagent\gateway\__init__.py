"""HTTP / SSE gateway package."""
