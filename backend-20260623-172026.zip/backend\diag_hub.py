"""Diagnose the /insights/research/ endpoint."""
import urllib.request
import traceback
import sys

# 1. Check backend directly
print("=" * 60)
print("CHECK 1: Backend at :8000/insights/research/")
print("=" * 60)
try:
    resp = urllib.request.urlopen("http://127.0.0.1:8000/insights/research/")
    html = resp.read().decode("utf-8")
    print(f"  Status: {resp.status}")
    print(f"  Length: {len(html)} bytes")
    has = lambda tag: tag in html
    checks = {
        "ticker-track": has("ticker-track"),
        "story--feature": has("story--feature"),
        "feat-thumb": has("feat-thumb"),
        "data-count": has("data-count"),
        "principle-grid": has("principle-grid"),
        "contact-card": has("contact-card"),
        "foot-grid": has("foot-grid"),
        "archive-search": has("archive-search"),
        "animateCount": has("animateCount"),
        "data-spark": has("data-spark"),
        "</html>": has("</html>"),
    }
    for k, v in checks.items():
        print(f"  {k}: {'OK' if v else 'MISSING'}")

    # Check for truncation: does the HTML end properly?
    tail = html[-200:]
    print(f"\n  Last 200 chars:\n  {repr(tail)}")
except Exception as e:
    print(f"  ERROR: {e}")
    if hasattr(e, "read"):
        body = e.read().decode("utf-8")[:500]
        print(f"  Response body: {body}")

# 2. Check Vite proxy
print("\n" + "=" * 60)
print("CHECK 2: Vite at :3000/insights/research/")
print("=" * 60)
try:
    resp2 = urllib.request.urlopen("http://localhost:3000/insights/research/")
    html2 = resp2.read().decode("utf-8")
    print(f"  Status: {resp2.status}")
    print(f"  Length: {len(html2)} bytes")
    react_root = 'id="root"' in html2
    print(f"  Has React root: {react_root}")
    print(f"  Has ticker: {'ticker-track' in html2}")
    print(f"  Has </html>: {'</html>' in html2}")
    print(f"\n  Last 200 chars:\n  {repr(html2[-200:])}")
except Exception as e:
    print(f"  ERROR: {e}")

# 3. Try building the HTML directly to catch Python errors
print("\n" + "=" * 60)
print("CHECK 3: build_insights_hub_html() direct call")
print("=" * 60)
try:
    from finagent.content.flash_engine import build_insights_hub_html
    result = build_insights_hub_html("insights")
    print(f"  Success: {len(result)} bytes")
    print(f"  Ends with </html>: {result.rstrip().endswith('</html>')}")
except Exception:
    traceback.print_exc()
