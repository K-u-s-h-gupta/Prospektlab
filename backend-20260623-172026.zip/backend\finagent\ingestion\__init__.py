"""Portfolio ingestion helpers."""
