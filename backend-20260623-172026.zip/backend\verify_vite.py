import urllib.request
resp = urllib.request.urlopen('http://localhost:3000/insights/research/')
html = resp.read().decode('utf-8')
print('Length:', len(html))
print('Has ticker:', 'ticker-track' in html)
print('Has story--feature:', 'story--feature' in html)
print('Has data-count:', 'data-count' in html)
print('Has react root:', 'id="root"' in html)
