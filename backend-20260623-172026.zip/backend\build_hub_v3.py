#!/usr/bin/env python3
"""Replace the return f-string in _build_insights_hub_html_editorial with a
pixel-faithful replica of the ProspektLab handoff — keeping the dark-blue theme
the user requested (#03060d base) but matching every section/component exactly."""

PATH = "finagent/content/flash_engine.py"

# ── Image map: content_type → thumbnail path ─────────────────────────────────
# Maps content_type keywords to one of the handoff SVG images.
IMAGE_SLUGS = {
    "sebi":     "/research-images/sebi-ace.svg",
    "earnings": "/research-images/it-earnings.svg",
    "company":  "/research-images/cement-capex.svg",
    "trend":    "/research-images/rbi-policy.svg",
    "manual":   "/research-images/nbfc-funding.svg",
    "banking":  "/research-images/banking-nim.svg",
    "auto":     "/research-images/auto-rural.svg",
    "pharma":   "/research-images/pharma-export.svg",
    "nbfc":     "/research-images/nbfc-funding.svg",
}

NEW_TEMPLATE = r'''
    # ── pick default thumbnail by content_type ──────────────────────────────
    _THUMB_MAP = {
        "sebi":     "/research-images/sebi-ace.svg",
        "earnings": "/research-images/it-earnings.svg",
        "company":  "/research-images/cement-capex.svg",
        "trend":    "/research-images/rbi-policy.svg",
        "manual":   "/research-images/nbfc-funding.svg",
    }

    def _thumb(article: dict[str, Any]) -> str:
        """Return best thumbnail URL: cover image if exists, else type-matched SVG."""
        slug = str(article.get("slug") or "").strip()
        if slug:
            img = str(article.get("image_path") or "")
            suffix = Path(img).suffix.lower() if img else ""
            ext = suffix if suffix in {".png", ".jpg", ".jpeg", ".webp", ".svg"} else ".svg"
            cover = f"/{route_base}/{slug}/cover{ext}"
            return cover
        ct = str(article.get("content_type") or "manual").strip().lower()
        return _THUMB_MAP.get(ct, "/research-images/nbfc-funding.svg")

    def _read_mins(article: dict[str, Any]) -> str:
        wc = 0
        for field in ("body", "hero_summary", "description"):
            txt = str(article.get(field) or "")
            wc += len(txt.split())
        mins = max(2, round(wc / 200))
        return f"{mins} min read"

    def _story_card_v3(article: dict[str, Any], *, featured: bool = False, index: int = 0) -> str:
        slug = str(article.get("slug") or "").strip()
        title_raw = str(article.get("title") or slug or "Untitled insight")
        summary_raw = str(article.get("hero_summary") or article.get("description") or "").strip()
        content_type = str(article.get("content_type") or "manual").strip().lower() or "manual"
        meta = type_meta.get(content_type, type_meta["manual"])
        accent = meta["accent"]
        cat_label = meta["label"]
        local_url = f"/{route_base}/{slug}/" if slug else "#"
        date_label = _format_date(str(article.get("published_at") or article.get("generated_at") or ""))
        thumb = html.escape(_thumb(article))
        title = html.escape(sanitize_public_text(title_raw))
        deck_raw = sanitize_public_text(summary_raw[:240] if featured else summary_raw[:160])
        deck = html.escape(deck_raw or "Publication-ready market research.")
        read_time = _read_mins(article)
        search_attr = html.escape(_search_blob(article), quote=True)
        ikg = bool(article.get("ikg_covered"))
        ikg_attr = "yes" if ikg else "no"

        if featured:
            # Feature card — full width, horizontal layout with side panel
            mktcap = html.escape(str(article.get("market_cap") or ""))
            revenue = html.escape(str(article.get("revenue") or ""))
            # 30-day price change if available
            chg30 = article.get("price_change_30d")
            try:
                chg30_f = float(chg30 or 0)
            except Exception:
                chg30_f = 0.0
            chg30_dir = "up" if chg30_f >= 0 else "down"
            chg30_str = html.escape(f"{'+' if chg30_f >= 0 else ''}{chg30_f:.1f}%")

            side_panel = ""
            if mktcap or revenue:
                rows = ""
                if mktcap:
                    rows += f'<div class="story-metric" style="justify-content:space-between;width:100%"><span class="muted">Market cap</span><strong>{mktcap}</strong></div>'
                if revenue:
                    rows += f'<div class="story-metric" style="justify-content:space-between;width:100%"><span class="muted">Revenue</span><strong>{revenue}</strong></div>'
                if chg30 is not None:
                    rows += (
                        f'<div class="story-metric" style="justify-content:space-between;width:100%">'
                        f'<span class="muted">30-day</span>'
                        f'<span style="display:inline-flex;align-items:center;gap:.5em">'
                        f'<canvas data-spark="100,98,97,95,96,94,93,92,90,91" data-dir="{chg30_dir}" style="width:60px;height:22px"></canvas>'
                        f'<span class="idx-chg {chg30_dir}">{chg30_str}</span>'
                        f'</span></div>'
                    )
                side_panel = (
                    '<div class="feat-side">'
                    '<span class="eyebrow" style="font-size:.6rem">Company Context</span>'
                    f'<div style="margin-top:16px;display:flex;flex-direction:column;gap:14px">{rows}</div>'
                    '</div>'
                )

            feat_row_cols = f'1.5fr {1 if side_panel else 0}fr' if side_panel else '1fr'
            feat_row = (
                f'<div class="feat-row" style="grid-template-columns:{feat_row_cols}">'
                '<div>'
                f'<div class="story-top"><span class="story-cat" style="color:{html.escape(accent)}">{html.escape(cat_label)}</span><span class="story-read">{html.escape(read_time)}</span></div>'
                f'<h2 class="story-title">{title}</h2>'
                f'<p class="story-dek">{deck}</p>'
                '<div class="story-foot">'
                f'<span class="story-date">{html.escape(date_label)}</span>'
                f'<a class="story-go" href="{html.escape(local_url)}">Read story <span class="arrow">&#x2192;</span></a>'
                '</div>'
                '</div>'
                + side_panel +
                '</div>'
            )
            return (
                f'<article class="story story--feature" data-story data-type="{html.escape(content_type)}" data-ikg="{ikg_attr}" data-search="{search_attr}">'
                f'<a href="{html.escape(local_url)}" class="story-card" data-cursor>'
                f'<img class="feat-thumb" src="{thumb}" alt="{title} cover" loading="lazy" />'
                + feat_row +
                '</a></article>'
            )
        else:
            # Standard card
            return (
                f'<article class="story" data-story data-type="{html.escape(content_type)}" data-ikg="{ikg_attr}" data-search="{search_attr}">'
                f'<a href="{html.escape(local_url)}" class="story-card" data-cursor>'
                f'<img class="story-thumb" src="{thumb}" alt="{title} cover" loading="lazy" />'
                f'<div class="story-top"><span class="story-cat" style="color:{html.escape(accent)}">{html.escape(cat_label)}</span><span class="story-read">{html.escape(read_time)}</span></div>'
                f'<h2 class="story-title">{title}</h2>'
                f'<p class="story-dek">{deck}</p>'
                '<div class="story-foot">'
                f'<span class="story-date">{html.escape(date_label)}</span>'
                f'<span class="story-go">Read <span class="arrow">&#x2192;</span></span>'
                '</div>'
                '</a></article>'
            )

    if published:
        stories_html_v3 = "\n".join(
            _story_card_v3(article, featured=(i == 0), index=i)
            for i, article in enumerate(published)
        )
    else:
        stories_html_v3 = (
            '<div id="archive-empty" style="grid-column:1/-1;text-align:center;padding:60px 20px;border:1px dashed rgba(255,255,255,0.12);border-radius:22px">'
            '<div class="eyebrow" style="justify-content:center;margin-bottom:16px"><span class="dot"></span> No stories yet</div>'
            '<h2 style="font-family:var(--serif);font-size:clamp(1.8rem,3vw,2.4rem);letter-spacing:-0.04em;margin-bottom:12px">The archive is warming up.</h2>'
            '<p style="color:var(--ink-2);max-width:46ch;margin:0 auto;line-height:1.65">High-conviction stories appear here as they clear editorial review and publish checks.</p>'
            '<a href="/" class="btn" style="margin-top:28px;display:inline-flex">Go to Dashboard <span class="arrow">&#x2192;</span></a>'
            '</div>'
        )

    return f"""<!doctype html>
<html lang="en-IN" data-page="hub">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>ProspektLab Research Hub | Indian Market Intelligence</title>
  <meta name="description" content="Earnings, regulation, company moves, and sector shifts — published as clean, searchable research pages built for fast reading and repeat discovery." />
  <meta name="robots" content="index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1" />
  <meta name="theme-color" content="#03060d" />
  <link rel="canonical" href="{html.escape(_SITE_URL)}/insights/research/" />
  <link rel="icon" type="image/svg+xml" href="/prospektlab-favicon-v2.svg" />
  <meta property="og:type" content="website" />
  <meta property="og:site_name" content="ProspektLab" />
  <meta property="og:title" content="ProspektLab Research Hub | Indian Market Intelligence" />
  <meta property="og:description" content="A public archive of editorial-style research pages for Indian market participants." />
  <meta property="og:url" content="{html.escape(_SITE_URL)}/insights/research/" />
  <meta property="og:image" content="{html.escape(featured_image)}" />
  <meta name="twitter:card" content="summary_large_image" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Newsreader:ital,opsz,wght@0,6..72,400..600;1,6..72,400..560&family=IBM+Plex+Mono:wght@400;500;600&display=swap" rel="stylesheet" />
  <script type="application/ld+json">{schema}</script>
  <style>
  /* ── ProspektLab Research Hub — dark-blue editorial theme ── */
  :root {{
    color-scheme: dark;
    --paper:   #03060d;
    --paper-2: rgba(8,16,32,0.7);
    --paper-3: #0a1628;
    --card:    #0d1f3c;
    --ink:     #EAE3D6;
    --ink-2:   #A8B4C8;
    --ink-3:   #5F7088;
    --ink-on-dark: #EAE3D6;
    --line:        rgba(148,163,184,0.10);
    --line-2:      rgba(147,197,253,0.18);
    --line-strong: rgba(147,197,253,0.30);
    --accent:      #60A5FA;
    --accent-deep: #3B82F6;
    --accent-soft: rgba(96,165,250,0.12);
    --up:   #34D399;
    --down: #FB7185;
    --dark:   #060e1e;
    --dark-2: #0d1928;
    --serif: "Newsreader", Georgia, "Times New Roman", serif;
    --mono:  "IBM Plex Mono", ui-monospace, "SF Mono", Menlo, monospace;
    --gap: clamp(16px, 2.2vw, 28px);
    --pad-x: clamp(20px, 5vw, 80px);
    --maxw: 1320px;
    --radius: 14px;
    --radius-lg: 22px;
    --shadow-sm: 0 1px 0 rgba(0,0,0,0.2), 0 1px 4px rgba(0,0,0,0.3);
    --shadow:    0 2px 8px rgba(0,0,0,0.4), 0 20px 50px -16px rgba(0,0,0,0.6);
    --shadow-lg: 0 30px 70px -30px rgba(0,0,0,0.7);
    --ease: cubic-bezier(0.22, 0.61, 0.36, 1);
  }}
  *, *::before, *::after {{ box-sizing: border-box; }}
  * {{ margin: 0; }}
  html {{ -webkit-text-size-adjust: 100%; scroll-behavior: smooth; }}
  body {{
    font-family: var(--serif); background: var(--paper); color: var(--ink);
    line-height: 1.6; font-size: 18px; -webkit-font-smoothing: antialiased;
    text-rendering: optimizeLegibility; overflow-x: hidden;
    background-image:
      radial-gradient(ellipse 700px 450px at 10% 5%, rgba(37,99,235,0.12) 0%, transparent 60%),
      radial-gradient(ellipse 560px 380px at 88% 12%, rgba(96,165,250,0.08) 0%, transparent 60%);
  }}
  img, svg, canvas {{ display: block; max-width: 100%; }}
  a {{ color: inherit; text-decoration: none; }}
  button {{ font: inherit; color: inherit; cursor: pointer; border: none; background: none; }}
  input, textarea {{ font: inherit; }}
  ::selection {{ background: var(--accent); color: #03060d; }}
  ::-webkit-scrollbar {{ width: 4px; }}
  ::-webkit-scrollbar-track {{ background: transparent; }}
  ::-webkit-scrollbar-thumb {{ background: rgba(148,163,184,0.15); border-radius: 10px; }}

  .wrap {{ width: 100%; max-width: var(--maxw); margin-inline: auto; padding-inline: var(--pad-x); }}
  .section {{ position: relative; z-index: 2; padding: clamp(32px,5vw,60px) 0; }}
  .divider {{ height: 1px; background: var(--line); border: 0; }}

  /* ── Typography ── */
  .eyebrow {{
    font-family: var(--mono); font-size: 0.7rem; font-weight: 500;
    letter-spacing: 0.2em; text-transform: uppercase; color: var(--ink-3);
    display: inline-flex; align-items: center; gap: 0.6em;
  }}
  .eyebrow .dot {{
    width: 7px; height: 7px; border-radius: 50%;
    background: var(--accent); box-shadow: 0 0 0 3px var(--accent-soft);
  }}
  .display {{
    font-family: var(--serif); font-weight: 500;
    font-size: clamp(2.8rem, 6.4vw, 6rem);
    line-height: 0.97; letter-spacing: -0.025em; font-optical-sizing: auto;
  }}
  .display .it {{ font-style: italic; font-weight: 460; color: var(--accent); }}
  h1,h2,h3,h4 {{ font-family: var(--serif); font-weight: 560; letter-spacing: -0.018em; line-height: 1.05; }}
  .h2 {{ font-size: clamp(1.9rem, 3.4vw, 3rem); }}
  .lede {{ font-size: clamp(1.05rem, 1.5vw, 1.3rem); line-height: 1.55; color: var(--ink-2); }}
  .muted {{ color: var(--ink-3); }}
  .mono {{ font-family: var(--mono); }}
  .serif-it {{ font-style: italic; color: var(--accent); }}

  /* ── Buttons ── */
  .btn {{
    font-family: var(--mono); font-size: 0.74rem; letter-spacing: 0.14em; text-transform: uppercase;
    font-weight: 500; display: inline-flex; align-items: center; gap: 0.7em;
    padding: 0.95em 1.5em; border-radius: 999px;
    background: var(--ink); color: var(--paper);
    transition: transform .4s var(--ease), background .3s, box-shadow .4s var(--ease);
  }}
  .btn:hover {{ background: var(--accent-deep); color: #fff; box-shadow: var(--shadow); }}
  .btn .arrow {{ transition: transform .4s var(--ease); }}
  .btn:hover .arrow {{ transform: translateX(4px); }}
  .btn--ghost {{ background: transparent; color: var(--ink); border: 1px solid var(--line-2); }}
  .btn--ghost:hover {{ background: rgba(96,165,250,0.1); border-color: var(--accent); color: var(--accent); }}
  .btn--accent {{ background: var(--accent); color: #03060d; border: none; }}
  .btn--accent:hover {{ background: var(--accent-deep); color: #fff; }}
  .btn--sm {{ padding: 0.7em 1.15em; font-size: 0.68rem; }}
  .magnetic {{ display: inline-block; }}

  /* ── Chips ── */
  .chip {{
    font-family: var(--mono); font-size: 0.7rem; letter-spacing: 0.04em; color: var(--ink-2);
    background: rgba(255,255,255,0.04); border: 1px solid var(--line);
    padding: 0.5em 0.9em; border-radius: 999px; display: inline-flex; align-items: center; gap: 0.5em;
    transition: border-color .25s, color .25s, background .25s, transform .25s var(--ease);
  }}
  .chip:hover {{ border-color: var(--accent); color: var(--accent); transform: translateY(-1px); }}
  .chip.is-active {{ background: var(--ink); color: var(--paper); border-color: var(--ink); }}

  /* ── Header ── */
  .site-head {{
    position: sticky; top: 0; z-index: 50;
    background: rgba(3,6,13,0.88); backdrop-filter: blur(18px) saturate(1.2);
    border-bottom: 1px solid transparent; transition: border-color .3s;
  }}
  .site-head.is-stuck {{ border-color: var(--line); }}
  .head-inner {{ display: flex; align-items: center; justify-content: space-between; height: 64px; gap: 20px; }}
  .brand {{ display: inline-flex; align-items: baseline; gap: 0.6em; }}
  .brand .mk-dot {{ width: 9px; height: 9px; border-radius: 50%; background: var(--accent); align-self: center; box-shadow: 0 0 0 3px var(--accent-soft); }}
  .brand .mk-name {{ font-family: var(--mono); font-weight: 600; letter-spacing: 0.14em; font-size: 0.82rem; text-transform: uppercase; color: #fff; }}
  .brand .mk-sub {{ font-family: var(--mono); font-weight: 400; letter-spacing: 0.22em; font-size: 0.62rem; text-transform: uppercase; color: var(--ink-3); }}
  .nav {{ display: flex; align-items: center; gap: 6px; }}
  .nav a:not(.btn) {{
    font-family: var(--mono); font-size: 0.74rem; letter-spacing: 0.1em; text-transform: uppercase;
    padding: 0.6em 0.95em; border-radius: 999px; color: var(--ink-2);
    position: relative; transition: color .25s, background .25s;
  }}
  .nav a:not(.btn):hover {{ color: var(--ink); background: rgba(255,255,255,0.06); }}
  .nav a:not(.btn).is-current {{ color: var(--ink); }}
  .nav a:not(.btn).is-current::after {{
    content: ""; position: absolute; left: 0.95em; right: 0.95em; bottom: 0.35em; height: 1.5px; background: var(--accent);
  }}
  .nav-cta {{ margin-left: 8px; }}
  .burger {{ display: none; width: 42px; height: 42px; border-radius: 10px; border: 1px solid var(--line-2); align-items: center; justify-content: center; flex-direction: column; gap: 4px; }}
  .burger span {{ width: 18px; height: 1.6px; background: var(--ink); transition: transform .3s var(--ease), opacity .3s; }}
  .burger.is-open span:nth-child(1) {{ transform: translateY(5.6px) rotate(45deg); }}
  .burger.is-open span:nth-child(2) {{ opacity: 0; }}
  .burger.is-open span:nth-child(3) {{ transform: translateY(-5.6px) rotate(-45deg); }}
  .m-nav {{
    position: fixed; inset: 0; z-index: 49; background: rgba(3,6,13,0.97);
    backdrop-filter: blur(20px); padding: 90px var(--pad-x) 40px;
    display: flex; flex-direction: column; gap: 8px;
    transform: translateY(-100%); transition: transform .5s var(--ease); visibility: hidden;
  }}
  .m-nav.is-open {{ transform: translateY(0); visibility: visible; }}
  .m-nav a {{ font-family: var(--serif); font-size: 2rem; padding: 0.3em 0; border-bottom: 1px solid var(--line); }}
  .m-nav a .n-num {{ font-family: var(--mono); font-size: 0.7rem; color: var(--ink-3); margin-right: 1em; }}

  /* ── Ticker ── */
  .ticker {{
    position: relative; z-index: 40; background: var(--dark); color: var(--ink-on-dark);
    border-bottom: 1px solid rgba(255,255,255,0.06); overflow: hidden; height: 36px;
  }}
  .ticker-track {{ display: flex; gap: 0; width: max-content; height: 100%; animation: ticker 48s linear infinite; align-items: center; }}
  .ticker:hover .ticker-track {{ animation-play-state: paused; }}
  @keyframes ticker {{ to {{ transform: translateX(-50%); }} }}
  .tk {{
    font-family: var(--mono); font-size: 0.72rem; letter-spacing: 0.02em;
    display: inline-flex; align-items: center; gap: 0.55em;
    padding: 0.7em 1.3em; border-right: 1px solid rgba(255,255,255,0.07); white-space: nowrap;
    height: 100%;
  }}
  .tk .sym {{ color: #fff; font-weight: 500; }}
  .tk .px {{ color: var(--ink-2); }}
  .tk .chg.up {{ color: #4FCF8E; }}
  .tk .chg.down {{ color: #F2876F; }}
  .tk .tri {{ font-size: 0.6rem; }}

  /* ── Reveal ── */
  [data-reveal] {{ opacity: 0; transform: translateY(22px); transition: opacity .9s var(--ease), transform .9s var(--ease); }}
  [data-reveal].in {{ opacity: 1; transform: none; }}
  [data-reveal-stagger] > * {{ opacity: 0; transform: translateY(22px); transition: opacity .8s var(--ease), transform .8s var(--ease); }}
  [data-reveal-stagger].in > * {{ opacity: 1; transform: none; }}
  @media (prefers-reduced-motion: reduce) {{
    * {{ animation: none !important; transition: none !important; }}
    [data-reveal], [data-reveal-stagger] > * {{ opacity: 1 !important; transform: none !important; }}
  }}

  /* ── Hero ── */
  .hero {{ padding: clamp(48px, 8vw, 110px) 0 clamp(40px, 6vw, 72px); }}
  .hero-grid {{ display: grid; grid-template-columns: 1.45fr 1fr; gap: clamp(28px, 4vw, 64px); align-items: end; }}
  .hero-head .display {{ margin: 0.35em 0 0; max-width: 14ch; }}
  .hero-lede {{ margin-top: 1.3em; max-width: 46ch; }}
  .hero-actions {{ margin-top: 2em; display: flex; gap: 14px; flex-wrap: wrap; align-items: center; }}

  /* ── Market Snapshot ── */
  .snap {{
    background: var(--card); border: 1px solid var(--line-2); border-radius: var(--radius-lg);
    padding: clamp(18px,2vw,26px); box-shadow: var(--shadow); position: relative; overflow: hidden;
  }}
  .snap::after {{ content:""; position:absolute; inset:0; border-radius:inherit; pointer-events:none; box-shadow: inset 0 1px 0 rgba(255,255,255,0.06); }}
  .snap-head {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 18px; }}
  .snap-live {{ font-family: var(--mono); font-size: 0.62rem; letter-spacing: 0.16em; text-transform: uppercase; color: var(--up); display: inline-flex; align-items: center; gap: 0.5em; }}
  .snap-live .pulse {{ width: 7px; height: 7px; border-radius: 50%; background: var(--up); position: relative; }}
  .snap-live .pulse::after {{ content:""; position:absolute; inset:0; border-radius:50%; background: var(--up); animation: pulse 2s var(--ease) infinite; }}
  @keyframes pulse {{ 0%{{transform:scale(1);opacity:.7}} 70%{{transform:scale(2.6);opacity:0}} 100%{{opacity:0}} }}
  .idx-row {{ display: flex; justify-content: space-between; align-items: center; padding: 13px 0; border-top: 1px solid var(--line); }}
  .idx-row:first-of-type {{ border-top: 0; }}
  .idx-meta .idx-name {{ font-family: var(--mono); font-size: 0.78rem; font-weight: 500; letter-spacing: 0.02em; }}
  .idx-meta .idx-sub {{ font-family: var(--mono); font-size: 0.62rem; color: var(--ink-3); letter-spacing: 0.04em; }}
  .idx-spark {{ width: 96px; height: 34px; }}
  .idx-val {{ text-align: right; min-width: 92px; }}
  .idx-val .idx-px {{ font-family: var(--mono); font-size: 0.84rem; font-weight: 500; font-feature-settings:"tnum"; }}
  .idx-val .idx-chg {{ font-family: var(--mono); font-size: 0.66rem; margin-top: 2px; }}
  .idx-chg.up {{ color: var(--up); }}
  .idx-chg.down {{ color: var(--down); }}

  /* ── Market Band ── */
  .market-band {{ padding: clamp(8px,1vw,16px) 0 clamp(36px,5vw,60px); border-top: 1px solid var(--line); border-bottom: 1px solid var(--line); background: var(--paper-2); }}
  .mb-grid {{ display: grid; grid-template-columns: repeat(6, 1fr); gap: 14px; }}
  .mb-card {{
    background: var(--card); border: 1px solid var(--line); border-radius: var(--radius);
    padding: 16px 16px 12px; transition: transform .4s var(--ease), border-color .3s, box-shadow .4s var(--ease);
  }}
  .mb-card:hover {{ transform: translateY(-3px); border-color: var(--line-2); box-shadow: var(--shadow-sm); }}
  .mb-card .mb-name {{ font-family: var(--mono); font-size: 0.66rem; letter-spacing: 0.08em; text-transform: uppercase; color: var(--ink-3); }}
  .mb-card .mb-px {{ font-family: var(--mono); font-size: 1.05rem; font-weight: 500; margin: 6px 0 2px; font-feature-settings:"tnum"; }}
  .mb-card .mb-chg {{ font-family: var(--mono); font-size: 0.7rem; display: inline-flex; gap: 0.3em; }}
  .mb-card canvas {{ width: 100%; height: 30px; margin-top: 8px; }}

  /* ── Section header ── */
  .sec-head {{ display: flex; justify-content: space-between; align-items: flex-end; gap: 24px; margin-bottom: clamp(24px,3vw,40px); flex-wrap: wrap; }}
  .sec-head .sec-title {{ max-width: 22ch; }}
  .sec-num {{ font-family: var(--mono); font-size: 0.7rem; letter-spacing: 0.16em; color: var(--ink-3); }}

  /* ── Publishing Model ── */
  .pubmodel {{ padding: clamp(40px,6vw,80px) 0; }}
  .pubmodel-grid {{ display: grid; grid-template-columns: 1fr 1fr; gap: clamp(28px,4vw,60px); align-items: start; }}
  .pubmodel .chips-wrap {{ display: flex; flex-wrap: wrap; gap: 10px; margin-top: 22px; }}

  /* ── Story cards ── */
  .stories {{ display: grid; grid-template-columns: repeat(12, 1fr); gap: var(--gap); }}
  .story {{ grid-column: span 4; display: flex; flex-direction: column; }}
  .story--feature {{ grid-column: span 12; }}
  .story-card {{
    background: var(--card); border: 1px solid var(--line); border-radius: var(--radius-lg);
    padding: clamp(20px,2.2vw,30px); height: 100%; display: flex; flex-direction: column;
    transition: transform .5s var(--ease), box-shadow .5s var(--ease), border-color .4s;
    position: relative; overflow: hidden;
  }}
  .story-card:hover {{ transform: translateY(-5px); box-shadow: var(--shadow); border-color: var(--line-2); }}
  .story-card::before {{ content:""; position:absolute; left:0; top:0; bottom:0; width:3px; background: var(--accent); transform: scaleY(0); transform-origin: top; transition: transform .5s var(--ease); }}
  .story-card:hover::before {{ transform: scaleY(1); }}
  .story-top {{ display: flex; justify-content: space-between; align-items: center; gap: 12px; margin-bottom: 18px; }}
  .story-cat {{ font-family: var(--mono); font-size: 0.64rem; letter-spacing: 0.14em; text-transform: uppercase; }}
  .story-read {{ font-family: var(--mono); font-size: 0.64rem; color: var(--ink-3); letter-spacing: 0.04em; }}
  .story-title {{ font-family: var(--serif); font-weight: 560; line-height: 1.1; letter-spacing: -0.015em; font-size: clamp(1.3rem, 1.7vw, 1.65rem); margin-bottom: 0.5em; }}
  .story--feature .story-title {{ font-size: clamp(1.9rem, 3.2vw, 2.9rem); max-width: 18ch; line-height: 1.06; }}
  .story-dek {{ color: var(--ink-2); font-size: 0.98rem; line-height: 1.55; }}
  .story--feature .story-dek {{ font-size: clamp(1.05rem,1.4vw,1.25rem); max-width: 52ch; }}
  .story-foot {{ margin-top: auto; padding-top: 20px; display: flex; justify-content: space-between; align-items: center; gap: 12px; }}
  .story-date {{ font-family: var(--mono); font-size: 0.66rem; color: var(--ink-3); letter-spacing: 0.04em; }}
  .story-go {{ font-family: var(--mono); font-size: 0.66rem; letter-spacing: 0.1em; text-transform: uppercase; color: var(--ink); display: inline-flex; align-items: center; gap: 0.5em; transition: gap .3s var(--ease), color .3s; }}
  .story-card:hover .story-go {{ gap: 0.9em; color: var(--accent); }}
  .story-metric {{ display: inline-flex; align-items: center; gap: 0.6em; font-family: var(--mono); font-size: 0.72rem; padding: 0.4em 0.7em; border: 1px solid var(--line); border-radius: 8px; }}
  .story-metric canvas {{ width: 60px; height: 22px; }}
  .story--feature .story-card {{ display: flex; flex-direction: column; gap: clamp(22px,2.5vw,30px); }}
  .story--feature .feat-thumb {{ display: block; width: 100%; aspect-ratio: 21/9; border-radius: var(--radius); overflow: hidden; object-fit: cover; }}
  .story--feature .feat-row {{ display: grid; grid-template-columns: 1.5fr 1fr; gap: 40px; align-items: center; }}
  .story--feature .feat-row > *:first-child {{ display: flex; flex-direction: column; }}
  .story--feature .feat-side {{ border-left: 1px solid var(--line); padding-left: 36px; }}
  .story-thumb {{ display: block; width: 100%; aspect-ratio: 16/10; border-radius: var(--radius); overflow: hidden; margin-bottom: 20px; object-fit: cover; }}

  /* Search & filter */
  #archive-search {{
    width: min(340px,100%); border: 1px solid var(--line); border-radius: var(--radius);
    background: rgba(255,255,255,0.03); padding: 11px 14px; color: var(--ink);
    font-family: var(--mono); font-size: 0.82rem; outline: none; transition: border-color .2s;
  }}
  #archive-search:focus {{ border-color: var(--accent); background: rgba(96,165,250,0.04); }}
  #archive-search::placeholder {{ color: var(--ink-3); }}
  .filter-strip {{ display: flex; flex-wrap: wrap; gap: 10px; margin-top: 14px; }}
  [data-filter] {{
    font-family: var(--mono); font-size: 0.7rem; letter-spacing: 0.08em; text-transform: uppercase;
    padding: 0.55em 1em; border-radius: 999px; border: 1px solid var(--line);
    background: rgba(255,255,255,0.03); color: var(--ink-2); cursor: pointer;
    display: inline-flex; align-items: center; gap: 0.5em;
    transition: border-color .2s, color .2s, background .2s, transform .2s var(--ease);
  }}
  [data-filter]:hover, [data-filter].is-active {{ border-color: var(--accent); color: var(--accent); background: rgba(96,165,250,0.08); transform: translateY(-1px); }}
  [data-filter] span {{ font-family: var(--mono); font-size: 0.62rem; color: var(--ink-3); }}
  #story-count {{ font-family: var(--mono); font-size: 0.72rem; color: var(--ink-3); letter-spacing: 0.06em; }}

  /* ── Principles ── */
  .principles {{ padding: clamp(40px,6vw,80px) 0; background: var(--paper-2); border-top: 1px solid var(--line); border-bottom: 1px solid var(--line); }}
  .principle-grid {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: var(--gap); }}
  .principle {{ border-top: 2px solid rgba(96,165,250,0.3); padding-top: 22px; }}
  .principle .p-num {{ font-family: var(--mono); font-size: 0.7rem; letter-spacing: 0.16em; color: var(--accent); margin-bottom: 14px; display: block; }}
  .principle h3 {{ font-size: clamp(1.3rem,1.8vw,1.7rem); line-height: 1.12; margin-bottom: 0.55em; }}
  .principle p {{ color: var(--ink-2); font-size: 0.98rem; line-height: 1.6; }}

  /* ── Contact ── */
  .contact {{ padding: clamp(50px,7vw,100px) 0; }}
  .contact-card {{
    background: var(--dark); color: var(--ink-on-dark); border-radius: var(--radius-lg);
    border: 1px solid var(--line-2);
    padding: clamp(34px,5vw,72px); display: grid; grid-template-columns: 1.2fr 1fr;
    gap: clamp(30px,4vw,64px); position: relative; overflow: hidden;
  }}
  .contact-card .eyebrow {{ color: rgba(234,227,214,0.6); }}
  .contact-card .eyebrow .dot {{ box-shadow: 0 0 0 3px rgba(255,255,255,0.08); }}
  .contact-card h2 {{ color: #fff; font-size: clamp(1.9rem,3.2vw,3rem); margin-top: 0.4em; }}
  .contact-card .c-lede {{ color: rgba(234,227,214,0.7); margin-top: 1em; max-width: 40ch; }}
  .contact-form {{ display: flex; flex-direction: column; gap: 14px; }}
  .field label {{ font-family: var(--mono); font-size: 0.64rem; letter-spacing: 0.14em; text-transform: uppercase; color: rgba(234,227,214,0.55); display: block; margin-bottom: 7px; }}
  .field input, .field textarea {{
    width: 100%; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.14); border-radius: 10px;
    padding: 12px 14px; color: #fff; font-family: var(--mono); font-size: 0.86rem; transition: border-color .25s, background .25s;
  }}
  .field input:focus, .field textarea:focus {{ outline: none; border-color: var(--accent); background: rgba(255,255,255,0.08); }}
  .field textarea {{ resize: vertical; min-height: 84px; }}
  .contact-form .btn--accent {{ justify-content: center; margin-top: 4px; }}
  .c-details {{ display: flex; flex-direction: column; gap: 18px; margin-top: 30px; }}
  .c-detail {{ border-top: 1px solid rgba(255,255,255,0.1); padding-top: 14px; }}
  .c-detail .cd-k {{ font-family: var(--mono); font-size: 0.62rem; letter-spacing: 0.14em; text-transform: uppercase; color: rgba(234,227,214,0.5); }}
  .c-detail .cd-v {{ font-family: var(--serif); font-size: 1.15rem; margin-top: 4px; }}

  /* ── Footer ── */
  .foot {{ position: relative; z-index: 2; background: var(--dark); color: var(--ink-on-dark); margin-top: clamp(60px, 9vw, 130px); }}
  .foot a {{ color: var(--ink-on-dark); }}
  .foot .foot-grid {{ display: grid; grid-template-columns: 1.4fr 1fr 1fr; gap: 40px; padding: clamp(50px,7vw,90px) 0 40px; }}
  .foot .mk-name {{ color: #fff; }}
  .foot-disc {{ font-family: var(--mono); font-size: 0.72rem; letter-spacing: 0.03em; color: rgba(234,227,214,0.55); line-height: 1.7; }}
  .foot-col h4 {{ font-family: var(--mono); font-size: 0.7rem; letter-spacing: 0.18em; text-transform: uppercase; color: rgba(234,227,214,0.5); margin-bottom: 14px; font-weight: 500; }}
  .foot-col ul {{ list-style: none; padding: 0; display: flex; flex-direction: column; gap: 10px; }}
  .foot-col a {{ font-family: var(--mono); font-size: 0.82rem; opacity: 0.85; transition: opacity .2s, color .2s; }}
  .foot-col a:hover {{ opacity: 1; color: #fff; }}
  .foot-base {{ display: flex; justify-content: space-between; align-items: center; padding: 22px 0 30px; border-top: 1px solid rgba(255,255,255,0.08); font-family: var(--mono); font-size: 0.68rem; letter-spacing: 0.06em; color: rgba(234,227,214,0.5); flex-wrap: wrap; gap: 14px; }}

  /* ── Custom cursor ── */
  .cursor-dot, .cursor-ring {{ position: fixed; top: 0; left: 0; z-index: 9999; pointer-events: none; border-radius: 50%; mix-blend-mode: difference; }}
  .cursor-dot {{ width: 6px; height: 6px; background: #fff; transform: translate(-50%,-50%); }}
  .cursor-ring {{ width: 34px; height: 34px; border: 1px solid #fff; transform: translate(-50%,-50%); transition: width .25s var(--ease), height .25s var(--ease), background .25s, opacity .25s; }}
  .cursor-ring.is-hover {{ width: 54px; height: 54px; background: rgba(255,255,255,0.12); }}
  @media (hover: none), (pointer: coarse) {{ .cursor-dot, .cursor-ring {{ display: none; }} }}

  /* ── Responsive ── */
  @media (max-width: 1080px) {{ .mb-grid {{ grid-template-columns: repeat(3, 1fr); }} }}
  @media (max-width: 880px) {{ .nav {{ display: none; }} .burger {{ display: flex; }} .foot .foot-grid {{ grid-template-columns: 1fr 1fr; gap: 30px; }} }}
  @media (max-width: 900px) {{
    .hero-grid {{ grid-template-columns: 1fr; align-items: start; }}
    .hero-head .display {{ max-width: 18ch; }}
    .pubmodel-grid {{ grid-template-columns: 1fr; }}
    .story {{ grid-column: span 6; }}
    .story--feature .feat-row {{ grid-template-columns: 1fr; gap: 24px; }}
    .story--feature .feat-side {{ border-left: 0; border-top: 1px solid var(--line); padding-left: 0; padding-top: 24px; }}
    .principle-grid {{ grid-template-columns: 1fr; gap: 30px; }}
    .contact-card {{ grid-template-columns: 1fr; }}
  }}
  @media (max-width: 620px) {{
    .mb-grid {{ grid-template-columns: repeat(2, 1fr); }}
    .story, .story--feature {{ grid-column: span 12; }}
  }}
  @media (max-width: 560px) {{ .foot .foot-grid {{ grid-template-columns: 1fr; }} }}
  </style>
</head>
<body>

<!-- Ticker -->
<div class="ticker" aria-hidden="true">
  <div class="ticker-track" id="ticker-track"></div>
</div>

<!-- Header -->
<header class="site-head">
  <div class="wrap head-inner">
    <a class="brand" href="/{html.escape(route_base)}/research/" aria-label="ProspektLab Research home">
      <span class="mk-dot"></span>
      <span class="mk-name">ProspektLab</span>
      <span class="mk-sub">Research</span>
    </a>
    <nav class="nav" aria-label="Primary">
      <a href="/{html.escape(route_base)}/research/" class="is-current">Dashboard</a>
      <a href="#contact">Contact</a>
      <span class="magnetic nav-cta" data-mag="0.35"><a href="#archive" class="btn btn--sm">Open Archive <span class="arrow">&#x2192;</span></a></span>
    </nav>
    <button class="burger" id="burger-btn" aria-label="Menu" aria-expanded="false">
      <span></span><span></span><span></span>
    </button>
  </div>
</header>

<!-- Mobile nav -->
<div class="m-nav" id="m-nav">
  <a href="/{html.escape(route_base)}/research/"><span class="n-num">01</span>Dashboard</a>
  <a href="#archive"><span class="n-num">02</span>Archive</a>
  <a href="#contact"><span class="n-num">03</span>Contact</a>
</div>

<main>
  <!-- HERO -->
  <section class="section hero">
    <div class="wrap hero-grid">
      <div class="hero-head" data-reveal>
        <span class="eyebrow"><span class="dot"></span> Public Research</span>
        <h1 class="display">Indian market stories with the <span class="it">context</span> serious readers actually need.</h1>
        <p class="lede hero-lede">Earnings, regulation, company moves, and sector shifts are published here as clean, searchable pages built for fast reading, deeper context, and repeat discovery.</p>
        <div class="hero-actions">
          <span class="magnetic" data-mag="0.3"><a href="#archive" class="btn">Browse the archive <span class="arrow">&#x2192;</span></a></span>
          <span class="magnetic" data-mag="0.3"><a href="{html.escape('/' + route_base + '/' + (published[0].get('slug','') if published else '') + '/')}" class="btn btn--ghost">Read latest story</a></span>
        </div>
      </div>

      <aside class="snap" data-reveal>
        <div class="snap-head">
          <span class="eyebrow" style="font-size:.62rem">Market Snapshot</span>
          <span class="snap-live"><span class="pulse"></span> Live</span>
        </div>
        <div class="idx-row">
          <div class="idx-meta"><div class="idx-name">NIFTY 50</div><div class="idx-sub">NSE &middot; INDEX</div></div>
          <canvas class="idx-spark" data-spark="100,101,99,102,103,101,104,106,105,108" data-dir="up" id="spark-nifty50"></canvas>
          <div class="idx-val"><div class="idx-px" id="px-nifty50" data-count="24218.45" data-dec="2">0</div><div class="idx-chg up" id="chg-nifty50">+0.94%</div></div>
        </div>
        <div class="idx-row">
          <div class="idx-meta"><div class="idx-name">SENSEX</div><div class="idx-sub">BSE &middot; INDEX</div></div>
          <canvas class="idx-spark" data-spark="100,100.5,101,100.2,101.5,102,101.8,103,102.6,103.4" data-dir="up" id="spark-sensex"></canvas>
          <div class="idx-val"><div class="idx-px" id="px-sensex" data-count="79476.19" data-dec="2">0</div><div class="idx-chg up" id="chg-sensex">+0.81%</div></div>
        </div>
        <div class="idx-row">
          <div class="idx-meta"><div class="idx-name">BANK NIFTY</div><div class="idx-sub">NSE &middot; INDEX</div></div>
          <canvas class="idx-spark" data-spark="100,99,98.5,99.2,98,97.4,98.1,97,96.4,96.8" data-dir="down" id="spark-banknifty"></canvas>
          <div class="idx-val"><div class="idx-px" id="px-banknifty" data-count="52104.30" data-dec="2">0</div><div class="idx-chg down" id="chg-banknifty">&#x2212;0.37%</div></div>
        </div>
        <div class="idx-row">
          <div class="idx-meta"><div class="idx-name">INR / USD</div><div class="idx-sub">FX &middot; SPOT</div></div>
          <canvas class="idx-spark" data-spark="100,100.1,100.05,100.2,100.3,100.25,100.4,100.5,100.45,100.6" data-dir="up" id="spark-inrusd"></canvas>
          <div class="idx-val"><div class="idx-px" id="px-inrusd" data-count="83.42" data-dec="2">0</div><div class="idx-chg up" id="chg-inrusd">+0.06%</div></div>
        </div>
      </aside>
    </div>
  </section>

  <!-- MARKET BAND -->
  <section class="section market-band">
    <div class="wrap">
      <div class="sec-head" data-reveal>
        <span class="eyebrow"><span class="dot"></span> Market Watch</span>
        <span class="sec-num">Indices &middot; Commodities &middot; Rates</span>
      </div>
      <div class="mb-grid" data-reveal-stagger data-stagger="70">
        <div class="mb-card"><div class="mb-name">Nifty IT</div><div class="mb-px" id="mb-niftyit" data-count="42180.20" data-dec="2">0</div><div class="mb-chg up" id="mbchg-niftyit">&#x25B2; +1.42%</div><canvas data-spark="100,101,102,101.5,103,104,103.6,105,106,107" data-dir="up"></canvas></div>
        <div class="mb-card"><div class="mb-name">Nifty Auto</div><div class="mb-px" id="mb-niftyauto" data-count="25934.85" data-dec="2">0</div><div class="mb-chg up" id="mbchg-niftyauto">&#x25B2; +0.68%</div><canvas data-spark="100,100.4,101,100.8,101.6,102,101.4,102.2,102.8,103" data-dir="up"></canvas></div>
        <div class="mb-card"><div class="mb-name">Nifty FMCG</div><div class="mb-px" id="mb-niftyfmcg" data-count="56120.10" data-dec="2">0</div><div class="mb-chg down" id="mbchg-niftyfmcg">&#x25BC; &#x2212;0.24%</div><canvas data-spark="100,99.8,100,99.4,99,99.2,98.6,98.9,98.4,98.7" data-dir="down"></canvas></div>
        <div class="mb-card"><div class="mb-name">Gold (10g)</div><div class="mb-px" id="mb-gold" data-count="72840" data-dec="0" data-prefix="&#x20B9;">0</div><div class="mb-chg up" id="mbchg-gold">&#x25B2; +0.52%</div><canvas data-spark="100,100.6,101,101.4,101,101.8,102.2,102,102.6,103" data-dir="up"></canvas></div>
        <div class="mb-card"><div class="mb-name">Crude (WTI)</div><div class="mb-px" id="mb-crude" data-count="74.18" data-dec="2" data-prefix="$">0</div><div class="mb-chg down" id="mbchg-crude">&#x25BC; &#x2212;1.08%</div><canvas data-spark="100,99.4,99,98.6,99,98.2,97.8,98,97.4,97.6" data-dir="down"></canvas></div>
        <div class="mb-card"><div class="mb-name">India 10Y</div><div class="mb-px" id="mb-in10y" data-count="6.84" data-dec="2" data-suffix="%">0</div><div class="mb-chg up" id="mbchg-in10y">&#x25B2; +2 bps</div><canvas data-spark="100,100.1,100,100.2,100.3,100.2,100.4,100.5,100.4,100.6" data-dir="up"></canvas></div>
      </div>
    </div>
  </section>

  <hr class="divider wrap" style="background:transparent" />

  <!-- PUBLISHING MODEL -->
  <section class="section pubmodel">
    <div class="wrap pubmodel-grid">
      <div data-reveal>
        <span class="eyebrow"><span class="dot"></span> Publishing Model</span>
        <h2 class="h2" style="margin-top:.5em; max-width:14ch;">Built for search, reading, and <span class="serif-it">trust</span>.</h2>
      </div>
      <div data-reveal>
        <p class="lede">Each article lives at a direct route, carries search metadata, and keeps the focus on the story rather than the workflow behind it.</p>
        <div class="chips-wrap">
          <span class="chip">Evidence-led reporting</span>
          <span class="chip">Continuous market watch</span>
          <span class="chip">Verified company context</span>
          <span class="chip">Compliance-safe language</span>
        </div>
      </div>
    </div>
  </section>

  <!-- LATEST RESEARCH -->
  <section id="archive" class="section" style="padding: clamp(20px,3vw,40px) 0 clamp(50px,7vw,90px)">
    <div class="wrap">
      <div class="sec-head" data-reveal>
        <div>
          <span class="eyebrow"><span class="dot"></span> Latest Research</span>
          <h2 class="h2 sec-title" style="margin-top:.4em">Filter by topic, company, or coverage angle.</h2>
        </div>
        <span class="magnetic" data-mag="0.3"><a href="#archive" class="btn btn--ghost btn--sm">All research <span class="arrow">&#x2192;</span></a></span>
      </div>

      <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;margin-bottom:12px">
        <input type="search" id="archive-search" placeholder="Search company, theme, or keyword&hellip;" />
        <span id="story-count" style="font-family:var(--mono);font-size:0.72rem;color:var(--ink-3)">{published_count} stories</span>
      </div>
      <div class="filter-strip">{filter_buttons}</div>

      <div class="stories" style="margin-top:clamp(28px,3.5vw,48px)" data-reveal-stagger data-stagger="90">
        {stories_html_v3}
      </div>
      <div id="archive-empty" style="display:none;text-align:center;padding:60px 20px;border:1px dashed var(--line);border-radius:var(--radius-lg);margin-top:24px">
        <div class="eyebrow" style="justify-content:center;margin-bottom:14px"><span class="dot"></span>No matches</div>
        <h2 style="font-family:var(--serif);font-size:clamp(1.6rem,2.5vw,2.2rem);letter-spacing:-0.04em">No stories match that filter.</h2>
        <p style="color:var(--ink-2);max-width:44ch;margin:12px auto;font-size:0.98rem;line-height:1.65">Try a different keyword or reset the filter to see all published research.</p>
      </div>
    </div>
  </section>

  <!-- PRINCIPLES -->
  <section class="section principles" style="background:var(--paper-2); border-top:1px solid var(--line); border-bottom:1px solid var(--line)">
    <div class="wrap">
      <div class="sec-head" data-reveal>
        <span class="eyebrow"><span class="dot"></span> Editorial Standards</span>
        <span class="sec-num">How pages are built</span>
      </div>
      <div class="principle-grid" data-reveal-stagger data-stagger="110">
        <div class="principle">
          <span class="p-num">01 &mdash; Evidence first</span>
          <h3>Primary-source bias is deliberate.</h3>
          <p>Official filings, exchange disclosures, company material, and transcripts outrank generic summaries. The archive is designed to make that discipline easy to spot.</p>
        </div>
        <div class="principle">
          <span class="p-num">02 &mdash; Context where useful</span>
          <h3>Company context appears only when it adds real depth.</h3>
          <p>Ownership, governance, and filing context should sharpen the story, not decorate it. Thin coverage should stay clearly disclosed.</p>
        </div>
        <div class="principle">
          <span class="p-num">03 &mdash; Editorial finish</span>
          <h3>The output should feel publishable on first open.</h3>
          <p>Sharper typography, calmer hierarchy, and clearer routes make the archive feel closer to a financial publication than a content dump.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- CONTACT -->
  <section class="section contact" id="contact">
    <div class="wrap">
      <div class="contact-card" data-reveal>
        <div>
          <span class="eyebrow"><span class="dot"></span> Contact</span>
          <h2>Research pages should feel deliberate and trustworthy.</h2>
          <p class="c-lede">Have a correction, a filing we should cover, or a partnership question? Reach the desk directly &mdash; we read everything.</p>
          <div class="c-details">
            <div class="c-detail"><div class="cd-k">Editorial desk</div><div class="cd-v">desk@prospektlab.in</div></div>
            <div class="c-detail"><div class="cd-k">Corrections</div><div class="cd-v">corrections@prospektlab.in</div></div>
            <div class="c-detail"><div class="cd-k">Location</div><div class="cd-v">Mumbai &middot; Bengaluru</div></div>
          </div>
        </div>
        <form class="contact-form" onsubmit="event.preventDefault();this.reset();this.querySelector('.btn').textContent='Sent \u2014 thank you';">
          <div class="field"><label>Name</label><input type="text" placeholder="Your name" required /></div>
          <div class="field"><label>Email</label><input type="email" placeholder="you@firm.com" required /></div>
          <div class="field"><label>Message</label><textarea placeholder="What should we look into?" required></textarea></div>
          <button type="submit" class="btn btn--accent">Send message <span class="arrow">&#x2192;</span></button>
        </form>
      </div>
    </div>
  </section>
</main>

<!-- FOOTER -->
<footer class="foot">
  <div class="wrap">
    <div class="foot-grid">
      <div>
        <a class="brand" href="/{html.escape(route_base)}/research/"><span class="mk-dot"></span><span class="mk-name">ProspektLab</span><span class="mk-sub">Research</span></a>
        <p class="foot-disc" style="margin-top:18px; max-width:42ch">Educational content only. No buy, sell, hold, or target-price language is published here. Research pages are informational and not investment advice.</p>
      </div>
      <div class="foot-col">
        <h4>Platform</h4>
        <ul>
          <li><a href="/{html.escape(route_base)}/research/">Dashboard</a></li>
          <li><a href="#archive">Research Archive</a></li>
          <li><a href="#contact">Contact</a></li>
        </ul>
      </div>
      <div class="foot-col">
        <h4>Coverage</h4>
        <ul>
          <li><a href="#archive">SEBI &amp; Regulation</a></li>
          <li><a href="#archive">Earnings</a></li>
          <li><a href="#archive">Banking &amp; NBFC</a></li>
          <li><a href="#archive">Sectors</a></li>
        </ul>
      </div>
    </div>
    <div class="foot-base">
      <span>&copy; 2026 ProspektLab Research</span>
      <span>Built for fast reading, deeper context, repeat discovery.</span>
    </div>
  </div>
</footer>

<script>
/* ─── ProspektLab Hub — interactions + live data ─── */
(function(){{
  "use strict";
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ── Sticky header ── */
  var head = document.querySelector(".site-head");
  function onScroll(){{ if(head) head.classList.toggle("is-stuck", window.scrollY > 8); }}
  window.addEventListener("scroll", onScroll, {{passive:true}});
  onScroll();

  /* ── Mobile burger ── */
  var burger = document.getElementById("burger-btn");
  var mnav = document.getElementById("m-nav");
  if(burger && mnav){{
    burger.addEventListener("click", function(){{
      var open = mnav.classList.toggle("is-open");
      burger.classList.toggle("is-open", open);
      burger.setAttribute("aria-expanded", open ? "true" : "false");
      document.body.style.overflow = open ? "hidden" : "";
    }});
    mnav.querySelectorAll("a").forEach(function(a){{
      a.addEventListener("click", function(){{
        mnav.classList.remove("is-open");
        burger.classList.remove("is-open");
        document.body.style.overflow = "";
      }});
    }});
  }}

  /* ── Visibility engine ── */
  var watchers = [];
  function watch(el, cb, ratio){{ watchers.push({{el:el, cb:cb, off:ratio==null?0.88:ratio, done:false}}); }}
  function inView(el, ratio){{
    var r = el.getBoundingClientRect();
    var vh = window.innerHeight || document.documentElement.clientHeight;
    if(r.height===0 && r.width===0) return false;
    return r.top < vh * ratio && r.bottom > -40;
  }}
  var ticking = false;
  function checkWatchers(){{
    ticking = false;
    for(var i=0;i<watchers.length;i++){{
      var w=watchers[i]; if(w.done) continue;
      if(inView(w.el, w.off)){{ w.done=true; w.cb(w.el); }}
    }}
  }}
  function onWatchScroll(){{ if(!ticking){{ ticking=true; requestAnimationFrame(checkWatchers); setTimeout(checkWatchers,60); }} }}
  window.addEventListener("scroll", onWatchScroll, {{passive:true}});
  window.addEventListener("resize", onWatchScroll, {{passive:true}});

  /* ── Scroll reveal ── */
  function finalizeReveal(el){{
    el.style.transition="none"; el.style.opacity="1"; el.style.transform="none";
    if(el.hasAttribute("data-reveal-stagger")){{
      for(var i=0;i<el.children.length;i++){{
        var c=el.children[i]; c.style.transition="none"; c.style.opacity="1"; c.style.transform="none";
      }}
    }}
  }}
  document.querySelectorAll("[data-reveal], [data-reveal-stagger]").forEach(function(el){{
    if(reduce){{ el.classList.add("in"); finalizeReveal(el); return; }}
    watch(el, function(t){{
      if(t.hasAttribute("data-reveal-stagger")){{
        var kids=t.children, base=parseFloat(t.getAttribute("data-stagger"))||80;
        for(var i=0;i<kids.length;i++) kids[i].style.transitionDelay=(i*base)+"ms";
      }}
      t.classList.add("in");
      var delay=t.hasAttribute("data-reveal-stagger")?1100+t.children.length*90:1050;
      setTimeout(function(){{ finalizeReveal(t); }}, delay);
    }});
  }});

  /* ── Animated counters ── */
  function fmtNum(n, dec, prefix, suffix){{
    var s = n.toLocaleString("en-IN", {{minimumFractionDigits:dec, maximumFractionDigits:dec}});
    return prefix + s + suffix;
  }}
  function animateCount(el){{
    var target = parseFloat(el.getAttribute("data-count"));
    var dec = parseInt(el.getAttribute("data-dec")||"0", 10);
    var prefix = el.getAttribute("data-prefix")||"";
    var suffix = el.getAttribute("data-suffix")||"";
    var dur = 1300, start = null;
    setTimeout(function(){{ el.textContent = fmtNum(target,dec,prefix,suffix); }}, 1450);
    if(reduce){{ el.textContent = fmtNum(target,dec,prefix,suffix); return; }}
    function step(ts){{
      if(!start) start=ts;
      var p = Math.min((ts-start)/dur, 1);
      var eased = 1-Math.pow(1-p,3);
      el.textContent = fmtNum(target*eased, dec, prefix, suffix);
      if(p<1) requestAnimationFrame(step);
    }}
    requestAnimationFrame(step);
  }}
  document.querySelectorAll("[data-count]").forEach(function(el){{ watch(el, animateCount, 0.97); }});

  /* ── Sparklines ── */
  function drawSpark(canvas, animate){{
    var raw = canvas.getAttribute("data-spark"); if(!raw) return;
    var pts = raw.split(",").map(parseFloat);
    var up = canvas.getAttribute("data-dir") !== "down";
    var color = up ? "#34D399" : "#FB7185";
    var dpr = window.devicePixelRatio || 1;
    var rect = canvas.getBoundingClientRect();
    var w = rect.width || 96, h = rect.height || 34;
    canvas.width = Math.round(w*dpr); canvas.height = Math.round(h*dpr);
    var ctx = canvas.getContext("2d"); ctx.scale(dpr,dpr);
    var mn=Math.min.apply(null,pts), mx=Math.max.apply(null,pts), rng=mx-mn||1, pad=3;
    function x(i){{ return pad+(i/(pts.length-1))*(w-pad*2); }}
    function y(v){{ return h-pad-((v-mn)/rng)*(h-pad*2); }}
    function render(prog){{
      ctx.clearRect(0,0,w,h);
      var n = Math.max(2, Math.round(pts.length*prog));
      var grad = ctx.createLinearGradient(0,0,0,h);
      grad.addColorStop(0, color+"33"); grad.addColorStop(1, color+"00");
      ctx.beginPath(); ctx.moveTo(x(0),y(pts[0]));
      for(var i=1;i<n;i++) ctx.lineTo(x(i),y(pts[i]));
      ctx.lineTo(x(n-1),h); ctx.lineTo(x(0),h); ctx.closePath();
      ctx.fillStyle=grad; ctx.fill();
      ctx.beginPath(); ctx.moveTo(x(0),y(pts[0]));
      for(var j=1;j<n;j++) ctx.lineTo(x(j),y(pts[j]));
      ctx.strokeStyle=color; ctx.lineWidth=1.6; ctx.lineJoin="round"; ctx.lineCap="round"; ctx.stroke();
      ctx.beginPath(); ctx.arc(x(n-1),y(pts[n-1]),2.2,0,Math.PI*2); ctx.fillStyle=color; ctx.fill();
    }}
    render(reduce||!animate ? 1 : 0.001);
    if(reduce||!animate) return;
    var stt=null, dur=850, raf;
    function stepFn(ts){{ if(!stt) stt=ts; var p=Math.min((ts-stt)/dur,1); render(1-Math.pow(1-p,2)); if(p<1) raf=requestAnimationFrame(stepFn); }}
    raf = requestAnimationFrame(stepFn);
    setTimeout(function(){{ if(raf) cancelAnimationFrame(raf); render(1); }}, 950);
  }}
  var sparkEls = document.querySelectorAll("[data-spark]");
  sparkEls.forEach(function(c){{ watch(c, function(t){{ drawSpark(t,true); }}, 0.97); }});
  function redrawSparks(){{ sparkEls.forEach(function(c){{ drawSpark(c,false); }}); }}
  window.addEventListener("resize", function(){{ clearTimeout(window._sparkTimer); window._sparkTimer = setTimeout(redrawSparks,200); }});

  /* ── Custom cursor ── */
  if(!window.matchMedia("(pointer: coarse)").matches){{
    var dot=document.createElement("div"); dot.className="cursor-dot";
    var ring=document.createElement("div"); ring.className="cursor-ring";
    document.body.appendChild(dot); document.body.appendChild(ring);
    var mx=0,my=0,rx=0,ry=0;
    document.addEventListener("mousemove", function(e){{
      mx=e.clientX; my=e.clientY;
      dot.style.transform="translate("+mx+"px,"+my+"px) translate(-50%,-50%)";
    }});
    (function loop(){{ rx+=(mx-rx)*0.18; ry+=(my-ry)*0.18; ring.style.transform="translate("+rx+"px,"+ry+"px) translate(-50%,-50%)"; requestAnimationFrame(loop); }})();
    document.querySelectorAll("a,button,.chip,.story-card,[data-cursor]").forEach(function(el){{
      el.addEventListener("mouseenter",function(){{ring.classList.add("is-hover");}});
      el.addEventListener("mouseleave",function(){{ring.classList.remove("is-hover");}});
    }});
  }}

  /* ── Magnetic buttons ── */
  if(!reduce && !window.matchMedia("(pointer: coarse)").matches){{
    document.querySelectorAll(".magnetic").forEach(function(el){{
      var str = parseFloat(el.getAttribute("data-mag"))||0.3;
      el.addEventListener("mousemove",function(e){{
        var r=el.getBoundingClientRect();
        var mx2=e.clientX-(r.left+r.width/2), my2=e.clientY-(r.top+r.height/2);
        el.style.transform="translate("+mx2*str+"px,"+my2*str+"px)";
        var inn=el.firstElementChild; if(inn) inn.style.transform="translate("+mx2*str*0.5+"px,"+my2*str*0.5+"px)";
      }});
      el.addEventListener("mouseleave",function(){{
        el.style.transform=""; var inn=el.firstElementChild; if(inn) inn.style.transform="";
      }});
    }});
  }}

  /* ── Ticker + Live quotes ── */
  var TICKER_DATA = [
    ["RELIANCE","2,948.20","+1.12%","up"],["TCS","4,012.55","+0.74%","up"],
    ["HDFCBANK","1,684.30","&#x2212;0.42%","down"],["INFY","1,612.90","+1.36%","up"],
    ["ICICIBANK","1,158.75","+0.58%","up"],["SBIN","842.10","&#x2212;0.21%","down"],
    ["BHARTIARTL","1,498.60","+0.92%","up"],["ITC","438.25","&#x2212;0.15%","down"],
    ["LT","3,604.40","+1.48%","up"],["AXISBANK","1,176.85","+0.33%","up"],
    ["KOTAKBANK","1,792.10","&#x2212;0.67%","down"],["HINDUNILVR","2,388.55","+0.27%","up"],
    ["ADANIENT","2,914.70","+2.04%","up"],["MARUTI","12,640.00","+0.88%","up"],
    ["SUNPHARMA","1,742.35","&#x2212;0.31%","down"]
  ];
  function buildTickerHtml(data){{
    return data.map(function(d){{
      return '<span class="tk"><span class="sym">'+d[0]+'</span><span class="px">'+d[1]+'</span><span class="chg '+d[3]+'"><span class="tri">'+(d[3]==="up"?"&#x25B2;":"&#x25BC;")+'</span>'+d[2]+'</span></span>';
    }}).join("");
  }}
  var tt = document.getElementById("ticker-track");
  if(tt){{ var h=buildTickerHtml(TICKER_DATA); tt.innerHTML=h+h; }}

  /* ── Live market data from backend ── */
  var SYMS = ["RELIANCE","TCS","HDFCBANK","INFY","ICICIBANK","SBIN","BHARTIARTL","ITC","LT","AXISBANK","KOTAKBANK","HINDUNILVR","ADANIENT","MARUTI","SUNPHARMA"];
  function toIN(v, dec){{
    if(v==null||!isFinite(+v)) return null;
    return Number(v).toLocaleString("en-IN",{{minimumFractionDigits:dec,maximumFractionDigits:dec}});
  }}
  function pct(p){{
    if(p==null||!isFinite(+p)) return null;
    return (p>=0?"+":"")+Number(p).toFixed(2)+"%";
  }}
  function applyIdx(idPx, idChg, q, fallbackPx, fallbackChg){{
    var pxEl=document.getElementById(idPx), chgEl=document.getElementById(idChg);
    if(!pxEl) return;
    var pr = q&&(q.price||q.value||q.last);
    var pc = q&&(q.change_pct||q.pct_change||q.changePct);
    var prStr = pr!=null ? toIN(pr,2) : null;
    var pcStr = pc!=null ? pct(pc) : null;
    // Only override if we got real data (not null)
    if(prStr) pxEl.textContent = prStr;
    if(pcStr && chgEl){{
      chgEl.textContent = pcStr;
      chgEl.className = "idx-chg "+(pc>=0?"up":"down");
    }}
  }}
  function applyMB(idPx, idChg, q){{
    var pxEl=document.getElementById(idPx), chgEl=document.getElementById(idChg);
    if(!pxEl||!q) return;
    var pr = q.price||q.value||q.last;
    var pc = q.change_pct||q.pct_change||q.changePct;
    var prefix = pxEl.getAttribute("data-prefix")||"";
    var suffix = pxEl.getAttribute("data-suffix")||"";
    if(pr!=null){{ var dec=parseInt(pxEl.getAttribute("data-dec")||"2",10); pxEl.textContent=prefix+toIN(pr,dec)+suffix; }}
    if(pc!=null && chgEl){{
      var up=pc>=0;
      chgEl.textContent=(up?"&#x25B2; +":"&#x25BC; ")+Math.abs(pc).toFixed(2)+"%";
      chgEl.className="mb-chg "+(up?"up":"down");
    }}
  }}
  function loadLiveData(){{
    fetch("/market/indices",{{credentials:"include"}})
      .then(function(r){{return r.ok?r.json():null;}})
      .then(function(data){{
        if(!data) return;
        var items=Array.isArray(data)?data:(data.indices||data.data||[]);
        var map={{}};
        items.forEach(function(item){{ var k=(item.symbol||item.index||"").toUpperCase().replace(/\W/g,""); map[k]=item; }});
        function g(keys){{ for(var i=0;i<keys.length;i++) if(map[keys[i]]) return map[keys[i]]; return null; }}
        applyIdx("px-nifty50","chg-nifty50",g(["NIFTY50","NIFTY"]));
        applyIdx("px-sensex","chg-sensex",g(["SENSEX","BSE30","BSE"]));
        applyIdx("px-banknifty","chg-banknifty",g(["BANKNIFTY","NIFTYBANK"]));
        applyIdx("px-inrusd","chg-inrusd",g(["USDINR","INRUSD","INR"]));
        applyMB("mb-niftyit","mbchg-niftyit",g(["NIFTYIT","IT"]));
        applyMB("mb-niftyauto","mbchg-niftyauto",g(["NIFTYAUTO","AUTO"]));
        applyMB("mb-niftyfmcg","mbchg-niftyfmcg",g(["NIFTYFMCG","FMCG"]));
        applyMB("mb-gold","mbchg-gold",g(["GOLD","GOLDFUT"]));
        applyMB("mb-crude","mbchg-crude",g(["CRUDEOIL","CRUDE","WTI"]));
        applyMB("mb-in10y","mbchg-in10y",g(["IN10Y","INDIA10Y","INDGB10Y"]));
      }}).catch(function(){{}});

    fetch("/market/quotes?symbols="+SYMS.join(","),{{credentials:"include"}})
      .then(function(r){{return r.ok?r.json():null;}})
      .then(function(data){{
        if(!data) return;
        var map={{}};
        if(Array.isArray(data)){{ data.forEach(function(q){{if(q.symbol)map[q.symbol]=q;}}); }}
        else{{ Object.keys(data).forEach(function(k){{map[k]=data[k];}}); }}
        var rows=[];
        SYMS.forEach(function(sym){{
          var q=map[sym]||map[sym+".NS"]||{{}};
          var pr=q.price||q.last_price||q.close||0;
          var pc=q.change_pct||q.changePct||q.pct_change||0;
          var up=+pc>=0;
          var px=pr>0?Number(pr).toLocaleString("en-IN",{{minimumFractionDigits:2,maximumFractionDigits:2}}):"&#x2014;";
          var cs=isFinite(+pc)?(up?"+":"")+Number(pc).toFixed(2)+"%":"&#x2014;";
          rows.push('<span class="tk"><span class="sym">'+sym+'</span><span class="px">'+px+'</span><span class="chg '+(up?"up":"down")+'"><span class="tri">'+(up?"&#x25B2;":"&#x25BC;")+'</span>'+cs+'</span></span>');
        }});
        if(rows.length && tt){{ tt.innerHTML=rows.join("")+rows.join(""); }}
      }}).catch(function(){{}});
  }}
  loadLiveData();
  setInterval(loadLiveData, 90000);

  /* ── Archive filter + search ── */
  window.__plArchive = true;
  (function(){{
    var search = document.getElementById("archive-search");
    var chips = document.querySelectorAll("[data-filter]");
    var items = document.querySelectorAll("[data-story]");
    var countEl = document.getElementById("story-count");
    var empty = document.getElementById("archive-empty");
    var active = "all", q = "";
    function apply(){{
      var n=0;
      items.forEach(function(it){{
        var type = it.getAttribute("data-type")||"";
        var ikg = it.getAttribute("data-ikg")||"no";
        var text = (it.getAttribute("data-search")||"").toLowerCase();
        var mf = active==="all" ? true : active==="ikg" ? ikg==="yes" : type===active;
        var ms = !q || text.indexOf(q)>-1;
        it.style.display = (mf&&ms) ? "" : "none";
        if(mf&&ms) n++;
      }});
      if(countEl) countEl.textContent = n+" "+(n===1?"story":"stories");
      if(empty) empty.style.display = (items.length>0&&n===0)?"block":"none";
    }}
    if(search) search.addEventListener("input", function(){{ q=search.value.toLowerCase().trim(); apply(); }});
    chips.forEach(function(c){{
      c.addEventListener("click", function(){{
        chips.forEach(function(x){{x.classList.remove("is-active");}});
        c.classList.add("is-active");
        active = c.getAttribute("data-filter");
        apply();
      }});
    }});
    apply();
  }})();

  /* ── Init ── */
  checkWatchers();
  setTimeout(checkWatchers, 120);
  setTimeout(checkWatchers, 600);
}})();
</script>
</body>
</html>
"""'''


# ─── Read current file ─────────────────────────────────────────────────────────
content = open(PATH, encoding='utf-8').read()

# ─── Find the return f-string block ───────────────────────────────────────────
START = '\n    return f"""<!doctype html>'
idx_start = content.find(START)
if idx_start == -1:
    # Maybe it's the v3 start already - find any return f"""
    START = '\n    return f"""'
    idx_start = content.rfind(START, 0, content.find('async def _build_ikg_context'))
    if idx_start == -1:
        raise RuntimeError("Could not find start of return f-string in _build_insights_hub_html_editorial")

# Find end: the closing """ on its own line followed by async def
idx_search = idx_start + len(START)
idx_end = None
while True:
    pos = content.find('\n"""', idx_search)
    if pos == -1:
        break
    after = content[pos+4:pos+60].lstrip('\r\n')
    if after.startswith('async def') or after.startswith('def ') or after.startswith('class '):
        idx_end = pos + 4
        break
    idx_search = pos + 1

if idx_end is None:
    raise RuntimeError("Could not find end of return f-string")

start_line = content[:idx_start].count('\n') + 1
end_line   = content[:idx_end].count('\n') + 1
print(f"Replacing lines {start_line}–{end_line}")

new_content = content[:idx_start] + NEW_TEMPLATE + content[idx_end:]

# ─── Syntax check then write ──────────────────────────────────────────────────
import ast
ast.parse(new_content)
print("Syntax OK")

open(PATH, 'w', encoding='utf-8').write(new_content)
print(f"Written. New line count: {new_content.count(chr(10))+1}")
print("Done ✓")
