
/* ─── ProspektLab Hub — interactions + live data ─── */
(function(){
  "use strict";
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ── Sticky header ── */
  var head = document.querySelector(".site-head");
  function onScroll(){ if(head) head.classList.toggle("is-stuck", window.scrollY > 8); }
  window.addEventListener("scroll", onScroll, {passive:true});
  onScroll();

  /* ── Mobile burger ── */
  var burger = document.getElementById("burger-btn");
  var mnav = document.getElementById("m-nav");
  if(burger && mnav){
    burger.addEventListener("click", function(){
      var open = mnav.classList.toggle("is-open");
      burger.classList.toggle("is-open", open);
      burger.setAttribute("aria-expanded", open ? "true" : "false");
      document.body.style.overflow = open ? "hidden" : "";
    });
    mnav.querySelectorAll("a").forEach(function(a){
      a.addEventListener("click", function(){
        mnav.classList.remove("is-open");
        burger.classList.remove("is-open");
        document.body.style.overflow = "";
      });
    });
  }

  /* ── Visibility engine ── */
  var watchers = [];
  function watch(el, cb, ratio){ watchers.push({el:el, cb:cb, off:ratio==null?0.88:ratio, done:false}); }
  function inView(el, ratio){
    var r = el.getBoundingClientRect();
    var vh = window.innerHeight || document.documentElement.clientHeight;
    if(r.height===0 && r.width===0) return false;
    return r.top < vh * ratio && r.bottom > -40;
  }
  var ticking = false;
  function checkWatchers(){
    ticking = false;
    for(var i=0;i<watchers.length;i++){
      var w=watchers[i]; if(w.done) continue;
      if(inView(w.el, w.off)){ w.done=true; w.cb(w.el); }
    }
  }
  function onWatchScroll(){ if(!ticking){ ticking=true; requestAnimationFrame(checkWatchers); setTimeout(checkWatchers,60); } }
  window.addEventListener("scroll", onWatchScroll, {passive:true});
  window.addEventListener("resize", onWatchScroll, {passive:true});

  /* ── Scroll reveal ── */
  function finalizeReveal(el){
    el.style.transition="none"; el.style.opacity="1"; el.style.transform="none";
    if(el.hasAttribute("data-reveal-stagger")){
      for(var i=0;i<el.children.length;i++){
        var c=el.children[i]; c.style.transition="none"; c.style.opacity="1"; c.style.transform="none";
      }
    }
  }
  document.querySelectorAll("[data-reveal], [data-reveal-stagger]").forEach(function(el){
    if(reduce){ el.classList.add("in"); finalizeReveal(el); return; }
    watch(el, function(t){
      if(t.hasAttribute("data-reveal-stagger")){
        var kids=t.children, base=parseFloat(t.getAttribute("data-stagger"))||80;
        for(var i=0;i<kids.length;i++) kids[i].style.transitionDelay=(i*base)+"ms";
      }
      t.classList.add("in");
      var delay=t.hasAttribute("data-reveal-stagger")?1100+t.children.length*90:1050;
      setTimeout(function(){ finalizeReveal(t); }, delay);
    });
  });

  /* ── Animated counters ── */
  function fmtNum(n, dec, prefix, suffix){
    var s = n.toLocaleString("en-IN", {minimumFractionDigits:dec, maximumFractionDigits:dec});
    return prefix + s + suffix;
  }
  function animateCount(el){
    var target = parseFloat(el.getAttribute("data-count"));
    var dec = parseInt(el.getAttribute("data-dec")||"0", 10);
    var prefix = el.getAttribute("data-prefix")||"";
    var suffix = el.getAttribute("data-suffix")||"";
    var dur = 1300, start = null;
    setTimeout(function(){ el.textContent = fmtNum(target,dec,prefix,suffix); }, 1450);
    if(reduce){ el.textContent = fmtNum(target,dec,prefix,suffix); return; }
    function step(ts){
      if(!start) start=ts;
      var p = Math.min((ts-start)/dur, 1);
      var eased = 1-Math.pow(1-p,3);
      el.textContent = fmtNum(target*eased, dec, prefix, suffix);
      if(p<1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }
  document.querySelectorAll("[data-count]").forEach(function(el){ watch(el, animateCount, 0.97); });

  /* ── Sparklines ── */
  function drawSpark(canvas, animate){
    var raw = canvas.getAttribute("data-spark"); if(!raw) return;
    var pts = raw.split(",").map(parseFloat);
    var up = canvas.getAttribute("data-dir") !== "down";
    var color = up ? "#34D399" : "#FB7185";
    var dpr = window.devicePixelRatio || 1;
    var rect = canvas.getBoundingClientRect();
    var w = rect.width || 96, h = rect.height || 34;
    canvas.width = Math.round(w*dpr); canvas.height = Math.round(h*dpr);
    var ctx = canvas.getContext("2d"); ctx.scale(dpr,dpr);
    var mn=Math.min.apply(null,pts), mx=Math.max.apply(null,pts), rng=mx-mn||1, pad=3;
    function x(i){ return pad+(i/(pts.length-1))*(w-pad*2); }
    function y(v){ return h-pad-((v-mn)/rng)*(h-pad*2); }
    function render(prog){
      ctx.clearRect(0,0,w,h);
      var n = Math.max(2, Math.round(pts.length*prog));
      var grad = ctx.createLinearGradient(0,0,0,h);
      grad.addColorStop(0, color+"33"); grad.addColorStop(1, color+"00");
      ctx.beginPath(); ctx.moveTo(x(0),y(pts[0]));
      for(var i=1;i<n;i++) ctx.lineTo(x(i),y(pts[i]));
      ctx.lineTo(x(n-1),h); ctx.lineTo(x(0),h); ctx.closePath();
      ctx.fillStyle=grad; ctx.fill();
      ctx.beginPath(); ctx.moveTo(x(0),y(pts[0]));
      for(var j=1;j<n;j++) ctx.lineTo(x(j),y(pts[j]));
      ctx.strokeStyle=color; ctx.lineWidth=1.6; ctx.lineJoin="round"; ctx.lineCap="round"; ctx.stroke();
      ctx.beginPath(); ctx.arc(x(n-1),y(pts[n-1]),2.2,0,Math.PI*2); ctx.fillStyle=color; ctx.fill();
    }
    render(reduce||!animate ? 1 : 0.001);
    if(reduce||!animate) return;
    var stt=null, dur=850, raf;
    function stepFn(ts){ if(!stt) stt=ts; var p=Math.min((ts-stt)/dur,1); render(1-Math.pow(1-p,2)); if(p<1) raf=requestAnimationFrame(stepFn); }
    raf = requestAnimationFrame(stepFn);
    setTimeout(function(){ if(raf) cancelAnimationFrame(raf); render(1); }, 950);
  }
  var sparkEls = document.querySelectorAll("[data-spark]");
  sparkEls.forEach(function(c){ watch(c, function(t){ drawSpark(t,true); }, 0.97); });
  function redrawSparks(){ sparkEls.forEach(function(c){ drawSpark(c,false); }); }
  window.addEventListener("resize", function(){ clearTimeout(window._sparkTimer); window._sparkTimer = setTimeout(redrawSparks,200); });

  /* ── Custom cursor ── */
  if(!window.matchMedia("(pointer: coarse)").matches){
    var dot=document.createElement("div"); dot.className="cursor-dot";
    var ring=document.createElement("div"); ring.className="cursor-ring";
    document.body.appendChild(dot); document.body.appendChild(ring);
    var mx=0,my=0,rx=0,ry=0;
    document.addEventListener("mousemove", function(e){
      mx=e.clientX; my=e.clientY;
      dot.style.transform="translate("+mx+"px,"+my+"px) translate(-50%,-50%)";
    });
    (function loop(){ rx+=(mx-rx)*0.18; ry+=(my-ry)*0.18; ring.style.transform="translate("+rx+"px,"+ry+"px) translate(-50%,-50%)"; requestAnimationFrame(loop); })();
    document.querySelectorAll("a,button,.chip,.story-card,[data-cursor]").forEach(function(el){
      el.addEventListener("mouseenter",function(){ring.classList.add("is-hover");});
      el.addEventListener("mouseleave",function(){ring.classList.remove("is-hover");});
    });
  }

  /* ── Magnetic buttons ── */
  if(!reduce && !window.matchMedia("(pointer: coarse)").matches){
    document.querySelectorAll(".magnetic").forEach(function(el){
      var str = parseFloat(el.getAttribute("data-mag"))||0.3;
      el.addEventListener("mousemove",function(e){
        var r=el.getBoundingClientRect();
        var mx2=e.clientX-(r.left+r.width/2), my2=e.clientY-(r.top+r.height/2);
        el.style.transform="translate("+mx2*str+"px,"+my2*str+"px)";
        var inn=el.firstElementChild; if(inn) inn.style.transform="translate("+mx2*str*0.5+"px,"+my2*str*0.5+"px)";
      });
      el.addEventListener("mouseleave",function(){
        el.style.transform=""; var inn=el.firstElementChild; if(inn) inn.style.transform="";
      });
    });
  }

  /* ── Ticker + Live quotes ── */
  var TICKER_DATA = [
    ["RELIANCE","2,948.20","+1.12%","up"],["TCS","4,012.55","+0.74%","up"],
    ["HDFCBANK","1,684.30","&#x2212;0.42%","down"],["INFY","1,612.90","+1.36%","up"],
    ["ICICIBANK","1,158.75","+0.58%","up"],["SBIN","842.10","&#x2212;0.21%","down"],
    ["BHARTIARTL","1,498.60","+0.92%","up"],["ITC","438.25","&#x2212;0.15%","down"],
    ["LT","3,604.40","+1.48%","up"],["AXISBANK","1,176.85","+0.33%","up"],
    ["KOTAKBANK","1,792.10","&#x2212;0.67%","down"],["HINDUNILVR","2,388.55","+0.27%","up"],
    ["ADANIENT","2,914.70","+2.04%","up"],["MARUTI","12,640.00","+0.88%","up"],
    ["SUNPHARMA","1,742.35","&#x2212;0.31%","down"]
  ];
  function buildTickerHtml(data){
    return data.map(function(d){
      return '<span class="tk"><span class="sym">'+d[0]+'</span><span class="px">'+d[1]+'</span><span class="chg '+d[3]+'"><span class="tri">'+(d[3]==="up"?"&#x25B2;":"&#x25BC;")+'</span>'+d[2]+'</span></span>';
    }).join("");
  }
  var tt = document.getElementById("ticker-track");
  if(tt){ var h=buildTickerHtml(TICKER_DATA); tt.innerHTML=h+h; }

  /* ── Live market data from backend ── */
  var SYMS = ["RELIANCE","TCS","HDFCBANK","INFY","ICICIBANK","SBIN","BHARTIARTL","ITC","LT","AXISBANK","KOTAKBANK","HINDUNILVR","ADANIENT","MARUTI","SUNPHARMA"];
  function toIN(v, dec){
    if(v==null||!isFinite(+v)) return null;
    return Number(v).toLocaleString("en-IN",{minimumFractionDigits:dec,maximumFractionDigits:dec});
  }
  function pct(p){
    if(p==null||!isFinite(+p)) return null;
    return (p>=0?"+":"")+Number(p).toFixed(2)+"%";
  }
  function applyIdx(idPx, idChg, q, fallbackPx, fallbackChg){
    var pxEl=document.getElementById(idPx), chgEl=document.getElementById(idChg);
    if(!pxEl) return;
    var pr = q&&(q.price||q.value||q.last);
    var pc = q&&(q.change_pct||q.pct_change||q.changePct);
    var prStr = pr!=null ? toIN(pr,2) : null;
    var pcStr = pc!=null ? pct(pc) : null;
    // Only override if we got real data (not null)
    if(prStr) pxEl.textContent = prStr;
    if(pcStr && chgEl){
      chgEl.textContent = pcStr;
      chgEl.className = "idx-chg "+(pc>=0?"up":"down");
    }
  }
  function applyMB(idPx, idChg, q){
    var pxEl=document.getElementById(idPx), chgEl=document.getElementById(idChg);
    if(!pxEl||!q) return;
    var pr = q.price||q.value||q.last;
    var pc = q.change_pct||q.pct_change||q.changePct;
    var prefix = pxEl.getAttribute("data-prefix")||"";
    var suffix = pxEl.getAttribute("data-suffix")||"";
    if(pr!=null){ var dec=parseInt(pxEl.getAttribute("data-dec")||"2",10); pxEl.textContent=prefix+toIN(pr,dec)+suffix; }
    if(pc!=null && chgEl){
      var up=pc>=0;
      chgEl.textContent=(up?"&#x25B2; +":"&#x25BC; ")+Math.abs(pc).toFixed(2)+"%";
      chgEl.className="mb-chg "+(up?"up":"down");
    }
  }
  function loadLiveData(){
    fetch("/market/indices",{credentials:"include"})
      .then(function(r){return r.ok?r.json():null;})
      .then(function(data){
        if(!data) return;
        var items=Array.isArray(data)?data:(data.indices||data.data||[]);
        var map={};
        items.forEach(function(item){ var k=(item.symbol||item.index||"").toUpperCase().replace(/\W/g,""); map[k]=item; });
        function g(keys){ for(var i=0;i<keys.length;i++) if(map[keys[i]]) return map[keys[i]]; return null; }
        applyIdx("px-nifty50","chg-nifty50",g(["NIFTY50","NIFTY"]));
        applyIdx("px-sensex","chg-sensex",g(["SENSEX","BSE30","BSE"]));
        applyIdx("px-banknifty","chg-banknifty",g(["BANKNIFTY","NIFTYBANK"]));
        applyIdx("px-inrusd","chg-inrusd",g(["USDINR","INRUSD","INR"]));
        applyMB("mb-niftyit","mbchg-niftyit",g(["NIFTYIT","IT"]));
        applyMB("mb-niftyauto","mbchg-niftyauto",g(["NIFTYAUTO","AUTO"]));
        applyMB("mb-niftyfmcg","mbchg-niftyfmcg",g(["NIFTYFMCG","FMCG"]));
        applyMB("mb-gold","mbchg-gold",g(["GOLD","GOLDFUT"]));
        applyMB("mb-crude","mbchg-crude",g(["CRUDEOIL","CRUDE","WTI"]));
        applyMB("mb-in10y","mbchg-in10y",g(["IN10Y","INDIA10Y","INDGB10Y"]));
      }).catch(function(){});

    fetch("/market/quotes?symbols="+SYMS.join(","),{credentials:"include"})
      .then(function(r){return r.ok?r.json():null;})
      .then(function(data){
        if(!data) return;
        var map={};
        if(Array.isArray(data)){ data.forEach(function(q){if(q.symbol)map[q.symbol]=q;}); }
        else{ Object.keys(data).forEach(function(k){map[k]=data[k];}); }
        var rows=[];
        SYMS.forEach(function(sym){
          var q=map[sym]||map[sym+".NS"]||{};
          var pr=q.price||q.last_price||q.close||0;
          var pc=q.change_pct||q.changePct||q.pct_change||0;
          var up=+pc>=0;
          var px=pr>0?Number(pr).toLocaleString("en-IN",{minimumFractionDigits:2,maximumFractionDigits:2}):"&#x2014;";
          var cs=isFinite(+pc)?(up?"+":"")+Number(pc).toFixed(2)+"%":"&#x2014;";
          rows.push('<span class="tk"><span class="sym">'+sym+'</span><span class="px">'+px+'</span><span class="chg '+(up?"up":"down")+'"><span class="tri">'+(up?"&#x25B2;":"&#x25BC;")+'</span>'+cs+'</span></span>');
        });
        if(rows.length && tt){ tt.innerHTML=rows.join("")+rows.join(""); }
      }).catch(function(){});
  }
  loadLiveData();
  setInterval(loadLiveData, 90000);

  /* ── Archive filter + search ── */
  window.__plArchive = true;
  (function(){
    var search = document.getElementById("archive-search");
    var chips = document.querySelectorAll("[data-filter]");
    var items = document.querySelectorAll("[data-story]");
    var countEl = document.getElementById("story-count");
    var empty = document.getElementById("archive-empty");
    var active = "all", q = "";
    function apply(){
      var n=0;
      items.forEach(function(it){
        var type = it.getAttribute("data-type")||"";
        var ikg = it.getAttribute("data-ikg")||"no";
        var text = (it.getAttribute("data-search")||"").toLowerCase();
        var mf = active==="all" ? true : active==="ikg" ? ikg==="yes" : type===active;
        var ms = !q || text.indexOf(q)>-1;
        it.style.display = (mf&&ms) ? "" : "none";
        if(mf&&ms) n++;
      });
      if(countEl) countEl.textContent = n+" "+(n===1?"story":"stories");
      if(empty) empty.style.display = (items.length>0&&n===0)?"block":"none";
    }
    if(search) search.addEventListener("input", function(){ q=search.value.toLowerCase().trim(); apply(); });
    chips.forEach(function(c){
      c.addEventListener("click", function(){
        chips.forEach(function(x){x.classList.remove("is-active");});
        c.classList.add("is-active");
        active = c.getAttribute("data-filter");
        apply();
      });
    });
    apply();
  })();

  /* ── Init ── */
  checkWatchers();
  setTimeout(checkWatchers, 120);
  setTimeout(checkWatchers, 600);
})();
