"""Local SQLite state store for rate limiting, verification codes, pending extractions, and token revocation.

Uses the existing WAL-mode SQLite pattern so it survives restarts and provides
durable, non-Redis shared state within a single host. Supabase-backed
functions in supabase_client.py fall back to this store when Supabase is
unavailable or the tables are not yet created.

Thread safety: each public function opens a fresh connection. SQLite
WAL mode handles concurrent readers; writers serialize on the WAL lock.
"""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Any

from finagent.paths import finagent_data_path
from finagent.storage.sqlite import connect_wal

logger = logging.getLogger("finagent.gateway.state")


def _state_db_path() -> Path:
    return finagent_data_path("state.sqlite3")


def _init_state_db() -> None:
    path = _state_db_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with connect_wal(path, timeout=5.0) as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS rate_limits (
                key TEXT PRIMARY KEY,
                count INTEGER NOT NULL DEFAULT 0,
                window_start REAL NOT NULL
            );

            CREATE TABLE IF NOT EXISTS verification_codes (
                email TEXT NOT NULL,
                code TEXT NOT NULL,
                type TEXT NOT NULL DEFAULT 'signup',
                created_at REAL NOT NULL,
                PRIMARY KEY (email, type)
            );

            CREATE TABLE IF NOT EXISTS pending_extractions (
                review_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at REAL NOT NULL
            );

            CREATE TABLE IF NOT EXISTS revoked_tokens (
                jti TEXT PRIMARY KEY,
                revoked_at REAL NOT NULL,
                expires_at REAL NOT NULL
            );

            CREATE TABLE IF NOT EXISTS outreach_unsubscribes (
                email TEXT PRIMARY KEY,
                reason TEXT NOT NULL DEFAULT 'unsubscribe',
                source TEXT NOT NULL DEFAULT 'public_page',
                note TEXT NOT NULL DEFAULT '',
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL
            );

            CREATE TABLE IF NOT EXISTS outreach_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                owner_email TEXT NOT NULL,
                message_id INTEGER,
                event_type TEXT NOT NULL DEFAULT '',
                provider TEXT NOT NULL DEFAULT '',
                event_payload TEXT NOT NULL DEFAULT '{}',
                occurred_at REAL NOT NULL,
                created_at REAL NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_pending_tenant
            ON pending_extractions(tenant_id);
            """
        )


# ── Rate limiting ──────────────────────────────────────────────────────────

def check_rate_limit(key: str, limit: int, window_seconds: int) -> bool:
    """Atomically check and increment a rate limit counter.
    Returns True if the request is allowed, False if the limit is exceeded.
    """
    _init_state_db()
    now = time.time()
    with connect_wal(_state_db_path(), timeout=5.0) as conn:
        # Purge expired windows
        conn.execute("DELETE FROM rate_limits WHERE window_start < ?", (now - window_seconds,))
        row = conn.execute(
            "SELECT count, window_start FROM rate_limits WHERE key = ?", (key,)
        ).fetchone()
        if row:
            count, window_start = row
            if now - window_start < window_seconds:
                if count >= limit:
                    return False
                conn.execute(
                    "UPDATE rate_limits SET count = count + 1 WHERE key = ?", (key,)
                )
                return True
        # New window
        conn.execute(
            "INSERT OR REPLACE INTO rate_limits (key, count, window_start) VALUES (?, 1, ?)",
            (key, now),
        )
        return True


# ── Verification codes ───────────────────────────────────────────────────

def store_verification_code(email: str, code: str, type_: str = "signup") -> None:
    _init_state_db()
    with connect_wal(_state_db_path(), timeout=5.0) as conn:
        conn.execute(
            "INSERT OR REPLACE INTO verification_codes (email, code, type, created_at) VALUES (?, ?, ?, ?)",
            (email.lower().strip(), code, type_, time.time()),
        )


def verify_and_consume_code(email: str, code: str, type_: str = "signup", ttl_seconds: int = 600) -> bool:
    _init_state_db()
    now = time.time()
    with connect_wal(_state_db_path(), timeout=5.0) as conn:
        row = conn.execute(
            "SELECT code, created_at FROM verification_codes WHERE email = ? AND type = ?",
            (email.lower().strip(), type_),
        ).fetchone()
        if not row:
            return False
        stored_code, created_at = row
        if now - created_at > ttl_seconds:
            conn.execute(
                "DELETE FROM verification_codes WHERE email = ? AND type = ?",
                (email.lower().strip(), type_),
            )
            return False
        if stored_code != code.strip():
            return False
        conn.execute(
            "DELETE FROM verification_codes WHERE email = ? AND type = ?",
            (email.lower().strip(), type_),
        )
        return True


# ── Pending extractions ──────────────────────────────────────────────────

def store_pending_extraction(review_id: str, tenant_id: str, payload: dict[str, Any]) -> None:
    _init_state_db()
    with connect_wal(_state_db_path(), timeout=5.0) as conn:
        conn.execute(
            "INSERT OR REPLACE INTO pending_extractions (review_id, tenant_id, payload_json, created_at) VALUES (?, ?, ?, ?)",
            (review_id, tenant_id, json.dumps(payload), time.time()),
        )


def get_pending_extraction(review_id: str) -> dict[str, Any] | None:
    _init_state_db()
    with connect_wal(_state_db_path(), timeout=5.0) as conn:
        row = conn.execute(
            "SELECT tenant_id, payload_json FROM pending_extractions WHERE review_id = ?",
            (review_id,),
        ).fetchone()
        if not row:
            return None
        return {"tenant_id": row[0], "extraction": json.loads(row[1])}


def get_pending_extractions_by_tenant(tenant_id: str) -> list[dict[str, Any]]:
    _init_state_db()
    with connect_wal(_state_db_path(), timeout=5.0) as conn:
        rows = conn.execute(
            "SELECT review_id, payload_json FROM pending_extractions WHERE tenant_id = ?",
            (tenant_id,),
        ).fetchall()
        return [{"review_id": r[0], **json.loads(r[1])} for r in rows]


def delete_pending_extraction(review_id: str) -> None:
    _init_state_db()
    with connect_wal(_state_db_path(), timeout=5.0) as conn:
        conn.execute("DELETE FROM pending_extractions WHERE review_id = ?", (review_id,))


# ── Token revocation ─────────────────────────────────────────────────────

def is_token_revoked(jti: str) -> bool:
    _init_state_db()
    now = time.time()
    with connect_wal(_state_db_path(), timeout=5.0) as conn:
        conn.execute("DELETE FROM revoked_tokens WHERE expires_at < ?", (now,))
        row = conn.execute("SELECT 1 FROM revoked_tokens WHERE jti = ?", (jti,)).fetchone()
        return row is not None


def revoke_token(jti: str, expires_at: float) -> None:
    _init_state_db()
    with connect_wal(_state_db_path(), timeout=5.0) as conn:
        conn.execute(
            "INSERT OR REPLACE INTO revoked_tokens (jti, revoked_at, expires_at) VALUES (?, ?, ?)",
            (jti, time.time(), expires_at),
        )


# -- Outreach unsubscribe state -------------------------------------------------

def store_outreach_unsubscribe(
    email: str,
    reason: str = "unsubscribe",
    source: str = "public_page",
    note: str = "",
) -> dict[str, Any]:
    _init_state_db()
    now = time.time()
    normalized = email.lower().strip()
    with connect_wal(_state_db_path(), timeout=5.0) as conn:
        conn.execute(
            """
            INSERT INTO outreach_unsubscribes (email, reason, source, note, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(email) DO UPDATE SET
                reason = excluded.reason,
                source = excluded.source,
                note = excluded.note,
                updated_at = excluded.updated_at
            """,
            (normalized, reason, source, note, now, now),
        )
    return {
        "email": normalized,
        "reason": reason,
        "source": source,
        "note": note,
        "created_at": now,
        "updated_at": now,
    }


def list_outreach_unsubscribes() -> list[dict[str, Any]]:
    _init_state_db()
    with connect_wal(_state_db_path(), timeout=5.0) as conn:
        rows = conn.execute(
            """
            SELECT email, reason, source, note, created_at, updated_at
            FROM outreach_unsubscribes
            ORDER BY updated_at DESC, email ASC
            """
        ).fetchall()
    return [
        {
            "email": row[0],
            "reason": row[1],
            "source": row[2],
            "note": row[3],
            "created_at": row[4],
            "updated_at": row[5],
        }
        for row in rows
    ]


# ── Outreach event state -----------------------------------------------------

def store_outreach_event(
    owner_email: str,
    event_type: str,
    *,
    provider: str = "",
    message_id: int | None = None,
    event_payload: dict[str, Any] | None = None,
    occurred_at: float | None = None,
) -> dict[str, Any]:
    _init_state_db()
    now = time.time()
    occurred_value = occurred_at if occurred_at is not None else now
    normalized_owner = owner_email.lower().strip()
    normalized_type = (event_type or "").strip().lower()
    normalized_provider = (provider or "").strip()
    payload_text = json.dumps(event_payload or {}, ensure_ascii=False)
    with connect_wal(_state_db_path(), timeout=5.0) as conn:
        conn.execute(
            """
            INSERT INTO outreach_events (
                owner_email,
                message_id,
                event_type,
                provider,
                event_payload,
                occurred_at,
                created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                normalized_owner,
                message_id,
                normalized_type,
                normalized_provider,
                payload_text,
                occurred_value,
                now,
            ),
        )
    return {
        "owner_email": normalized_owner,
        "message_id": message_id,
        "event_type": normalized_type,
        "provider": normalized_provider,
        "event_payload": event_payload or {},
        "occurred_at": occurred_value,
        "created_at": now,
    }


def list_outreach_events() -> list[dict[str, Any]]:
    _init_state_db()
    with connect_wal(_state_db_path(), timeout=5.0) as conn:
        rows = conn.execute(
            """
            SELECT owner_email, message_id, event_type, provider, event_payload, occurred_at, created_at
            FROM outreach_events
            ORDER BY occurred_at DESC, created_at DESC
            """
        ).fetchall()
    return [
        {
            "owner_email": row[0],
            "message_id": row[1],
            "event_type": row[2],
            "provider": row[3],
            "event_payload": _safe_json_loads(row[4]),
            "occurred_at": row[5],
            "created_at": row[6],
        }
        for row in rows
    ]


def _safe_json_loads(raw: object) -> dict[str, Any]:
    if isinstance(raw, dict):
        return raw
    if raw is None:
        return {}
    try:
        parsed = json.loads(str(raw))
        return parsed if isinstance(parsed, dict) else {}
    except Exception:
        return {}


# ── Periodic cleanup ─────────────────────────────────────────────────────

def cleanup_old_state(ttl_seconds: int = 3600) -> None:
    """Call periodically to purge old verification codes and pending extractions.
    Also cleans expired rate-limit windows and revoked tokens.
    """
    _init_state_db()
    now = time.time()
    with connect_wal(_state_db_path(), timeout=5.0) as conn:
        # Verification codes older than TTL
        cur = conn.execute("DELETE FROM verification_codes WHERE created_at < ?", (now - ttl_seconds,))
        if cur.rowcount:
            logger.info("Cleaned %d expired verification codes", cur.rowcount)
        # Pending extractions older than 24 hours
        cur = conn.execute("DELETE FROM pending_extractions WHERE created_at < ?", (now - 86400,))
        if cur.rowcount:
            logger.info("Cleaned %d expired pending extractions", cur.rowcount)
        # Rate limit windows (sweep is also done per-key, but this catches stragglers)
        cur = conn.execute("DELETE FROM rate_limits WHERE window_start < ?", (now - 3600,))
        if cur.rowcount:
            logger.info("Cleaned %d stale rate-limit windows", cur.rowcount)
        # Expired revoked tokens
        cur = conn.execute("DELETE FROM revoked_tokens WHERE expires_at < ?", (now,))
        if cur.rowcount:
            logger.info("Cleaned %d expired revoked tokens", cur.rowcount)
