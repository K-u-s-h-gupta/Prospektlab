import urllib.request
resp = urllib.request.urlopen('http://localhost:3000/insights/research/')
html = resp.read().decode('utf-8')
print('Starts with:', html[:100])
print('Has ticker:', 'ticker-track' in html)
print('Has react root:', 'id="root"' in html)
