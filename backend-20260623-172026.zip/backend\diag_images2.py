"""Check if cover images are actually accessible via GET."""
import urllib.request

images = [
    "/insights/earnings-generate-a-publication-grade-research-analysis-of-britannia-industries-3qfy25-r-v2/cover.png",
    "/insights/manual-tcs-q3-fy25-earnings-overview/cover.png",
    "/research-images/sebi-ace.svg",
]

for img in images:
    for port in [8000, 3000]:
        url = f"http://localhost:{port}{img}"
        try:
            resp = urllib.request.urlopen(url, timeout=5)
            ct = resp.headers.get("Content-Type", "?")
            data = resp.read()
            print(f"  :{port} {img[-60:]} -> {resp.status} ({ct}, {len(data)} bytes)")
        except urllib.error.HTTPError as e:
            print(f"  :{port} {img[-60:]} -> HTTP {e.code}: {e.reason}")
        except Exception as e:
            print(f"  :{port} {img[-60:]} -> ERROR: {e}")
    print()
