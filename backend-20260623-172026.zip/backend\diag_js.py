"""Extract and validate all JS blocks from the hub HTML."""
import urllib.request
import re
import subprocess
import tempfile
import os

resp = urllib.request.urlopen("http://127.0.0.1:8000/insights/research/")
html = resp.read().decode("utf-8")

# Extract all <script> blocks
scripts = re.findall(r'<script[^>]*>(.*?)</script>', html, re.DOTALL)
print(f"Found {len(scripts)} script blocks\n")

for i, js in enumerate(scripts):
    js = js.strip()
    if not js:
        continue
    if js.startswith('{'):  # JSON-LD
        print(f"Script {i}: JSON-LD ({len(js)} chars) — skipped")
        continue
    
    print(f"Script {i}: JS ({len(js)} chars)")
    
    # Write to temp file and check with node
    tmp = os.path.join(tempfile.gettempdir(), f"hub_script_{i}.js")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(js)
    
    result = subprocess.run(
        ["node", "--check", tmp],
        capture_output=True, text=True
    )
    if result.returncode == 0:
        print(f"  Syntax: OK")
    else:
        print(f"  Syntax: ERROR")
        print(f"  {result.stderr.strip()}")
    
    # Show first/last few lines for context
    lines = js.split('\n')
    print(f"  Lines: {len(lines)}")
    print(f"  First line: {lines[0][:100]}")
    print(f"  Last line:  {lines[-1][:100]}")
    print()
