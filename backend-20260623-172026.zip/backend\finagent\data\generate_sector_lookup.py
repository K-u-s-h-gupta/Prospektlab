# Generate a starter ISIN→sector lookup JSON for Nifty 50 + key midcaps.
# Run: python generate_sector_lookup.py

import json
from pathlib import Path

# fmt: off
_ENTRIES = [
    # Nifty 50 core
    {"isin": "INE002A01018", "symbol": "RELIANCE",   "exchange": "NSE", "name": "Reliance Industries Limited",        "sector": "Oil Gas & Consumable Fuels",   "industry": "Refineries & Marketing"},
    {"isin": "INE467B01029", "symbol": "TCS",        "exchange": "NSE", "name": "Tata Consultancy Services Limited",   "sector": "Information Technology",       "industry": "IT Services & Consulting"},
    {"isin": "INE040A01034", "symbol": "HDFCBANK",   "exchange": "NSE", "name": "HDFC Bank Limited",                "sector": "Financial Services",           "industry": "Private Banks"},
    {"isin": "INE090A01021", "symbol": "ICICIBANK",  "exchange": "NSE", "name": "ICICI Bank Limited",               "sector": "Financial Services",           "industry": "Private Banks"},
    {"isin": "INE009A01021", "symbol": "INFY",       "exchange": "NSE", "name": "Infosys Limited",                  "sector": "Information Technology",       "industry": "IT Services & Consulting"},
    {"isin": "INE062A01020", "symbol": "SBIN",       "exchange": "NSE", "name": "State Bank of India",              "sector": "Financial Services",           "industry": "Public Banks"},
    {"isin": "INE397D01024", "symbol": "BHARTIARTL","exchange": "NSE", "name": "Bharti Airtel Limited",            "sector": "Telecommunication",            "industry": "Telecom Services"},
    {"isin": "INE030A01027", "symbol": "HINDUNILVR", "exchange": "NSE", "name": "Hindustan Unilever Limited",       "sector": "Fast Moving Consumer Goods",   "industry": "FMCG - Household Products"},
    {"isin": "INE154A01025", "symbol": "ITC",        "exchange": "NSE", "name": "ITC Limited",                      "sector": "Fast Moving Consumer Goods",   "industry": "FMCG - Tobacco"},
    {"isin": "INE237A01028", "symbol": "KOTAKBANK",  "exchange": "NSE", "name": "Kotak Mahindra Bank Limited",      "sector": "Financial Services",           "industry": "Private Banks"},
    {"isin": "INE018A01030", "symbol": "LT",         "exchange": "NSE", "name": "Larsen & Toubro Limited",          "sector": "Construction",                 "industry": "Engineering & Construction"},
    {"isin": "INE238A01034", "symbol": "AXISBANK",   "exchange": "NSE", "name": "Axis Bank Limited",                "sector": "Financial Services",           "industry": "Private Banks"},
    {"isin": "INE021A01026", "symbol": "ASIANPAINT", "exchange": "NSE", "name": "Asian Paints Limited",             "sector": "Consumer Durables",            "industry": "Paints"},
    {"isin": "INE585B01010", "symbol": "MARUTI",     "exchange": "NSE", "name": "Maruti Suzuki India Limited",      "sector": "Automobile and Auto Components","industry": "Passenger Cars"},
    {"isin": "INE155A01029", "symbol": "TATAMOTORS", "exchange": "NSE", "name": "Tata Motors Limited",              "sector": "Automobile and Auto Components","industry": "Passenger Cars"},
    {"isin": "INE044A01036", "symbol": "SUNPHARMA",  "exchange": "NSE", "name": "Sun Pharmaceutical Industries Limited", "sector": "Healthcare",              "industry": "Pharmaceuticals"},
    {"isin": "INE280A01028", "symbol": "TITAN",      "exchange": "NSE", "name": "Titan Company Limited",            "sector": "Consumer Durables",            "industry": "Watches & Jewellery"},
    {"isin": "INE481G01011", "symbol": "ULTRACEMCO", "exchange": "NSE", "name": "UltraTech Cement Limited",         "sector": "Construction Materials",       "industry": "Cement"},
    {"isin": "INE239A01016", "symbol": "NESTLEIND",  "exchange": "NSE", "name": "Nestle India Limited",             "sector": "Fast Moving Consumer Goods",   "industry": "FMCG - Foods"},
    {"isin": "INE752E01010", "symbol": "POWERGRID",  "exchange": "NSE", "name": "Power Grid Corporation of India Limited", "sector": "Power",                  "industry": "Power Transmission"},
    {"isin": "INE101A01026", "symbol": "M&M",        "exchange": "NSE", "name": "Mahindra & Mahindra Limited",      "sector": "Automobile and Auto Components","industry": "Tractors"},
    {"isin": "INE075A01022", "symbol": "WIPRO",      "exchange": "NSE", "name": "Wipro Limited",                    "sector": "Information Technology",       "industry": "IT Services & Consulting"},
    {"isin": "INE423A01024", "symbol": "ADANIENT",   "exchange": "NSE", "name": "Adani Enterprises Limited",        "sector": "Metals & Mining",              "industry": "Trading"},
    {"isin": "INE742F01042", "symbol": "ADANIPORTS", "exchange": "NSE", "name": "Adani Ports and Special Economic Zone Limited", "sector": "Services", "industry": "Port & Port Services"},
    {"isin": "INE047A01021", "symbol": "GRASIM",     "exchange": "NSE", "name": "Grasim Industries Limited",        "sector": "Construction Materials",       "industry": "Cement & Cement Products"},
    {"isin": "INE860A01027", "symbol": "HCLTECH",    "exchange": "NSE", "name": "HCL Technologies Limited",         "sector": "Information Technology",       "industry": "IT Services & Consulting"},
    {"isin": "INE019A01038", "symbol": "JSWSTEEL",   "exchange": "NSE", "name": "JSW Steel Limited",                "sector": "Metals & Mining",              "industry": "Iron & Steel"},
    {"isin": "INE669C01036", "symbol": "TECHM",      "exchange": "NSE", "name": "Tech Mahindra Limited",            "sector": "Information Technology",       "industry": "IT Services & Consulting"},
    {"isin": "INE213A01029", "symbol": "ONGC",       "exchange": "NSE", "name": "Oil and Natural Gas Corporation Limited", "sector": "Oil Gas & Consumable Fuels", "industry": "Exploration & Production"},
    {"isin": "INE733E01010", "symbol": "NTPC",       "exchange": "NSE", "name": "NTPC Limited",                     "sector": "Power",                        "industry": "Power Generation"},
    {"isin": "INE522F01014", "symbol": "COALINDIA",  "exchange": "NSE", "name": "Coal India Limited",               "sector": "Metals & Mining",              "industry": "Coal"},
    {"isin": "INE081A01020", "symbol": "TATASTEEL",  "exchange": "NSE", "name": "Tata Steel Limited",               "sector": "Metals & Mining",              "industry": "Iron & Steel"},
    {"isin": "INE795G01014", "symbol": "HDFCLIFE",   "exchange": "NSE", "name": "HDFC Life Insurance Company Limited", "sector": "Financial Services",        "industry": "Life Insurance"},
    {"isin": "INE123W01016", "symbol": "SBILIFE",    "exchange": "NSE", "name": "SBI Life Insurance Company Limited", "sector": "Financial Services",         "industry": "Life Insurance"},
    {"isin": "INE029A01011", "symbol": "BPCL",       "exchange": "NSE", "name": "Bharat Petroleum Corporation Limited", "sector": "Oil Gas & Consumable Fuels", "industry": "Refineries & Marketing"},
    {"isin": "INE216A01030", "symbol": "BRITANNIA",  "exchange": "NSE", "name": "Britannia Industries Limited",     "sector": "Fast Moving Consumer Goods",   "industry": "FMCG - Foods"},
    {"isin": "INE059A01026", "symbol": "CIPLA",      "exchange": "NSE", "name": "Cipla Limited",                    "sector": "Healthcare",                   "industry": "Pharmaceuticals"},
    {"isin": "INE089A01029", "symbol": "DRREDDY",    "exchange": "NSE", "name": "Dr. Reddy's Laboratories Limited", "sector": "Healthcare",                   "industry": "Pharmaceuticals"},
    {"isin": "INE066A01021", "symbol": "EICHERMOT",  "exchange": "NSE", "name": "Eicher Motors Limited",            "sector": "Automobile and Auto Components","industry": "2/3 Wheelers"},
    {"isin": "INE038A01020", "symbol": "HINDALCO",   "exchange": "NSE", "name": "Hindalco Industries Limited",      "sector": "Metals & Mining",              "industry": "Aluminium"},
    {"isin": "INE095A01012", "symbol": "INDUSINDBK", "exchange": "NSE", "name": "IndusInd Bank Limited",            "sector": "Financial Services",           "industry": "Private Banks"},
    {"isin": "INE242A01010", "symbol": "IOC",        "exchange": "NSE", "name": "Indian Oil Corporation Limited",   "sector": "Oil Gas & Consumable Fuels",   "industry": "Refineries & Marketing"},
    {"isin": "INE318A01026", "symbol": "PIDILITIND", "exchange": "NSE", "name": "Pidilite Industries Limited",    "sector": "Chemicals",                    "industry": "Specialty Chemicals"},
    {"isin": "INE070A01043", "symbol": "SHREECEM",   "exchange": "NSE", "name": "Shree Cement Limited",             "sector": "Construction Materials",       "industry": "Cement"},
    {"isin": "INE192A01025", "symbol": "TATACONSUM", "exchange": "NSE", "name": "Tata Consumer Products Limited",   "sector": "Fast Moving Consumer Goods",   "industry": "FMCG - Foods"},
    {"isin": "INE849A01020", "symbol": "TRENT",      "exchange": "NSE", "name": "Trent Limited",                    "sector": "Consumer Services",            "industry": "Apparel Retail"},
    {"isin": "INE296A01024", "symbol": "BAJFINANCE", "exchange": "NSE", "name": "Bajaj Finance Limited",            "sector": "Financial Services",           "industry": "Non Banking Financial Company"},
    {"isin": "INE918I01018", "symbol": "BAJAJFINSV","exchange": "NSE", "name": "Bajaj Finserv Limited",            "sector": "Financial Services",           "industry": "Insurance"},
    {"isin": "INE361B01024", "symbol": "DIVISLAB",   "exchange": "NSE", "name": "Divi's Laboratories Limited",    "sector": "Healthcare",                   "industry": "Pharmaceuticals"},
    {"isin": "INE437A01024", "symbol": "APOLLOHOSP", "exchange": "NSE", "name": "Apollo Hospitals Enterprise Limited", "sector": "Healthcare",              "industry": "Hospital"},
    {"isin": "INE917I01010", "symbol": "BAJAJ-AUTO", "exchange": "NSE", "name": "Bajaj Auto Limited",               "sector": "Automobile and Auto Components","industry": "2/3 Wheelers"},
    {"isin": "INE263A01024", "symbol": "BEL",        "exchange": "NSE", "name": "Bharat Electronics Limited",       "sector": "Capital Goods",                "industry": "Aerospace & Defense"},
    {"isin": "INE158A01026", "symbol": "HEROMOTOCO", "exchange": "NSE", "name": "Hero MotoCorp Limited",            "sector": "Automobile and Auto Components","industry": "2/3 Wheelers"},
    # Key midcaps / liquid stocks
    {"isin": "INE854D01024", "symbol": "UNITDSPR",   "exchange": "NSE", "name": "United Spirits Limited",           "sector": "Fast Moving Consumer Goods",   "industry": "Beverages"},
    {"isin": "INE797F01012", "symbol": "JUBLFOOD",   "exchange": "NSE", "name": "Jubilant FoodWorks Limited",       "sector": "Consumer Services",            "industry": "Restaurant & QSR"},
    {"isin": "INE245A01021", "symbol": "TATAPOWER",  "exchange": "NSE", "name": "Tata Power Company Limited",       "sector": "Power",                        "industry": "Power Generation"},
    {"isin": "INE758T01015", "symbol": "ZOMATO",     "exchange": "NSE", "name": "Zomato Limited",                   "sector": "Consumer Services",            "industry": "Online Services"},
    {"isin": "INE982J01020", "symbol": "PAYTM",      "exchange": "NSE", "name": "One 97 Communications Limited",  "sector": "Consumer Services",            "industry": "Online Services"},
    {"isin": "INE455K01017", "symbol": "POLYCAB",    "exchange": "NSE", "name": "Polycab India Limited",            "sector": "Capital Goods",                "industry": "Cables"},
    {"isin": "INE160A01022", "symbol": "PNB",        "exchange": "NSE", "name": "Punjab National Bank",             "sector": "Financial Services",           "industry": "Public Banks"},
    {"isin": "INE476A01014", "symbol": "CANBK",      "exchange": "NSE", "name": "Canara Bank",                      "sector": "Financial Services",           "industry": "Public Banks"},
    {"isin": "INE028A01039", "symbol": "BANKBARODA", "exchange": "NSE", "name": "Bank of Baroda",                   "sector": "Financial Services",           "industry": "Public Banks"},
    {"isin": "INE129A01019", "symbol": "GAIL",       "exchange": "NSE", "name": "GAIL (India) Limited",             "sector": "Oil Gas & Consumable Fuels",   "industry": "Gas Distribution"},
    {"isin": "INE205A01025", "symbol": "VEDL",       "exchange": "NSE", "name": "Vedanta Limited",                  "sector": "Metals & Mining",              "industry": "Diversified Metals"},
    {"isin": "INE092A01019", "symbol": "TATACHEM",   "exchange": "NSE", "name": "Tata Chemicals Limited",           "sector": "Chemicals",                    "industry": "Specialty Chemicals"},
    {"isin": "INE066F01012", "symbol": "HAL",        "exchange": "NSE", "name": "Hindustan Aeronautics Limited",    "sector": "Capital Goods",                "industry": "Aerospace & Defense"},
    {"isin": "INE335Y01012", "symbol": "IRCTC",      "exchange": "NSE", "name": "Indian Railway Catering and Tourism Corporation Limited", "sector": "Consumer Services", "industry": "Travel Services"},
    {"isin": "INE115A01026", "symbol": "LICHSGFIN",  "exchange": "NSE", "name": "LIC Housing Finance Limited",      "sector": "Financial Services",           "industry": "Housing Finance"},
    {"isin": "INE271C01023", "symbol": "DLF",        "exchange": "NSE", "name": "DLF Limited",                      "sector": "Realty",                       "industry": "Real Estate"},
    {"isin": "INE102A01028", "symbol": "GODREJCP",   "exchange": "NSE", "name": "Godrej Consumer Products Limited", "sector": "Fast Moving Consumer Goods",   "industry": "FMCG - Household Products"},
    {"isin": "INE196A01026", "symbol": "MARICO",     "exchange": "NSE", "name": "Marico Limited",                   "sector": "Fast Moving Consumer Goods",   "industry": "FMCG - Household Products"},
    {"isin": "INE259A01022", "symbol": "COLPAL",     "exchange": "NSE", "name": "Colgate-Palmolive (India) Limited","sector": "Fast Moving Consumer Goods",   "industry": "FMCG - Personal Products"},
    {"isin": "INE463A01038", "symbol": "BERGEPAINT", "exchange": "NSE", "name": "Berger Paints India Limited",      "sector": "Consumer Durables",            "industry": "Paints"},
    {"isin": "INE062A01336", "symbol": "SBICARD",    "exchange": "NSE", "name": "SBI Cards and Payment Services Limited", "sector": "Financial Services",     "industry": "Consumer Finance"},
    {"isin": "INE079A01024", "symbol": "MRF",        "exchange": "NSE", "name": "MRF Limited",                      "sector": "Automobile and Auto Components","industry": "Tyres"},
    {"isin": "INE010A01011", "symbol": "TVSMOTOR",   "exchange": "NSE", "name": "TVS Motor Company Limited",        "sector": "Automobile and Auto Components","industry": "2/3 Wheelers"},
    {"isin": "INE104A01012", "symbol": "BOSCHLTD",   "exchange": "NSE", "name": "Bosch Limited",                    "sector": "Automobile and Auto Components","industry": "Auto Components"},
    {"isin": "INE154A01029", "symbol": "ITC",        "exchange": "BSE", "name": "ITC Limited",                      "sector": "Fast Moving Consumer Goods",   "industry": "FMCG - Tobacco"},
]
# fmt: on

def generate() -> None:
    out = {}
    for e in _ENTRIES:
        isin = e["isin"]
        out[isin] = {
            "symbol": e["symbol"],
            "exchange": e["exchange"],
            "name": e["name"],
            "sector": e["sector"],
            "industry": e["industry"],
        }
    root = Path(__file__).resolve().parent.parent / "data" / "nifty500_sectors.json"
    root.parent.mkdir(parents=True, exist_ok=True)
    root.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(f"Wrote {len(out)} entries to {root}")

if __name__ == "__main__":
    generate()
