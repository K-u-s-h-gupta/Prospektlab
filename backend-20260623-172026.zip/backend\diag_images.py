"""Check if cover images are actually accessible via the proxy."""
import urllib.request

images = [
    "/insights/earnings-generate-a-publication-grade-research-analysis-of-britannia-industries-3qfy25-r-v2/cover.png",
    "/insights/manual-tcs-q3-fy25-earnings-overview/cover.png",
    "/research-images/sebi-ace.svg",
    "/prospektlab-favicon-v2.svg",
]

for img in images:
    for port in [8000, 3000]:
        url = f"http://localhost:{port}{img}"
        try:
            req = urllib.request.Request(url, method="HEAD")
            resp = urllib.request.urlopen(req, timeout=5)
            ct = resp.headers.get("Content-Type", "?")
            cl = resp.headers.get("Content-Length", "?")
            print(f"  :{port} {img[:60]}... -> {resp.status} ({ct}, {cl} bytes)")
        except Exception as e:
            print(f"  :{port} {img[:60]}... -> ERROR: {e}")
    print()
