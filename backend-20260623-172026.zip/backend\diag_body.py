"""Check actual body-level ordering and look for rendering-breaking issues."""
import urllib.request
import re

resp = urllib.request.urlopen("http://127.0.0.1:8000/insights/research/")
html = resp.read().decode("utf-8")

# Extract body content only
body_start = html.find('<body>') + 6
body_end = html.find('</body>')
body = html[body_start:body_end]

# Check section order in body only
sections = [
    ('Ticker', 'id="ticker-track"'),
    ('Header', 'class="site-head"'),
    ('Mobile nav', 'class="m-nav"'),
    ('Main open', '<main>'),
    ('Hero section', 'class="section hero"'),
    ('Market Band', 'class="section market-band"'),
    ('Publishing Model', 'class="section pubmodel"'),
    ('Latest Research section', 'id="archive"'),
    ('Market Snapshot', 'class="market-snapshot"'),
    ('Search/filter', 'id="archive-search"'),
    ('Stories grid', 'class="stories"'),
    ('First story (feature)', 'story--feature'),
    ('Principles', 'class="section principles"'),
    ('Contact', 'id="contact"'),
    ('Main close', '</main>'),
    ('Footer', 'class="foot"'),
]

print("Body section order:")
for name, marker in sections:
    pos = body.find(marker)
    if pos == -1:
        print(f"  {name}: *** MISSING ***")
    else:
        print(f"  {name}: at byte {pos}")

# Check for any HTML comments that might be hiding content
comments = re.findall(r'<!--.*?-->', body, re.DOTALL)
print(f"\nHTML comments in body: {len(comments)}")

# Check if there are display:none or visibility:hidden inline styles
hidden = re.findall(r'style="[^"]*(?:display:\s*none|visibility:\s*hidden)[^"]*"', body)
print(f"Elements with display:none/visibility:hidden inline: {len(hidden)}")
for h in hidden[:5]:
    print(f"  {h[:100]}")

# Check for broken image paths
img_srcs = re.findall(r'<img[^>]+src="([^"]+)"', body)
print(f"\nImage sources ({len(img_srcs)}):")
for src in img_srcs:
    print(f"  {src}")

# Check the Vite proxy version too
print("\n\nVite proxy version:")
try:
    resp2 = urllib.request.urlopen("http://localhost:3000/insights/research/")
    html2 = resp2.read().decode("utf-8")
    # Does Vite inject anything?
    vite_injected = 'vite' in html2.lower() and 'vite' not in html.lower()
    print(f"  Vite injects extra content: {vite_injected}")
    if len(html2) != len(html):
        print(f"  Size difference: backend={len(html)}, vite={len(html2)}")
        # Find what's different
        if len(html2) > len(html):
            diff = len(html2) - len(html)
            print(f"  Vite added {diff} bytes")
            # Look for Vite client injection
            if '/@vite/client' in html2:
                print("  Vite HMR client injected (normal for dev)")
        elif len(html2) < len(html):
            print(f"  Vite removed {len(html) - len(html2)} bytes")
    else:
        print(f"  Identical size: {len(html)} bytes")
except Exception as e:
    print(f"  Error: {e}")
