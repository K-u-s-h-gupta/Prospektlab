"""Check if the hub HTML has proper structure and no CSS issues."""
import urllib.request
import re

resp = urllib.request.urlopen("http://127.0.0.1:8000/insights/research/")
html = resp.read().decode("utf-8")

# Check tag balance
open_tags = len(re.findall(r'<div[ >]', html))
close_tags = len(re.findall(r'</div>', html))
print(f"DIV tags: {open_tags} open, {close_tags} close, diff={open_tags - close_tags}")

open_sec = len(re.findall(r'<section[ >]', html))
close_sec = len(re.findall(r'</section>', html))
print(f"SECTION tags: {open_sec} open, {close_sec} close, diff={open_sec - close_sec}")

open_art = len(re.findall(r'<article[ >]', html))
close_art = len(re.findall(r'</article>', html))
print(f"ARTICLE tags: {open_art} open, {close_art} close, diff={open_art - close_art}")

# Check for unclosed style tag
style_open = html.count('<style>')
style_close = html.count('</style>')
print(f"STYLE tags: {style_open} open, {style_close} close")

# Check body structure
body_start = html.find('<body>')
body_end = html.find('</body>')
print(f"BODY: starts at {body_start}, ends at {body_end}")

# Check main sections exist in order
sections = [
    ('Ticker', 'ticker-track'),
    ('Header', 'site-head'),
    ('Hero', 'class="section hero"'),
    ('Market Band', 'market-band'),
    ('Publishing Model', 'pubmodel'),
    ('Latest Research', 'Latest Research'),
    ('Market Snapshot', 'market-snapshot'),
    ('Stories grid', 'class="stories"'),
    ('Principles', 'principle-grid'),
    ('Contact', 'contact-card'),
    ('Footer', 'foot-grid'),
]

print("\nSection order check:")
last_pos = 0
for name, marker in sections:
    pos = html.find(marker)
    if pos == -1:
        print(f"  {name}: MISSING!")
    elif pos < last_pos:
        print(f"  {name}: at {pos} (OUT OF ORDER, should be after {last_pos})")
    else:
        print(f"  {name}: at {pos} OK")
        last_pos = pos

# Check for common CSS issues
print("\nCSS variable check:")
css_match = re.search(r'<style>(.*?)</style>', html, re.DOTALL)
if css_match:
    css = css_match.group(1)
    print(f"  CSS length: {len(css)} chars")
    # Check key CSS classes
    key_classes = [
        '.story--feature', '.feat-thumb', '.feat-row', '.feat-side',
        '.story-card', '.story-thumb', '.mb-card', '.mb-grid',
        '.principle', '.contact-card', '.foot-grid',
        '.snap', '.idx-row', '.idx-spark',
    ]
    for cls in key_classes:
        if cls in css:
            print(f"  {cls}: defined")
        else:
            print(f"  {cls}: MISSING from CSS!")
else:
    print("  No <style> block found!")

# Count story cards
story_count = html.count('data-story ')
print(f"\nStory cards rendered: {story_count}")

# Check for empty/broken content
empty_divs = len(re.findall(r'<div[^>]*>\s*</div>', html))
print(f"Empty divs: {empty_divs}")
